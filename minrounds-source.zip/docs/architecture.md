# MindRounds MVP architecture

## Phase 1 delivered shape

The application starts with one course, Psychiatry. The course dashboard makes topics the main entry point, keeps past questions separate from teaching documents, and exposes a source-grounded AI entry surface. Preview content is isolated presentation data and will be replaced by approved topics discovered during ingestion.

Authentication is provided by the hosting layer for the deployed private site. The application reads the authenticated user server-side and does not expose credentials in the browser.

The PostgreSQL migration in `database/migrations/0001_foundation.sql` is the canonical data model. It includes course/topic/document/page/chunk provenance, global concepts for later cross-course use, separate past-paper entities, study artifacts, attempts, sessions, and progress. `pgvector` provides the future semantic retrieval index.

## Planned service boundaries

- `ingestion`: Drive discovery, stable source identity, checksums, parsing, OCR routing, page segmentation, and retries.
- `knowledge`: normalization, chunking, embeddings, hybrid retrieval, reranking, and citations.
- `topics`: extraction, canonicalization, AI confidence, and human corrections.
- `past-questions`: paper parsing, year/session extraction, question/options extraction, and topic classification.
- `study`: summaries, MCQs, flashcards, teaching mode, attempts, and progress.

## Phase 2 implementation sequence

1. Connect the Psychiatry Drive folder and discover files without duplicating records.
2. Classify file type and detect native-text versus scanned/image content.
3. Extract PDF, PPTX, DOCX, and image pages while preserving original page identity.
4. Add OCR/vision fallback with confidence and processing logs.
5. Populate documents, pages, topics, and topic-document assignments through an admin review queue.

## Grounding rule

Course answers must retrieve Psychiatry chunks with course/topic metadata filters, rerank the result, and cite the exact document and page or slide. When evidence is insufficient, the application must say so. General medical knowledge, when explicitly allowed, must be visually distinguished from course evidence.
