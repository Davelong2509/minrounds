import { sqliteTable, text, integer, index } from "drizzle-orm/sqlite-core";

export const studyResults = sqliteTable("study_results", {
  id:text("id").primaryKey(),
  owner:text("owner").notNull(),
  topicSlug:text("topic_slug").notNull(),
  requestKey:text("request_key").notNull(),
  sourceVersion:text("source_version").notNull(),
  mode:text("mode"),
  question:text("question").notNull(),
  resultJson:text("result_json").notNull(),
  createdAt:text("created_at").notNull(),
}, table=>[
  index("study_results_history").on(table.owner,table.topicSlug,table.createdAt),
  index("study_results_cache").on(table.owner,table.topicSlug,table.requestKey,table.sourceVersion),
]);

export const studyLocks = sqliteTable("study_locks", {
  key:text("key").primaryKey(),
  token:text("token").notNull(),
  expiresAt:integer("expires_at").notNull(),
});

export const learnerTopics = sqliteTable("learner_topics", {
  key:text("key").primaryKey(), owner:text("owner").notNull(), topicSlug:text("topic_slug").notNull(),
  completed:integer("completed").notNull().default(0), bookmarked:integer("bookmarked").notNull().default(0),
  seconds:integer("seconds").notNull().default(0), lastVisited:text("last_visited").notNull(),
},t=>[index("learner_topics_owner").on(t.owner,t.topicSlug)]);
export const learnerSessions = sqliteTable("learner_sessions", {
  key:text("key").primaryKey(), owner:text("owner").notNull(), topicSlug:text("topic_slug").notNull(),
  seconds:integer("seconds").notNull().default(0), updatedAt:text("updated_at").notNull(),
},t=>[index("learner_sessions_owner_topic").on(t.owner,t.topicSlug)]);
export const quizAttempts = sqliteTable("quiz_attempts", {
  id:text("id").primaryKey(), owner:text("owner").notNull(), resultId:text("result_id").notNull(), topicSlug:text("topic_slug").notNull(),
  mode:text("mode").notNull(), answersJson:text("answers_json").notNull(), correct:integer("correct").notNull(), total:integer("total").notNull(),
  seconds:integer("seconds").notNull(), createdAt:text("created_at").notNull(),
},t=>[index("quiz_attempts_owner").on(t.owner,t.createdAt), index("quiz_attempts_result").on(t.owner,t.resultId)]);
export const cardReviews = sqliteTable("card_reviews", {
  key:text("key").primaryKey(), owner:text("owner").notNull(), resultId:text("result_id").notNull(), cardIndex:integer("card_index").notNull(),
  intervalDays:integer("interval_days").notNull().default(0), repetitions:integer("repetitions").notNull().default(0),
  grade:text("grade").notNull(), dueAt:text("due_at").notNull(), updatedAt:text("updated_at").notNull(), eventId:text("event_id").notNull(),
},t=>[index("card_reviews_due").on(t.owner,t.dueAt)]);
export const studyPlans = sqliteTable("study_plans", {
  owner:text("owner").primaryKey(), examDate:text("exam_date").notNull(), dailyMinutes:integer("daily_minutes").notNull(),
  timezone:text("timezone").notNull(), reminderHour:integer("reminder_hour").notNull(), updatedAt:text("updated_at").notNull(),
});
export const videoRecommendations = sqliteTable("video_recommendations", {
  key:text("key").primaryKey(), topicSlug:text("topic_slug").notNull(), videoId:text("video_id").notNull(),
  title:text("title").notNull(), publisher:text("publisher").notNull(), focus:text("focus").notNull(),
  origin:text("origin").notNull().default("manual"),
  disabled:integer("disabled").notNull().default(0), checkStatus:text("check_status").notNull().default("unchecked"),
  checkedAt:text("checked_at"), updatedAt:text("updated_at").notNull(),
},t=>[index("video_recommendations_topic").on(t.topicSlug)]);
export const videoWatch = sqliteTable("video_watch", {
  key:text("key").primaryKey(), owner:text("owner").notNull(), topicSlug:text("topic_slug").notNull(), videoId:text("video_id").notNull(),
  position:integer("position").notNull(), duration:integer("duration").notNull(), completed:integer("completed").notNull(), updatedAt:text("updated_at").notNull(),
},t=>[index("video_watch_owner_topic").on(t.owner,t.topicSlug)]);
export const usageEvents = sqliteTable("usage_events", {
  id:text("id").primaryKey(), operation:text("operation").notNull(), model:text("model").notNull(), inputTokens:integer("input_tokens").notNull(),
  outputTokens:integer("output_tokens").notNull(), status:integer("status").notNull(), costMicros:integer("cost_micros"), createdAt:text("created_at").notNull(),
},t=>[index("usage_events_date").on(t.createdAt)]);
export const requestLimits = sqliteTable("request_limits", { key:text("key").primaryKey(), count:integer("count").notNull(), expiresAt:integer("expires_at").notNull() });
export const ingestionRuns = sqliteTable("ingestion_runs", { id:text("id").primaryKey(), status:text("status").notNull(), detail:text("detail").notNull(), createdAt:text("created_at").notNull() });

export const courseFolders = sqliteTable("course_folders", {
 folderId:text("folder_id").primaryKey(), courseId:text("course_id").notNull(),
 slug:text("slug").notNull(), name:text("name").notNull(), active:integer("active").notNull().default(1),
 updatedAt:text("updated_at").notNull(),
},t=>[index("course_folders_course").on(t.courseId)]);

export const videoDiscovery = sqliteTable("video_discovery", {
 topicSlug:text("topic_slug").primaryKey(), queryKey:text("query_key").notNull(),
 status:text("status").notNull(), error:text("error"), updatedAt:text("updated_at").notNull(),
});
