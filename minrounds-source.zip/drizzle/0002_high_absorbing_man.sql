CREATE INDEX `learner_sessions_owner_topic` ON `learner_sessions` (`owner`,`topic_slug`);--> statement-breakpoint
CREATE INDEX `quiz_attempts_result` ON `quiz_attempts` (`owner`,`result_id`);--> statement-breakpoint
CREATE INDEX `usage_events_date` ON `usage_events` (`created_at`);--> statement-breakpoint
CREATE INDEX `video_recommendations_topic` ON `video_recommendations` (`topic_slug`);--> statement-breakpoint
CREATE INDEX `video_watch_owner_topic` ON `video_watch` (`owner`,`topic_slug`);