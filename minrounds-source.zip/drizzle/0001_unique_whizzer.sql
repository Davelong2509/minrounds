CREATE TABLE `card_reviews` (
	`key` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`result_id` text NOT NULL,
	`card_index` integer NOT NULL,
	`interval_days` integer DEFAULT 0 NOT NULL,
	`repetitions` integer DEFAULT 0 NOT NULL,
	`grade` text NOT NULL,
	`due_at` text NOT NULL,
	`updated_at` text NOT NULL,
	`event_id` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `card_reviews_due` ON `card_reviews` (`owner`,`due_at`);--> statement-breakpoint
CREATE TABLE `ingestion_runs` (
	`id` text PRIMARY KEY NOT NULL,
	`status` text NOT NULL,
	`detail` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `learner_sessions` (
	`key` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`topic_slug` text NOT NULL,
	`seconds` integer DEFAULT 0 NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `learner_topics` (
	`key` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`topic_slug` text NOT NULL,
	`completed` integer DEFAULT 0 NOT NULL,
	`bookmarked` integer DEFAULT 0 NOT NULL,
	`seconds` integer DEFAULT 0 NOT NULL,
	`last_visited` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `learner_topics_owner` ON `learner_topics` (`owner`,`topic_slug`);--> statement-breakpoint
CREATE TABLE `quiz_attempts` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`result_id` text NOT NULL,
	`topic_slug` text NOT NULL,
	`mode` text NOT NULL,
	`answers_json` text NOT NULL,
	`correct` integer NOT NULL,
	`total` integer NOT NULL,
	`seconds` integer NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `quiz_attempts_owner` ON `quiz_attempts` (`owner`,`created_at`);--> statement-breakpoint
CREATE TABLE `request_limits` (
	`key` text PRIMARY KEY NOT NULL,
	`count` integer NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `study_plans` (
	`owner` text PRIMARY KEY NOT NULL,
	`exam_date` text NOT NULL,
	`daily_minutes` integer NOT NULL,
	`timezone` text NOT NULL,
	`reminder_hour` integer NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `usage_events` (
	`id` text PRIMARY KEY NOT NULL,
	`operation` text NOT NULL,
	`model` text NOT NULL,
	`input_tokens` integer NOT NULL,
	`output_tokens` integer NOT NULL,
	`status` integer NOT NULL,
	`cost_micros` integer,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `video_recommendations` (
	`key` text PRIMARY KEY NOT NULL,
	`topic_slug` text NOT NULL,
	`video_id` text NOT NULL,
	`title` text NOT NULL,
	`publisher` text NOT NULL,
	`focus` text NOT NULL,
	`disabled` integer DEFAULT 0 NOT NULL,
	`check_status` text DEFAULT 'unchecked' NOT NULL,
	`checked_at` text,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `video_watch` (
	`key` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`topic_slug` text NOT NULL,
	`video_id` text NOT NULL,
	`position` integer NOT NULL,
	`duration` integer NOT NULL,
	`completed` integer NOT NULL,
	`updated_at` text NOT NULL
);
