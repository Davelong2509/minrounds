CREATE TABLE `study_locks` (
	`key` text PRIMARY KEY NOT NULL,
	`token` text NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `study_results` (
	`id` text PRIMARY KEY NOT NULL,
	`owner` text NOT NULL,
	`topic_slug` text NOT NULL,
	`request_key` text NOT NULL,
	`source_version` text NOT NULL,
	`mode` text,
	`question` text NOT NULL,
	`result_json` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `study_results_history` ON `study_results` (`owner`,`topic_slug`,`created_at`);--> statement-breakpoint
CREATE INDEX `study_results_cache` ON `study_results` (`owner`,`topic_slug`,`request_key`,`source_version`);