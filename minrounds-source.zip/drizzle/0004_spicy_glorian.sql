CREATE TABLE `video_discovery` (
	`topic_slug` text PRIMARY KEY NOT NULL,
	`query_key` text NOT NULL,
	`status` text NOT NULL,
	`error` text,
	`updated_at` text NOT NULL
);
