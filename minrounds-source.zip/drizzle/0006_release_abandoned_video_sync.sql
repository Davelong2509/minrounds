-- Release only this abandoned pre-batching video sync; unrelated work is untouched.
DELETE FROM study_locks WHERE key = 'pipeline' AND token = '1303713c-aa53-4b2e-a7b2-b4e365731dd2';
