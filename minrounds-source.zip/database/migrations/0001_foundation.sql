CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TYPE document_type AS ENUM ('lecture', 'note', 'slide', 'textbook', 'past_question', 'other');
CREATE TYPE processing_status AS ENUM ('discovered', 'queued', 'processing', 'ready', 'failed');
CREATE TYPE question_type AS ENUM ('single_best_answer', 'multiple_choice', 'short_answer', 'essay', 'other');
CREATE TYPE topic_relation_role AS ENUM ('primary', 'secondary');

CREATE TABLE users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  auth_provider_id text UNIQUE NOT NULL,
  email text UNIQUE NOT NULL,
  display_name text,
  role text NOT NULL DEFAULT 'student' CHECK (role IN ('student', 'admin')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE courses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text UNIQUE NOT NULL,
  name text NOT NULL,
  description text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE topics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  parent_topic_id uuid REFERENCES topics(id) ON DELETE SET NULL,
  canonical_name text NOT NULL,
  slug text NOT NULL,
  description text,
  status text NOT NULL DEFAULT 'suggested' CHECK (status IN ('suggested', 'approved', 'merged', 'archived')),
  merged_into_topic_id uuid REFERENCES topics(id) ON DELETE SET NULL,
  created_by text NOT NULL DEFAULT 'ai' CHECK (created_by IN ('ai', 'admin')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(course_id, slug)
);

CREATE TABLE concepts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  canonical_name text UNIQUE NOT NULL,
  slug text UNIQUE NOT NULL,
  description text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE course_concepts (
  course_id uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  concept_id uuid NOT NULL REFERENCES concepts(id) ON DELETE CASCADE,
  PRIMARY KEY (course_id, concept_id)
);

CREATE TABLE topic_concepts (
  topic_id uuid NOT NULL REFERENCES topics(id) ON DELETE CASCADE,
  concept_id uuid NOT NULL REFERENCES concepts(id) ON DELETE CASCADE,
  confidence numeric(5,4),
  assignment_source text NOT NULL DEFAULT 'ai' CHECK (assignment_source IN ('ai', 'admin')),
  PRIMARY KEY (topic_id, concept_id)
);

CREATE TABLE concept_relationships (
  source_concept_id uuid NOT NULL REFERENCES concepts(id) ON DELETE CASCADE,
  target_concept_id uuid NOT NULL REFERENCES concepts(id) ON DELETE CASCADE,
  relationship text NOT NULL,
  PRIMARY KEY (source_concept_id, target_concept_id, relationship)
);

CREATE TABLE documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  source_provider text NOT NULL DEFAULT 'google_drive',
  source_file_id text NOT NULL,
  source_version text,
  source_url text,
  checksum_sha256 text,
  title text NOT NULL,
  mime_type text NOT NULL,
  file_extension text,
  document_type document_type NOT NULL DEFAULT 'other',
  is_handwritten boolean NOT NULL DEFAULT false,
  processing_status processing_status NOT NULL DEFAULT 'discovered',
  processing_error text,
  discovered_at timestamptz NOT NULL DEFAULT now(),
  processed_at timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(source_provider, source_file_id)
);

CREATE TABLE topic_documents (
  topic_id uuid NOT NULL REFERENCES topics(id) ON DELETE CASCADE,
  document_id uuid NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  confidence numeric(5,4),
  assignment_source text NOT NULL DEFAULT 'ai' CHECK (assignment_source IN ('ai', 'admin')),
  PRIMARY KEY (topic_id, document_id)
);

CREATE TABLE document_pages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id uuid NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  page_number integer NOT NULL CHECK (page_number > 0),
  slide_number integer,
  storage_key text,
  extracted_text text,
  extraction_method text CHECK (extraction_method IN ('native', 'ocr', 'vision', 'hybrid')),
  extraction_confidence numeric(5,4),
  is_image_only boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(document_id, page_number)
);

CREATE TABLE document_chunks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  document_id uuid NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  document_page_id uuid REFERENCES document_pages(id) ON DELETE CASCADE,
  chunk_index integer NOT NULL CHECK (chunk_index >= 0),
  content text NOT NULL,
  token_count integer,
  embedding vector(1536),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(document_id, chunk_index)
);

CREATE TABLE past_question_papers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  document_id uuid UNIQUE NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
  exam_year integer,
  session_name text,
  institution text,
  answer_key_available boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE past_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  paper_id uuid NOT NULL REFERENCES past_question_papers(id) ON DELETE CASCADE,
  source_page_id uuid REFERENCES document_pages(id) ON DELETE SET NULL,
  question_number text,
  question_text text NOT NULL,
  question_type question_type NOT NULL DEFAULT 'other',
  official_answer text,
  ai_explanation text,
  extraction_confidence numeric(5,4),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE past_question_options (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question_id uuid NOT NULL REFERENCES past_questions(id) ON DELETE CASCADE,
  option_key text,
  option_text text NOT NULL,
  is_officially_correct boolean,
  display_order integer NOT NULL,
  UNIQUE(question_id, display_order)
);

CREATE TABLE past_question_topics (
  question_id uuid NOT NULL REFERENCES past_questions(id) ON DELETE CASCADE,
  topic_id uuid NOT NULL REFERENCES topics(id) ON DELETE CASCADE,
  relation_role topic_relation_role NOT NULL DEFAULT 'secondary',
  confidence numeric(5,4),
  assignment_source text NOT NULL DEFAULT 'ai' CHECK (assignment_source IN ('ai', 'admin')),
  PRIMARY KEY (question_id, topic_id)
);

CREATE TABLE past_question_concepts (
  question_id uuid NOT NULL REFERENCES past_questions(id) ON DELETE CASCADE,
  concept_id uuid NOT NULL REFERENCES concepts(id) ON DELETE CASCADE,
  confidence numeric(5,4),
  PRIMARY KEY (question_id, concept_id)
);

CREATE TABLE flashcards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES users(id) ON DELETE CASCADE,
  course_id uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  topic_id uuid REFERENCES topics(id) ON DELETE SET NULL,
  front text NOT NULL,
  back text NOT NULL,
  source_references jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE quiz_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  course_id uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  topic_id uuid REFERENCES topics(id) ON DELETE SET NULL,
  prompt text NOT NULL,
  options jsonb NOT NULL,
  correct_answer text NOT NULL,
  explanation text NOT NULL,
  difficulty text NOT NULL CHECK (difficulty IN ('easy', 'medium', 'hard')),
  source_references jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE quiz_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  quiz_question_id uuid NOT NULL REFERENCES quiz_questions(id) ON DELETE CASCADE,
  selected_answer text,
  is_correct boolean,
  attempted_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE study_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  course_id uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  topic_id uuid REFERENCES topics(id) ON DELETE SET NULL,
  session_type text NOT NULL,
  started_at timestamptz NOT NULL DEFAULT now(),
  ended_at timestamptz
);

CREATE TABLE user_progress (
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  course_id uuid NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  topic_id uuid NOT NULL REFERENCES topics(id) ON DELETE CASCADE,
  materials_opened integer NOT NULL DEFAULT 0,
  questions_attempted integer NOT NULL DEFAULT 0,
  questions_correct integer NOT NULL DEFAULT 0,
  last_studied_at timestamptz,
  PRIMARY KEY (user_id, topic_id)
);

CREATE INDEX idx_topics_course_status ON topics(course_id, status);
CREATE INDEX idx_documents_course_status ON documents(course_id, processing_status);
CREATE INDEX idx_documents_checksum ON documents(checksum_sha256);
CREATE INDEX idx_document_pages_document ON document_pages(document_id, page_number);
CREATE INDEX idx_chunks_document_page ON document_chunks(document_id, document_page_id);
CREATE INDEX idx_chunks_embedding ON document_chunks USING hnsw (embedding vector_cosine_ops);
CREATE INDEX idx_papers_course_year ON past_question_papers(course_id, exam_year DESC);
CREATE INDEX idx_pq_topics_topic ON past_question_topics(topic_id, question_id);
CREATE INDEX idx_progress_user_course ON user_progress(user_id, course_id);

INSERT INTO courses (slug, name, description)
VALUES ('psychiatry', 'Psychiatry', 'Structured Psychiatry learning from lectures, notes, and past questions')
ON CONFLICT (slug) DO NOTHING;
