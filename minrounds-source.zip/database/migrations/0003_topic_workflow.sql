-- Optional database-side views and protection for the Phase 6 topic workflow.
-- Core topic management works against 0001_foundation.sql without these views.
BEGIN;

CREATE OR REPLACE VIEW topic_candidates WITH (security_invoker = true) AS
SELECT t.id, t.course_id, t.canonical_name AS name, t.description,
       t.status, t.created_at,
       (SELECT max(td.confidence) FROM topic_documents td WHERE td.topic_id = t.id) AS confidence,
       ARRAY(SELECT td.document_id FROM topic_documents td WHERE td.topic_id = t.id) AS source_documents
FROM topics t WHERE t.status = 'suggested';

CREATE OR REPLACE VIEW question_topics WITH (security_invoker = true) AS
SELECT * FROM past_question_topics;

CREATE OR REPLACE FUNCTION protect_reviewed_topic_assignment()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NEW.assignment_source = 'ai' AND EXISTS (
    SELECT 1 FROM topics WHERE id = NEW.topic_id
      AND (created_by = 'admin' OR status IN ('merged', 'archived'))
  ) THEN
    RETURN NULL;
  END IF;
  IF TG_OP = 'UPDATE' AND OLD.assignment_source = 'admin'
     AND NEW.assignment_source = 'ai' THEN
    RETURN OLD;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS protect_topic_documents ON topic_documents;
CREATE TRIGGER protect_topic_documents BEFORE INSERT OR UPDATE ON topic_documents
FOR EACH ROW EXECUTE FUNCTION protect_reviewed_topic_assignment();
DROP TRIGGER IF EXISTS protect_topic_concepts ON topic_concepts;
CREATE TRIGGER protect_topic_concepts BEFORE INSERT OR UPDATE ON topic_concepts
FOR EACH ROW EXECUTE FUNCTION protect_reviewed_topic_assignment();
DROP TRIGGER IF EXISTS protect_question_topics ON past_question_topics;
CREATE TRIGGER protect_question_topics BEFORE INSERT OR UPDATE ON past_question_topics
FOR EACH ROW EXECUTE FUNCTION protect_reviewed_topic_assignment();

GRANT SELECT ON topic_candidates, question_topics TO service_role;
COMMIT;
