ALTER TABLE document_chunks
  ADD COLUMN IF NOT EXISTS embedding_model text,
  ADD COLUMN IF NOT EXISTS embedded_at timestamptz;

CREATE OR REPLACE FUNCTION match_psychiatry_chunks(
  query_embedding vector(1536),
  match_threshold float DEFAULT 0.18,
  match_count integer DEFAULT 8,
  filter_course_id uuid DEFAULT NULL,
  filter_topic_id uuid DEFAULT NULL
)
RETURNS TABLE (
  content text,
  document_title text,
  source_url text,
  page_number integer,
  similarity float
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT
    dc.content,
    d.title AS document_title,
    d.source_url,
    dp.page_number,
    1 - (dc.embedding <=> query_embedding) AS similarity
  FROM document_chunks dc
  JOIN documents d ON d.id = dc.document_id
  LEFT JOIN document_pages dp ON dp.id = dc.document_page_id
  WHERE dc.embedding IS NOT NULL
    AND (filter_course_id IS NULL OR d.course_id = filter_course_id)
    AND (
      filter_topic_id IS NULL OR EXISTS (
        SELECT 1 FROM topic_documents td
        WHERE td.document_id = d.id AND td.topic_id = filter_topic_id
      )
    )
    AND 1 - (dc.embedding <=> query_embedding) >= match_threshold
  ORDER BY dc.embedding <=> query_embedding
  LIMIT LEAST(GREATEST(match_count, 1), 20);
$$;

REVOKE ALL ON FUNCTION match_psychiatry_chunks(vector, float, integer, uuid, uuid) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION match_psychiatry_chunks(vector, float, integer, uuid, uuid) TO service_role;

