type ServiceAccount = {
  client_email: string;
  private_key: string;
  token_uri?: string;
};

export type DriveFile = {
  id: string;
  name: string;
  mimeType: string;
  modifiedTime?: string;
  version?: string;
  webViewLink?: string;
  fileExtension?: string;
  size?: string;
  md5Checksum?: string;
  parents?: string[];
};

const DRIVE_FOLDER_MIME = "application/vnd.google-apps.folder";

export function isGoogleDriveConfigured() {
  return Boolean((process.env.GOOGLE_DRIVE_ROOT_FOLDER_ID || process.env.GOOGLE_DRIVE_FOLDER_ID) && process.env.GOOGLE_SERVICE_ACCOUNT_JSON);
}

function base64Url(value: Uint8Array | string) {
  const bytes = typeof value === "string" ? new TextEncoder().encode(value) : value;
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function pemToBytes(pem: string) {
  const base64 = pem
    .replace(/-----BEGIN PRIVATE KEY-----/g, "")
    .replace(/-----END PRIVATE KEY-----/g, "")
    .replace(/\s/g, "");
  const binary = atob(base64);
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
}

async function getAccessToken() {
  const raw = process.env.GOOGLE_SERVICE_ACCOUNT_JSON;
  if (!raw) throw new Error("Google service-account credentials are not configured.");

  let account: ServiceAccount;
  try {
    account = JSON.parse(raw) as ServiceAccount;
  } catch {
    throw new Error("Google service-account credentials are not valid JSON.");
  }
  if (!account.client_email || !account.private_key) {
    throw new Error("Google service-account credentials are incomplete.");
  }

  const now = Math.floor(Date.now() / 1000);
  const tokenUri = account.token_uri || "https://oauth2.googleapis.com/token";
  const header = base64Url(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const payload = base64Url(
    JSON.stringify({
      iss: account.client_email,
      scope: "https://www.googleapis.com/auth/drive.readonly",
      aud: tokenUri,
      iat: now,
      exp: now + 3600,
    }),
  );
  const unsigned = `${header}.${payload}`;
  const key = await crypto.subtle.importKey(
    "pkcs8",
    pemToBytes(account.private_key),
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const signature = await crypto.subtle.sign(
    "RSASSA-PKCS1-v1_5",
    key,
    new TextEncoder().encode(unsigned),
  );

  const response = await fetch(tokenUri, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
      assertion: `${unsigned}.${base64Url(new Uint8Array(signature))}`,
    }),
  });
  const body = (await response.json()) as { access_token?: string; error_description?: string };
  if (!response.ok || !body.access_token) {
    throw new Error(body.error_description || "Google Drive authentication failed.");
  }
  return body.access_token;
}

export async function downloadDriveFile(file: DriveFile) {
  const accessToken = await getAccessToken();
  const isGoogleNative = file.mimeType.startsWith("application/vnd.google-apps.");
  const targetMimeType = isGoogleNative ? "application/pdf" : file.mimeType;
  const url = isGoogleNative
    ? `https://www.googleapis.com/drive/v3/files/${encodeURIComponent(file.id)}/export?mimeType=${encodeURIComponent(targetMimeType)}`
    : `https://www.googleapis.com/drive/v3/files/${encodeURIComponent(file.id)}?alt=media&supportsAllDrives=true`;
  const response = await fetch(url, {
    headers: { Authorization: `Bearer ${accessToken}` },
    cache: "no-store",
  });
  if (!response.ok) {
    const detail = await response.text();
    throw new Error(`Google Drive download failed (${response.status}): ${detail.slice(0, 300)}`);
  }
  const blob = await response.blob();
  if (blob.size > 24 * 1024 * 1024) {
    throw new Error("This file is larger than the current 24 MB processing limit.");
  }
  return {
    blob,
    mimeType: targetMimeType,
    filename: isGoogleNative ? `${file.name.replace(/\.[^.]+$/, "")}.pdf` : file.name,
  };
}

async function listFolder(folderId: string, accessToken: string) {
  const files: DriveFile[] = [];
  let pageToken: string | undefined;

  do {
    const params = new URLSearchParams({
      q: `'${folderId.replace(/'/g, "\\'")}' in parents and trashed = false`,
      pageSize: "1000",
      supportsAllDrives: "true",
      includeItemsFromAllDrives: "true",
      fields:
        "nextPageToken,files(id,name,mimeType,modifiedTime,version,webViewLink,fileExtension,size,md5Checksum,parents)",
    });
    if (pageToken) params.set("pageToken", pageToken);

    const response = await fetch(`https://www.googleapis.com/drive/v3/files?${params}`, {
      headers: { Authorization: `Bearer ${accessToken}` },
      signal: AbortSignal.timeout(30000),
      cache: "no-store",
    });
    const body = (await response.json()) as {
      files?: DriveFile[];
      nextPageToken?: string;
      error?: { message?: string };
    };
    if (!response.ok) throw new Error(body.error?.message || "Google Drive listing failed.");
    files.push(...(body.files ?? []));
    pageToken = body.nextPageToken;
  } while (pageToken);

  return files;
}

export function psychiatryRoot(rootFolderId:string, entries:DriveFile[]) {
  const folders=entries.filter(file=>file.mimeType===DRIVE_FOLDER_MIME);
  const psychiatry=folders.filter(file=>file.name.trim().toLowerCase()==="psychiatry");
  if(psychiatry.length>1)throw Error("Multiple Psychiatry folders found. Configure the exact Psychiatry folder.");
  if(psychiatry.length)return psychiatry[0].id;
  if(folders.some(file=>/^(dermatology|orthop(?:a)?edics)$/i.test(file.name.trim())))throw Error("Configure the Psychiatry folder directly; other course folders will not be imported into Psychiatry.");
  return rootFolderId;
}
export async function discoverDriveFiles() {
  const rootFolderId = process.env.GOOGLE_DRIVE_FOLDER_ID;
  if (!rootFolderId) throw new Error("GOOGLE_DRIVE_FOLDER_ID is not configured.");

  const accessToken = await getAccessToken();
  const discovered: DriveFile[] = [];
  const rootEntries=await listFolder(rootFolderId,accessToken);
  const pending = [psychiatryRoot(rootFolderId,rootEntries)];
  const visited = new Set<string>();

  while (pending.length) {
    const folderId = pending.shift()!;
    if (visited.has(folderId)) continue;
    visited.add(folderId);
    const entries = await listFolder(folderId, accessToken);
    for (const entry of entries) {
      if (entry.mimeType === DRIVE_FOLDER_MIME) { if(!/^(dermatology|orthop(?:a)?edics)$/i.test(entry.name.trim()))pending.push(entry.id); }
      else discovered.push(entry);
    }
  }

  return discovered;
}

export async function discoverDriveCourses(rootId:string){
 const accessToken=await getAccessToken();
 // Verify access to the actual root: an inaccessible folder must never look empty.
 const rootResponse=await fetch(`https://www.googleapis.com/drive/v3/files/${encodeURIComponent(rootId)}?fields=id,mimeType&supportsAllDrives=true`,{headers:{Authorization:`Bearer ${accessToken}`},signal:AbortSignal.timeout(30000)});
 if(!rootResponse.ok)throw Error(`MindRounds parent folder is inaccessible (${rootResponse.status}). Share it with the configured Google service account.`);
 const root=await rootResponse.json() as {mimeType:string};if(root.mimeType!==DRIVE_FOLDER_MIME)throw Error("MindRounds root must be a Drive folder.");
 const entries=await listFolder(rootId,accessToken);
 const folders=entries.filter(f=>f.mimeType===DRIVE_FOLDER_MIME);
 const courses:Array<{folder:DriveFile;files:DriveFile[];error?:string}>=[];
 for(const folder of folders){
  const files:DriveFile[]=[];const pending=[folder.id];const visited=new Set<string>();
  try{while(pending.length){const id=pending.shift()!;if(visited.has(id))continue;visited.add(id);
   for(const entry of await listFolder(id,accessToken)){if(entry.mimeType===DRIVE_FOLDER_MIME)pending.push(entry.id);else files.push(entry);}
  }courses.push({folder,files});}catch(e){courses.push({folder,files:[],error:e instanceof Error?e.message:"Folder scan failed."});}
 }
 return {courses,ignoredRootFiles:entries.filter(f=>f.mimeType!==DRIVE_FOLDER_MIME).length};
}
