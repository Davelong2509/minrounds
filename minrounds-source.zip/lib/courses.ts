import { env } from "cloudflare:workers";
import { supabaseRequest } from "./supabase";
export type Course = {id:string;slug:string;name:string;description:string|null;is_active:boolean};
export async function getCourses() {
 const {data}=await supabaseRequest<Course[]>("courses?select=id,slug,name,description,is_active&is_active=eq.true&order=name.asc&limit=10000");
 return data;
}
export async function getCourse(slug="psychiatry") {
 if(!/^[a-z0-9-]{1,100}$/.test(slug))return null;
 const {data}=await supabaseRequest<Course[]>(`courses?select=id,slug,name,description,is_active&slug=eq.${encodeURIComponent(slug)}&is_active=eq.true&limit=1`);
 return data[0]??null;
}
export async function documentCourse(id:string) {
 if(!/^[0-9a-f-]{36}$/.test(id))return null;
 const {data}=await supabaseRequest<Array<{course_id:string}>>(`documents?select=course_id&id=eq.${id}&limit=1`);
 if(!data[0])return null;
 const {data:courses}=await supabaseRequest<Course[]>(`courses?select=id,slug,name,description,is_active&id=eq.${data[0].course_id}&is_active=eq.true&limit=1`);
 return courses[0]??null;
}
export async function activeCourseFilter(){const courses=await getCourses();return `course_id=in.(${courses.map(c=>c.id).join(",")||"00000000-0000-0000-0000-000000000000"})`;}
// Drive folder IDs are permanent identities; names and URLs may change.
export async function registerCourseFolder(folder:{id:string;name:string}){
 if(!env.DB)throw Error("Course folder storage is unavailable.");
 const previous=await env.DB.prepare("SELECT course_id,slug FROM course_folders WHERE folder_id=?").bind(folder.id).first<{course_id:string;slug:string}>();
 let courseId=previous?.course_id;let slug=previous?.slug;
 if(!courseId){
  const legacy=folder.name.trim().toLowerCase()==="psychiatry"?await getCourse("psychiatry"):null;
  if(legacy){const claimed=await env.DB.prepare("SELECT folder_id FROM course_folders WHERE course_id=?").bind(legacy.id).first();if(!claimed){courseId=legacy.id;slug=legacy.slug;}}
  if(!courseId){
   const suffix=Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256",new TextEncoder().encode(folder.id)))).slice(0,8).map(n=>n.toString(16).padStart(2,"0")).join("");
   slug=`${folder.name.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g,"").replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"").slice(0,65)||"course"}-${suffix}`;
   const {data}=await supabaseRequest<Course[]>("courses?on_conflict=slug&select=id",{method:"POST",headers:{Prefer:"resolution=merge-duplicates,return=representation"},body:JSON.stringify({slug,name:folder.name,is_active:true,description:"Materials from a MindRounds Drive course folder."})});
   courseId=data[0]?.id;if(!courseId)throw Error(`Could not register course ${folder.name}.`);
  }
 }
 await supabaseRequest(`courses?id=eq.${courseId}`,{method:"PATCH",headers:{Prefer:"return=minimal"},body:JSON.stringify({name:folder.name,is_active:true,updated_at:new Date().toISOString()})});
 await env.DB.prepare("INSERT INTO course_folders(folder_id,course_id,slug,name,active,updated_at) VALUES(?,?,?,?,1,?) ON CONFLICT(folder_id) DO UPDATE SET name=excluded.name,active=1,updated_at=excluded.updated_at").bind(folder.id,courseId,slug,folder.name,new Date().toISOString()).run();
 return {id:courseId,slug:slug!,name:folder.name};
}
export async function hideMissingCourseFolders(present:string[]){
 if(!env.DB)throw Error("Course folder storage is unavailable.");
 const {results}=await env.DB.prepare("SELECT folder_id,course_id FROM course_folders WHERE active=1").all<{folder_id:string;course_id:string}>();
 for(const row of results)if(!present.includes(row.folder_id)){
  await supabaseRequest(`courses?id=eq.${row.course_id}`,{method:"PATCH",headers:{Prefer:"return=minimal"},body:JSON.stringify({is_active:false,updated_at:new Date().toISOString()})});
  await env.DB.prepare("UPDATE course_folders SET active=0,updated_at=? WHERE folder_id=?").bind(new Date().toISOString(),row.folder_id).run();
 }
}
