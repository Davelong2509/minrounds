import { database, studyOwner, materialVersion } from "./saved-study";
import { gradeQuiz, nextCardReview, dayInTimezone, type CardGrade, type LearningData, type Attempt, type Progress, type Review, type Plan } from "./learning-types";
import type { GroundedAnswer } from "./rag";
export const uuid=(v:unknown):v is string=>typeof v==="string"&&/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(v);
const key=(...parts:unknown[])=>JSON.stringify(parts);
export async function ownedStudy(owner:string,id:string){
  if(!uuid(id))throw Error("Choose a saved study result.");
  const row=await database().prepare("SELECT id, topic_slug, question, mode, result_json, created_at FROM study_results WHERE id = ? AND owner = ?").bind(id,owner).first<{id:string;topic_slug:string;question:string;mode:string|null;result_json:string;created_at:string}>();
  if(!row)throw Error("This saved result is unavailable for your account.");
  return {...row,result:JSON.parse(row.result_json) as GroundedAnswer};
}
export async function learningData(resultId?:string,topicSlug?:string):Promise<LearningData>{
  const {owner,signedIn}=await studyOwner();const db=database();
  const [progress,attempts,reviews,decks,plan,totals,watches]=await Promise.all([
    db.prepare("SELECT topic_slug, completed, bookmarked, seconds, last_visited FROM learner_topics WHERE owner = ? ORDER BY last_visited DESC").bind(owner).all<Progress>(),
    db.prepare(`SELECT * FROM quiz_attempts WHERE owner = ? ${resultId?"AND result_id = ?":""} ORDER BY created_at DESC LIMIT 100`).bind(...(resultId?[owner,resultId]:[owner])).all<Attempt>(),
    db.prepare("SELECT result_id,card_index,interval_days,repetitions,grade,due_at,updated_at FROM card_reviews WHERE owner = ?").bind(owner).all<Review>(),
    db.prepare("SELECT s.id,s.topic_slug,s.result_json,s.created_at FROM study_results s WHERE s.owner = ? AND s.mode IN ('mcqs','flashcards') AND NOT EXISTS (SELECT 1 FROM study_results newer WHERE newer.owner = s.owner AND newer.topic_slug = s.topic_slug AND newer.mode = s.mode AND (newer.created_at > s.created_at OR (newer.created_at = s.created_at AND newer.id > s.id))) ORDER BY s.created_at DESC LIMIT 100").bind(owner).all<{id:string;topic_slug:string;result_json:string;created_at:string}>(),
    db.prepare("SELECT * FROM study_plans WHERE owner = ?").bind(owner).first<Plan>(),
    db.prepare("SELECT COUNT(*) AS attempts, COALESCE(SUM(correct),0) AS correct, COALESCE(SUM(total),0) AS questions FROM quiz_attempts WHERE owner = ?").bind(owner).first<{attempts:number;correct:number;questions:number}>(),
    topicSlug?db.prepare("SELECT video_id, position, duration, completed FROM video_watch WHERE owner = ? AND topic_slug = ?").bind(owner,topicSlug).all<LearningData["watches"][number]>():Promise.resolve({results:[]}),
  ]);
  return {signedIn,progress:progress.results,attempts:attempts.results.map(({id,result_id,topic_slug,mode,answers_json,correct,total,seconds,created_at})=>({id,result_id,topic_slug,mode,answers_json,correct,total,seconds,created_at})),reviews:reviews.results,decks:decks.results.map(r=>{const result=JSON.parse(r.result_json) as GroundedAnswer;return {id:r.id,topicSlug:r.topic_slug,createdAt:r.created_at,cards:result.flashcards??[],mcqs:result.mcqs??[]};}),plan,totals:totals??{correct:0,questions:0,attempts:0},watches:watches.results};
}
export async function learningMutation(body:Record<string,unknown>){
  const {owner}=await studyOwner();const db=database();const now=new Date().toISOString();
  if(body.action==="quiz"){
    if(!uuid(body.attemptId))throw Error("Invalid quiz attempt.");
    const saved=await ownedStudy(owner,String(body.resultId));
    const items=saved.result.mcqs??[];if(!items.length)throw Error("This result has no MCQs.");
    const graded=gradeQuiz(items,body.answers);const seconds=Number(body.seconds);
    if(!Number.isInteger(seconds)||seconds<0||seconds>86400)throw Error("Invalid quiz duration.");
    const mode=body.mode==="exam"?"exam":"practice";
    await db.prepare("INSERT INTO quiz_attempts (id,owner,result_id,topic_slug,mode,answers_json,correct,total,seconds,created_at) VALUES (?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING").bind(body.attemptId,owner,saved.id,saved.topic_slug,mode,JSON.stringify(graded.answers),graded.correct,graded.total,seconds,now).run();
    const attempt=await db.prepare("SELECT * FROM quiz_attempts WHERE id = ? AND owner = ? AND result_id = ?").bind(body.attemptId,owner,saved.id).first<Attempt>();
    if(!attempt)throw Error("This attempt could not be saved.");
    return {attempt};
  }
  if(body.action==="review"){
    const saved=await ownedStudy(owner,String(body.resultId));const i=Number(body.cardIndex);
    if(!Number.isInteger(i)||!saved.result.flashcards?.[i])throw Error("Choose a valid card.");
    if(!["again","hard","good","easy"].includes(String(body.grade))||!uuid(body.eventId))throw Error("Choose a review rating.");
    const cardKey=key(owner,saved.id,i);
    const previous=await db.prepare("SELECT * FROM card_reviews WHERE key = ? AND owner = ?").bind(cardKey,owner).first<Review & {event_id:string}>();
    if(previous?.event_id===body.eventId)return {review:previous};
    const next=nextCardReview(previous,body.grade as CardGrade);
    const row=await db.prepare("INSERT INTO card_reviews (key,owner,result_id,card_index,interval_days,repetitions,grade,due_at,updated_at,event_id) VALUES (?,?,?,?,?,?,?,?,?,?) ON CONFLICT(key) DO UPDATE SET interval_days=excluded.interval_days,repetitions=excluded.repetitions,grade=excluded.grade,due_at=excluded.due_at,updated_at=excluded.updated_at,event_id=excluded.event_id WHERE card_reviews.event_id = ? RETURNING *").bind(cardKey,owner,saved.id,i,next.intervalDays,next.repetitions,body.grade,next.dueAt,now,body.eventId,previous?.event_id??"").first<Review>();
    if(!row)throw Error("This card changed in another tab. Reload before rating again.");
    return {review:row};
  }
  if(body.action==="plan"){
    const examDate=String(body.examDate);const minutes=Number(body.dailyMinutes);const hour=Number(body.reminderHour);const timezone=String(body.timezone??"Africa/Lagos");
    if(!/^\d{4}-\d{2}-\d{2}$/.test(examDate)||!Number.isFinite(Date.parse(examDate))||new Date(examDate).toISOString().slice(0,10)!==examDate)throw Error("Choose a valid exam date.");
    if(!Number.isInteger(minutes)||minutes<5||minutes>480||!Number.isInteger(hour)||hour<0||hour>23)throw Error("Choose 5–480 study minutes and a valid reminder hour.");
    try{new Intl.DateTimeFormat("en",{timeZone:timezone}).format();}catch{throw Error("Choose a valid timezone.");}
    const days=(Date.parse(examDate)-Date.parse(dayInTimezone(timezone)))/86400000;
    if(days<0||days>365)throw Error("Choose an exam date within the next 365 days.");
    await db.prepare("INSERT INTO study_plans (owner,exam_date,daily_minutes,timezone,reminder_hour,updated_at) VALUES (?,?,?,?,?,?) ON CONFLICT(owner) DO UPDATE SET exam_date=excluded.exam_date,daily_minutes=excluded.daily_minutes,timezone=excluded.timezone,reminder_hour=excluded.reminder_hour,updated_at=excluded.updated_at").bind(owner,examDate,minutes,timezone,hour,now).run();return {ok:true};
  }
  const slug=String(body.topicSlug);await materialVersion(slug);
  const topicKey=key(owner,slug);
  await db.prepare("INSERT INTO learner_topics (key,owner,topic_slug,last_visited) VALUES (?,?,?,?) ON CONFLICT(key) DO NOTHING").bind(topicKey,owner,slug,now).run();
  if(body.action==="progress"){
    if(typeof body.completed!=="boolean"&&typeof body.bookmarked!=="boolean")throw Error("Choose a progress update.");
    if(typeof body.completed==="boolean")await db.prepare("UPDATE learner_topics SET completed = ? WHERE key = ? AND owner = ?").bind(body.completed?1:0,topicKey,owner).run();
    if(typeof body.bookmarked==="boolean")await db.prepare("UPDATE learner_topics SET bookmarked = ? WHERE key = ? AND owner = ?").bind(body.bookmarked?1:0,topicKey,owner).run();
  }else if(body.action==="visit"){
    if(!uuid(body.sessionId))throw Error("Invalid study session.");
    const seconds=Number(body.seconds);if(!Number.isInteger(seconds)||seconds<0||seconds>86400)throw Error("Invalid session time.");
    const sessionKey=key(owner,slug,body.sessionId);
    await db.batch([
      db.prepare("INSERT INTO learner_sessions (key,owner,topic_slug,seconds,updated_at) VALUES (?,?,?,?,?) ON CONFLICT(key) DO UPDATE SET seconds=MAX(learner_sessions.seconds,MIN(?,learner_sessions.seconds+90)),updated_at=excluded.updated_at").bind(sessionKey,owner,slug,Math.min(seconds,90),now,seconds),
      db.prepare("UPDATE learner_topics SET seconds=(SELECT COALESCE(SUM(seconds),0) FROM learner_sessions WHERE owner=? AND topic_slug=?),last_visited=? WHERE key=? AND owner=?").bind(owner,slug,now,topicKey,owner),
    ]);
  }else if(body.action==="video"){
    const id=String(body.videoId);const position=Number(body.position);const duration=Number(body.duration);
    if(!/^[\w-]{11}$/.test(id)||![position,duration].every(v=>Number.isFinite(v)&&v>=0&&v<=86400))throw Error("Invalid video progress.");
    await db.prepare("INSERT INTO video_watch (key,owner,topic_slug,video_id,position,duration,completed,updated_at) VALUES (?,?,?,?,?,?,?,?) ON CONFLICT(key) DO UPDATE SET position=excluded.position,duration=excluded.duration,completed=MAX(video_watch.completed,excluded.completed),updated_at=excluded.updated_at").bind(key(owner,slug,id),owner,slug,id,Math.floor(position),Math.floor(duration),duration>0&&position/duration>=.9?1:0,now).run();
  }else throw Error("Unknown learning action.");
  return {ok:true};
}
