import { recordAIUsage } from "./usage";
function apiKey() {
  const key = process.env.OPENAI_API_KEY;
  if (!key) throw new Error("OPENAI_API_KEY is not configured.");
  return key;
}

export async function openAIRequest<T>(path: string, init: RequestInit): Promise<T> {
  const response = await fetch(`https://api.openai.com/v1/${path}`, {
    ...init,
    signal:init.signal??AbortSignal.timeout(120_000),
    headers: {
      Authorization: `Bearer ${apiKey()}`,
      ...init.headers,
    },
  });
  const raw = await response.text();
  let usagePayload: {model?:string;usage?:{input_tokens?:number;output_tokens?:number;prompt_tokens?:number;total_tokens?:number}}={};
  try { usagePayload=JSON.parse(raw); } catch {}
  let requestedModel="unknown";
  try { requestedModel=JSON.parse(String(init.body)).model??"unknown"; } catch {}
  await recordAIUsage(path,usagePayload.model??requestedModel,response.status,usagePayload.usage);
  if (!response.ok) {
    let message = raw;
    try {
      const parsed = JSON.parse(raw) as { error?: { message?: string } };
      message = parsed.error?.message ?? raw;
    } catch {
      // Preserve the original API response when it is not JSON.
    }
    throw new Error(`OpenAI request failed (${response.status}): ${message.slice(0, 500)}`);
  }
  return JSON.parse(raw) as T;
}

export function responseOutputText(response: {
  output?: Array<{ content?: Array<{ type?: string; text?: string }> }>;
}) {
  for (const item of response.output ?? []) {
    for (const content of item.content ?? []) {
      if (content.type === "output_text" && content.text) return content.text;
    }
  }
  throw new Error("OpenAI returned no answer text.");
}

export async function createEmbeddings(inputs: string[]) {
  if (!inputs.length) return [];
  const response = await openAIRequest<{
    data: Array<{ index: number; embedding: number[] }>;
  }>("embeddings", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: process.env.OPENAI_EMBEDDING_MODEL || "text-embedding-3-small",
      input: inputs,
      encoding_format: "float",
    }),
  });
  return response.data.sort((a, b) => a.index - b.index).map((item) => item.embedding);
}

