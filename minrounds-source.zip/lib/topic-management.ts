export type TopicAction = { action: string };
export async function manageTopic(_body: TopicAction): Promise<{message:string}> {
  throw new Error("Topics follow Drive materials automatically. Rename the source file in Drive and sync; splitting and merging are disabled.");
}
