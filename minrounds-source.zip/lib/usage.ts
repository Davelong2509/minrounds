import {database} from "./saved-study";
export async function recordAIUsage(operation:string,model:string,status:number,usage?:{input_tokens?:number;output_tokens?:number;prompt_tokens?:number;total_tokens?:number}){
 const input=usage?.input_tokens??usage?.prompt_tokens??usage?.total_tokens??0;const output=usage?.output_tokens??0;
 const inRate=Number(process.env.OPENAI_INPUT_PRICE_PER_MILLION);const outRate=Number(process.env.OPENAI_OUTPUT_PRICE_PER_MILLION);const embedRate=Number(process.env.OPENAI_EMBEDDING_PRICE_PER_MILLION);
 const configured=operation==="embeddings"?Boolean(process.env.OPENAI_EMBEDDING_PRICE_PER_MILLION?.trim()):Boolean(process.env.OPENAI_INPUT_PRICE_PER_MILLION?.trim())&&Boolean(process.env.OPENAI_OUTPUT_PRICE_PER_MILLION?.trim());
 const cost=configured?Math.round(operation==="embeddings"?input*embedRate:input*inRate+output*outRate):null;
 try{await database().prepare("INSERT INTO usage_events (id,operation,model,input_tokens,output_tokens,status,cost_micros,created_at) VALUES (?,?,?,?,?,?,?,?)").bind(crypto.randomUUID(),operation,model,input,output,status,Number.isFinite(cost)?cost:null,new Date().toISOString()).run();}catch{/* Usage logging must never discard a paid, successfully generated answer. */}
}
