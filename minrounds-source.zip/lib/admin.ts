import type { ChatGPTUser } from "@/app/chatgpt-auth";

export function isIngestionAdmin(user: ChatGPTUser | null) {
  if (!user) return false;
  const configuredEmail = process.env.ADMIN_EMAIL?.trim().toLowerCase();
  return Boolean(configuredEmail && user.email.toLowerCase() === configuredEmail);
}
