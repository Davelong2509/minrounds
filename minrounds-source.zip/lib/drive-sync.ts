import { discoverDriveFiles, discoverDriveCourses, type DriveFile } from "./google-drive";
import { ensurePsychiatryCourse, supabaseRequest, verifyDatabaseSchema } from "./supabase";

import {syncCourseVideos} from "./video-discovery";
import {registerCourseFolder,hideMissingCourseFolders} from "./courses";

type ExistingDocument = {
  id: string;
  source_file_id: string;
  source_version: string | null;
  title: string;
};

function extensionFor(file: DriveFile) {
  if (file.fileExtension) return file.fileExtension.toLowerCase();
  const dot = file.name.lastIndexOf(".");
  return dot > -1 ? file.name.slice(dot + 1).toLowerCase() : null;
}

function typeFor(file: DriveFile) {
  const text = `${file.name} ${file.mimeType}`.toLowerCase();
  if (/past[ _-]?question|\bexams?\b|exam(?:ination)?[ _-]+(?:paper|questions?)|question[ _-]+paper/.test(text)) return "past_question";
  if (/textbook|handbook|manual/.test(text)) return "textbook";
  if (/slide|powerpoint|presentation|lecture/.test(text)) return "slide";
  if (/note|handout|summary/.test(text)) return "note";
  return "other";
}

function versionFor(file: DriveFile) {
  return file.version || file.modifiedTime || null;
}

function payloadFor(file: DriveFile, courseId: string) {
  return {
    course_id: courseId,
    source_provider: "google_drive",
    source_file_id: file.id,
    source_version: versionFor(file),
    source_url: file.webViewLink || `https://drive.google.com/open?id=${encodeURIComponent(file.id)}`,
    checksum_sha256: null,
    title: file.name,
    mime_type: file.mimeType,
    file_extension: extensionFor(file),
    document_type: typeFor(file),
    is_handwritten: false,
    updated_at: new Date().toISOString(),
  };
}

async function inBatches<T>(items: T[], batchSize: number, operation: (item: T) => Promise<void>) {
  for (let index = 0; index < items.length; index += batchSize) {
    await Promise.all(items.slice(index, index + batchSize).map(operation));
  }
}

export async function syncDriveDocuments() {
  const schema = await verifyDatabaseSchema();
  if (!schema.ready) {
    throw new Error(
      "The Supabase schema is not ready. Apply database/migrations/0001_foundation.sql first.",
    );
  }

  const rootId=process.env.GOOGLE_DRIVE_ROOT_FOLDER_ID;
  if(!rootId){const id=await ensurePsychiatryCourse();const result=await syncCourseFiles(id,await discoverDriveFiles());return {...result,videos:await syncCourseVideos([id])};}
  const scan=await discoverDriveCourses(rootId);
  const courses=[];const failures:Array<{course:string;error:string}>=[];
  for(const entry of scan.courses){
    try{
      const course=await registerCourseFolder(entry.folder);
      if(entry.error)throw Error(entry.error);
      courses.push({...course,...await syncCourseFiles(course.id,entry.files)});
    }catch(e){failures.push({course:entry.folder.name,error:e instanceof Error?e.message:"Course sync failed."});}
  }
  await hideMissingCourseFolders(scan.courses.map(c=>c.folder.id));
  const videos=await syncCourseVideos(courses.map(c=>c.id));
  return {videos,discovered:courses.reduce((n,c)=>n+c.discovered,0),registered:courses.reduce((n,c)=>n+c.registered,0),refreshed:courses.reduce((n,c)=>n+c.refreshed,0),unchanged:courses.reduce((n,c)=>n+c.unchanged,0),courses,failures,ignoredRootFiles:scan.ignoredRootFiles};
}

async function syncCourseFiles(courseId:string,files:DriveFile[]){
  const { data: existing } = await supabaseRequest<ExistingDocument[]>(
    `documents?select=id,source_file_id,source_version,title&source_provider=eq.google_drive&course_id=eq.${courseId}&limit=10000`,
  );
  const byFileId = new Map(existing.map((document) => [document.source_file_id, document]));
  const fresh = files.filter((file) => !byFileId.has(file.id));
  const changed = files.filter((file) => {
    const previous = byFileId.get(file.id);
    return previous && (previous.source_version !== versionFor(file) || previous.title !== file.name);
  });

  for (let index = 0; index < fresh.length; index += 100) {
    const batch = fresh.slice(index, index + 100).map((file) => ({
      ...payloadFor(file, courseId),
      processing_status: "discovered",
    }));
    if (!batch.length) continue;
    await supabaseRequest<unknown>("documents", {
      method: "POST",
      headers: { Prefer: "return=minimal" },
      body: JSON.stringify(batch),
    });
  }

  await inBatches(changed, 8, async (file) => {
    await supabaseRequest<unknown>(
      `documents?source_provider=eq.google_drive&course_id=eq.${courseId}&source_file_id=eq.${encodeURIComponent(file.id)}`,
      {
        method: "PATCH",
        headers: { Prefer: "return=minimal" },
        body: JSON.stringify({
          ...payloadFor(file, courseId),
          processing_status: "discovered",
          processing_error: null,
          processed_at: null,
        }),
      },
    );
  });

  return {
    discovered: files.length,
    registered: fresh.length,
    refreshed: changed.length,
    unchanged: files.length - fresh.length - changed.length,
  };
}
