import { downloadDriveFile } from "./google-drive";
import { extractDocument } from "./openai-extraction";
import { createEmbeddings } from "./openai-api";
import { extractLocalDocument } from "./local-extraction";
import { supabaseRequest } from "./supabase";
import {activeCourseFilter,documentCourse} from "./courses";

type PendingDocument = {
  id: string;
  course_id: string;
  source_file_id: string;
  title: string;
  mime_type: string;
  file_extension: string | null;
  processing_status: string;
  updated_at: string;
};

function slugify(value: string) {
  return value
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 80);
}

function chunks(text: string, size = 1800, overlap = 180) {
  const normalized = text.replace(/\s+/g, " ").trim();
  if (!normalized) return [];
  const result: string[] = [];
  let start = 0;
  while (start < normalized.length) {
    let end = Math.min(start + size, normalized.length);
    if (end < normalized.length) {
      const boundary = normalized.lastIndexOf(" ", end);
      if (boundary > start + size * 0.65) end = boundary;
    }
    result.push(normalized.slice(start, end));
    if (end >= normalized.length) break;
    start = Math.max(end - overlap, start + 1);
  }
  return result;
}

async function ensureMaterialTopic(document: PendingDocument) {
  const slug = `material-${document.id}`;
  const { data } = await supabaseRequest<Array<{ id: string; slug: string }>>("topics?on_conflict=course_id,slug&select=id,slug", {
    method: "POST", headers: { Prefer: "resolution=merge-duplicates,return=representation" },
    body: JSON.stringify({course_id:document.course_id, canonical_name:document.title, slug,
      status:"approved", created_by:"admin", description:null}),
  });
  if (!data[0]) throw new Error("Material topic could not be registered.");
  await supabaseRequest("topic_documents?on_conflict=topic_id,document_id", {
    method:"POST", headers:{Prefer:"resolution=merge-duplicates,return=minimal"},
    body:JSON.stringify({topic_id:data[0].id,document_id:document.id,confidence:1,assignment_source:"admin"}),
  });
  return data[0];
}

async function ensureConcept(input: { name: string; description?: string }) {
  const slug = slugify(input.name);
  if (!slug) return null;
  const { data: existing } = await supabaseRequest<Array<{ id: string }>>(
    `concepts?select=id&slug=eq.${encodeURIComponent(slug)}&limit=1`,
  );
  if (existing[0]) return existing[0];
  const { data: created } = await supabaseRequest<Array<{ id: string }>>("concepts?select=id", {
    method: "POST",
    headers: { Prefer: "return=representation" },
    body: JSON.stringify({
      canonical_name: input.name.trim(),
      slug,
      description: input.description?.trim() || null,
    }),
  });
  return created[0] ?? null;
}

export async function embedPendingChunks(limit = 96) {
  const safeLimit = Math.max(1, Math.min(96, Math.floor(limit)));
  const { data: pending } = await supabaseRequest<Array<{ id: string; content: string }>>(
    `document_chunks?select=id,content&embedding=is.null&order=created_at.asc&limit=${safeLimit}`,
  );
  if (!pending.length) return { done: true, embedded: 0 };
  const embeddings = await createEmbeddings(pending.map((chunk) => chunk.content));
  for (let index = 0; index < pending.length; index += 1) {
    await supabaseRequest<unknown>(`document_chunks?id=eq.${encodeURIComponent(pending[index].id)}`, {
      method: "PATCH",
      headers: { Prefer: "return=minimal" },
      body: JSON.stringify({ embedding: embeddings[index] }),
    });
  }
  return { done: pending.length < safeLimit, embedded: pending.length };
}

async function markFailed(documentId: string, error: unknown) {
  const message = error instanceof Error ? error.message : "Document processing failed.";
  await supabaseRequest<unknown>(`documents?id=eq.${encodeURIComponent(documentId)}`, {
    method: "PATCH",
    headers: { Prefer: "return=minimal" },
    body: JSON.stringify({
      processing_status: "failed",
      processing_error: message.slice(0, 1500),
      updated_at: new Date().toISOString(),
    }),
  });
}

export async function processNextDocument() {
  const courseFilter=await activeCourseFilter();
  const stale=new Date(Date.now()-15*60_000).toISOString();
  await supabaseRequest(`documents?${courseFilter}&processing_status=eq.processing&updated_at=lt.${stale}`,{method:"PATCH",headers:{Prefer:"return=minimal"},body:JSON.stringify({processing_status:"discovered",processing_error:null,updated_at:new Date().toISOString()})});
  return processDocument(undefined,{skipEmbeddings:true});
}

export async function processDocument(documentId?: string, options: {skipEmbeddings?: boolean;localOnly?:boolean} = {}) {
  const courseFilter=await activeCourseFilter();
  if(documentId&&!await documentCourse(documentId))throw Error("This material is not part of an active course.");
  const { data: pending } = await supabaseRequest<PendingDocument[]>(
    `documents?select=id,course_id,source_file_id,title,mime_type,file_extension,processing_status,updated_at&${documentId ? `id=eq.${encodeURIComponent(documentId)}` : "processing_status=eq.discovered"}&${courseFilter}&order=discovered_at.asc&limit=1`,
  );
  const document = pending[0];
  if (!document) return { done: true, processed: null };
  if (document.processing_status === "processing" && Date.now()-Date.parse(document.updated_at)<15*60_000) {
    return {done:false, skipped:true, processed:null};
  }

  const { data: claimed } = await supabaseRequest<PendingDocument[]>(
    `documents?id=eq.${encodeURIComponent(document.id)}&processing_status=eq.${document.processing_status}&updated_at=eq.${encodeURIComponent(document.updated_at)}&select=id,course_id,source_file_id,title,mime_type,file_extension`,
    {
      method: "PATCH",
      headers: { Prefer: "return=representation" },
      body: JSON.stringify({ processing_status: "processing", processing_error: null, updated_at:new Date().toISOString() }),
    },
  );
  if (!claimed.length) return { done: false, skipped: true, processed: null };

  try {
    const downloaded = await downloadDriveFile({
      id: document.source_file_id,
      name: document.title,
      mimeType: document.mime_type,
      fileExtension: document.file_extension ?? undefined,
    });
    let extraction=await extractLocalDocument(downloaded);
    const native=Boolean(extraction);
    if(!extraction){
      if(options.localOnly)throw Error("This material requires PDF or image extraction through OpenAI. Local preparation did not send it to OpenAI.");
      extraction=await extractDocument({...downloaded,title:document.title});
    }

    if (!extraction.pages.some(page=>page.text.trim()) && !extraction.summary.trim()) {
      throw new Error("No readable text was found in this material. Check the original file or upload a readable PDF.");
    }
    await supabaseRequest<unknown>(`document_chunks?document_id=eq.${encodeURIComponent(document.id)}`, {
      method:"DELETE", headers:{Prefer:"return=minimal"},
    });
    await supabaseRequest<unknown>(`document_pages?document_id=eq.${encodeURIComponent(document.id)}`, {
      method: "DELETE",
      headers: { Prefer: "return=minimal" },
    });
    const seenPageNumbers = new Set<number>();
    const pagePayload = (extraction.pages.length ? extraction.pages : [{ page_number: 1, text: extraction.summary }])
      .filter((page) => page.text.trim())
      .map((page, index) => {
        let pageNumber = page.page_number > 0 ? page.page_number : index + 1;
        while (seenPageNumbers.has(pageNumber)) pageNumber += 1;
        seenPageNumbers.add(pageNumber);
        return {
        document_id: document.id,
        page_number: pageNumber,
        slide_number: extraction.document_type === "slide" ? pageNumber : null,
        extracted_text: page.text.trim(),
        extraction_method: native ? "native" : document.mime_type.startsWith("image/") ? "vision" : "hybrid",
        extraction_confidence: null,
        is_image_only: document.mime_type.startsWith("image/"),
      }});
    const { data: pages } = await supabaseRequest<Array<{ id: string; page_number: number; extracted_text: string }>>(
      "document_pages?select=id,page_number,extracted_text",
      {
        method: "POST",
        headers: { Prefer: "return=representation" },
        body: JSON.stringify(pagePayload),
      },
    );

    let chunkIndex = 0;
    const chunkPayload = pages.flatMap((page) =>
      chunks(page.extracted_text).map((content) => ({
        document_id: document.id,
        document_page_id: page.id,
        chunk_index: chunkIndex++,
        content,
        token_count: Math.ceil(content.length / 4),
      })),
    );
    for (let index = 0; index < chunkPayload.length; index += 100) {
      await supabaseRequest<unknown>("document_chunks", {
        method: "POST",
        headers: { Prefer: "return=minimal" },
        body: JSON.stringify(chunkPayload.slice(index, index + 100)),
      });
    }
    if (!options.skipEmbeddings) try {
      const chunkEmbeddings = await createEmbeddings(chunkPayload.map((chunk) => chunk.content));
      for (let index = 0; index < chunkPayload.length; index += 1) {
        const chunk = chunkPayload[index];
        await supabaseRequest<unknown>(
          `document_chunks?document_id=eq.${encodeURIComponent(document.id)}&chunk_index=eq.${chunk.chunk_index}`,
          {
            method: "PATCH",
            headers: { Prefer: "return=minimal" },
            body: JSON.stringify({ embedding: chunkEmbeddings[index] }),
          },
        );
      }
    } catch {
      // Document extraction remains valid; the admin can retry semantic indexing independently.
    }

    const materialTopic = await ensureMaterialTopic(document);
    const conceptsBySlug = new Map<string, string>();
    for (const concept of extraction.concepts.slice(0, 30)) {
      const saved = await ensureConcept({ name: concept.name, description: concept.description });
      if (!saved) continue;
      const conceptSlug = slugify(concept.name);
      conceptsBySlug.set(conceptSlug, saved.id);
      await supabaseRequest<unknown>("course_concepts?on_conflict=course_id,concept_id", {
        method: "POST",
        headers: { Prefer: "resolution=ignore-duplicates,return=minimal" },
        body: JSON.stringify({ course_id: document.course_id, concept_id: saved.id }),
      });
      const relatedTopicIds = [materialTopic.id];
      if (relatedTopicIds.length) {
        await supabaseRequest<unknown>("topic_concepts?on_conflict=topic_id,concept_id", {
          method: "POST",
          headers: { Prefer: "resolution=ignore-duplicates,return=minimal" },
          body: JSON.stringify(relatedTopicIds.map((topicId) => ({
            topic_id: topicId,
            concept_id: saved.id,
            confidence: Math.max(0, Math.min(1, concept.confidence)),
            assignment_source: "admin",
          }))),
        });
      }
    }

    let indexedQuestions = 0;
    if (extraction.is_past_question || extraction.questions.length) {
      const { data: papers } = await supabaseRequest<Array<{ id: string }>>(
        "past_question_papers?on_conflict=document_id&select=id",
        {
          method: "POST",
          headers: { Prefer: "resolution=merge-duplicates,return=representation" },
          body: JSON.stringify({
            course_id: document.course_id,
            document_id: document.id,
            exam_year: extraction.past_paper.exam_year,
            session_name: extraction.past_paper.session_name.trim() || null,
            institution: extraction.past_paper.institution.trim() || null,
            answer_key_available: extraction.past_paper.answer_key_available,
          }),
        },
      );
      const paperId = papers[0]?.id;
      if (!paperId) throw new Error("The past-question paper could not be registered.");

      const {data:oldQuestions}=await supabaseRequest<Array<{id:string;question_number:string|null;question_text:string}>>(`past_questions?select=id,question_number,question_text&paper_id=eq.${paperId}`);
      const {data:oldAdminLinks}=oldQuestions.length?await supabaseRequest<Array<{question_id:string;topic_id:string;relation_role:string;confidence:number|null}>>(`past_question_topics?select=question_id,topic_id,relation_role,confidence&assignment_source=eq.admin&question_id=in.(${oldQuestions.map(q=>q.id).join(",")})`):{data:[]};
      await supabaseRequest<unknown>(`past_questions?paper_id=eq.${encodeURIComponent(paperId)}`, {
        method: "DELETE",
        headers: { Prefer: "return=minimal" },
      });
      const pageIds = new Map(pages.map((page) => [page.page_number, page.id]));

      for (const question of extraction.questions.slice(0, 80)) {
        if (!question.question_text.trim()) continue;
        const { data: createdQuestions } = await supabaseRequest<Array<{ id: string }>>(
          "past_questions?select=id",
          {
            method: "POST",
            headers: { Prefer: "return=representation" },
            body: JSON.stringify({
              paper_id: paperId,
              source_page_id: pageIds.get(question.page_number) ?? null,
              question_number: question.question_number.trim() || null,
              question_text: question.question_text.trim(),
              question_type: question.question_type,
              official_answer: question.official_answer?.trim() || null,
              ai_explanation: question.explanation?.trim() || null,
              extraction_confidence: Math.max(0, Math.min(1, question.confidence)),
            }),
          },
        );
        const questionId = createdQuestions[0]?.id;
        if (!questionId) continue;
        indexedQuestions += 1;

        const options = question.options
          .filter((option) => option.text.trim())
          .map((option, index) => ({
            question_id: questionId,
            option_key: option.key.trim() || null,
            option_text: option.text.trim(),
            is_officially_correct: option.is_correct,
            display_order: index,
          }));
        if (options.length) {
          await supabaseRequest<unknown>("past_question_options", {
            method: "POST",
            headers: { Prefer: "return=minimal" },
            body: JSON.stringify(options),
          });
        }

        const topicIds = [materialTopic.id];
        if (topicIds.length) {
          await supabaseRequest<unknown>("past_question_topics", {
            method: "POST",
            headers: { Prefer: "return=minimal" },
            body: JSON.stringify(topicIds.map((topicId, index) => ({
              question_id: questionId,
              topic_id: topicId,
              relation_role: index === 0 ? "primary" : "secondary",
              confidence: Math.max(0, Math.min(1, question.confidence)),
              assignment_source: "admin",
            }))),
          });
        }
        const previous=oldQuestions.find(q=>q.question_text.trim()===question.question_text.trim() && (q.question_number??"")===(question.question_number.trim()||""));
        const preserved=oldAdminLinks.filter(l=>l.question_id===previous?.id && l.topic_id===materialTopic.id);
        if(preserved.length) await supabaseRequest<unknown>("past_question_topics?on_conflict=question_id,topic_id",{method:"POST",headers:{Prefer:"resolution=merge-duplicates,return=minimal"},body:JSON.stringify(preserved.map(l=>({...l,question_id:questionId,assignment_source:"admin"})))});
        const conceptIds: string[] = [];
        for (const conceptName of question.concept_names.slice(0, 5)) {
          const conceptSlug = slugify(conceptName);
          let conceptId = conceptsBySlug.get(conceptSlug);
          if (!conceptId) {
            const concept = await ensureConcept({ name: conceptName });
            conceptId = concept?.id;
            if (conceptId) conceptsBySlug.set(conceptSlug, conceptId);
          }
          if (conceptId && !conceptIds.includes(conceptId)) conceptIds.push(conceptId);
        }
        if (conceptIds.length) {
          await supabaseRequest<unknown>("course_concepts?on_conflict=course_id,concept_id", {
            method: "POST",
            headers: { Prefer: "resolution=ignore-duplicates,return=minimal" },
            body: JSON.stringify(conceptIds.map((conceptId) => ({ course_id: document.course_id, concept_id: conceptId }))),
          });
          await supabaseRequest<unknown>("past_question_concepts", {
            method: "POST",
            headers: { Prefer: "return=minimal" },
            body: JSON.stringify(conceptIds.map((conceptId) => ({
              question_id: questionId,
              concept_id: conceptId,
              confidence: Math.max(0, Math.min(1, question.confidence)),
            }))),
          });
        }
      }
    } else {
      await supabaseRequest<unknown>(`past_question_papers?document_id=eq.${encodeURIComponent(document.id)}`, {
        method: "DELETE",
        headers: { Prefer: "return=minimal" },
      });
    }

    await supabaseRequest<unknown>(`documents?id=eq.${encodeURIComponent(document.id)}`, {
      method: "PATCH",
      headers: { Prefer: "return=minimal" },
      body: JSON.stringify({
        document_type: extraction.document_type,
        processing_status: "ready",
        processing_error: null,
        processed_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      }),
    });

    return {
      done: false,
      processed: { id: document.id, title: document.title, pages: pages.length, chunks: chunkPayload.length, topics: 1, concepts: extraction.concepts.length, questions: indexedQuestions },
    };
  } catch (error) {
    await markFailed(document.id, error);
    throw error;
  }
}

export async function approveSuggestedTopic(_topicId: string): Promise<never> {
  throw new Error("Every Drive material is already a topic. Topic suggestions are disabled.");
}
