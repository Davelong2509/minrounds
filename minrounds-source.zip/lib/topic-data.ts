import { getPsychiatryCourseId, supabaseRequest } from "./supabase";

export type TopicRecord = { id: string; course_id: string; canonical_name: string; slug: string; description: string | null; status: string; created_by: string; merged_into_topic_id: string | null };
export type TopicDocument = { id: string; title: string; source_url: string | null; document_type: string; processing_status: string };
export type TopicConcept = { id: string; canonical_name: string; description: string | null; slug: string };
export type TopicQuestion = { id: string; paper_id: string; source_page_id: string | null; question_number: string | null; question_text: string; question_type: string; official_answer: string | null; ai_explanation: string | null };
export type TopicPaper = { id: string; document_id: string; exam_year: number | null; session_name: string | null };
export type TopicGraph = Awaited<ReturnType<typeof getTopicGraph>>;

import {documentCourse} from "./courses";

export async function getStoredTopicGraph(selectedCourseId?:string) {
  const courseId = selectedCourseId ?? await getPsychiatryCourseId();
  if (!courseId) throw new Error("The Psychiatry course has not been initialized.");
  const courseFilter = `course_id=eq.${courseId}`;
  const [topics, documents, papers, courseConcepts] = await Promise.all([
    supabaseRequest<TopicRecord[]>(`topics?select=*&${courseFilter}&order=canonical_name.asc`),
    supabaseRequest<TopicDocument[]>(`documents?select=id,title,source_url,document_type,processing_status&${courseFilter}&order=title.asc`),
    supabaseRequest<TopicPaper[]>(`past_question_papers?select=id,document_id,exam_year,session_name&${courseFilter}`),
    supabaseRequest<Array<{ concept_id: string }>>(`course_concepts?select=concept_id&${courseFilter}`),
  ]);
  const topicIds = topics.data.map(t => t.id);
  const paperIds = papers.data.map(p => p.id);
  const conceptIds = courseConcepts.data.map(c => c.concept_id);
  const [documentLinks, conceptLinks, questionLinks, concepts, questions, pages] = await Promise.all([
    topicIds.length ? supabaseRequest<Array<{ topic_id: string; document_id: string; confidence: number | null; assignment_source: string }>>(`topic_documents?select=*&topic_id=in.(${topicIds.join(",")})`) : { data: [] },
    topicIds.length ? supabaseRequest<Array<{ topic_id: string; concept_id: string; assignment_source: string }>>(`topic_concepts?select=*&topic_id=in.(${topicIds.join(",")})`) : { data: [] },
    topicIds.length ? supabaseRequest<Array<{ topic_id: string; question_id: string; assignment_source: string }>>(`past_question_topics?select=*&topic_id=in.(${topicIds.join(",")})`) : { data: [] },
    conceptIds.length ? supabaseRequest<TopicConcept[]>(`concepts?select=id,canonical_name,description,slug&id=in.(${conceptIds.join(",")})&order=canonical_name.asc`) : { data: [] },
    paperIds.length ? supabaseRequest<TopicQuestion[]>(`past_questions?select=*&paper_id=in.(${paperIds.join(",")})&order=created_at.asc`) : { data: [] },
    documents.data.length ? supabaseRequest<Array<{ id: string; document_id: string; page_number: number }>>(`document_pages?select=id,document_id,page_number&document_id=in.(${documents.data.map(d => d.id).join(",")})&order=page_number.asc`) : { data: [] },
  ]);
  return { courseId, topics: topics.data, documents: documents.data, papers: papers.data, concepts: concepts.data, questions: questions.data, pages: pages.data, documentLinks: documentLinks.data, conceptLinks: conceptLinks.data, questionLinks: questionLinks.data };
}

// Material identity is independent of AI classification, filenames and processing status.
export function materialTopicSlug(documentId: string) { return `material-${documentId}`; }

export function materialGraph(graph: Awaited<ReturnType<typeof getStoredTopicGraph>>) {
  const topics: TopicRecord[] = graph.documents.map(d => ({
    id: d.id, course_id: graph.courseId, canonical_name: d.title,
    slug: materialTopicSlug(d.id), description: null, status: "approved",
    created_by: "admin", merged_into_topic_id: null,
  }));
  const conceptLinks = graph.documents.flatMap(d => {
    // Prefer the explicit material assignment created by current ingestion.
    const material = graph.topics.find(t => t.slug === materialTopicSlug(d.id));
    const ids = new Set(material ? [material.id] : graph.documentLinks.filter(l => l.document_id === d.id).map(l => l.topic_id));
    const concepts = new Set(graph.conceptLinks.filter(l => ids.has(l.topic_id)).map(l => l.concept_id));
    return [...concepts].map(concept_id => ({topic_id:d.id, concept_id, assignment_source:"admin"}));
  });
  const questionLinks = graph.questions.flatMap(q => {
    const paper = graph.papers.find(p => p.id === q.paper_id);
    return paper ? [{topic_id:paper.document_id, question_id:q.id, assignment_source:"admin"}] : [];
  });
  return {...graph, topics, conceptLinks, questionLinks,
    documentLinks: graph.documents.map(d => ({topic_id:d.id, document_id:d.id, confidence:1, assignment_source:"admin"})),
  };
}

export async function getTopicGraph(courseId?:string) { return materialGraph(await getStoredTopicGraph(courseId)); }

export function topicFromGraph(graph: TopicGraph, topic: TopicRecord) {
  const documents = graph.documents.filter(d => d.id === topic.id);
  const concepts = graph.concepts.filter(c => graph.conceptLinks.some(r => r.topic_id === topic.id && r.concept_id === c.id));
  const questions = graph.questions.filter(q => graph.questionLinks.some(r => r.topic_id === topic.id && r.question_id === q.id));
  const years = [...new Set(questions.map(q => graph.papers.find(p => p.id === q.paper_id)?.exam_year).filter((year): year is number => typeof year === "number"))].sort((a,b) => b-a);
  return { topic, documents, concepts, questions, years, papers: graph.papers, pages: graph.pages, sourceDocuments: graph.documents };
}

export async function getTopicDetail(slug: string, courseId?:string) {
  if(!courseId&&/^material-[0-9a-f-]{36}$/.test(slug)){const course=await documentCourse(slug.slice(9));if(!course)return null;courseId=course.id;}
  const graph = await getTopicGraph(courseId);
  const topic = graph.topics.find(t => t.slug === slug);
  return topic ? topicFromGraph(graph, topic) : null;
}
