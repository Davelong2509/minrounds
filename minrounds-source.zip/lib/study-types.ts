export const STUDY_MODES = ["overview", "teach", "summary", "guide", "mcqs", "flashcards"] as const;
export type StudyMode = typeof STUDY_MODES[number];
export type StudyMCQ = {question:string;options:string[];correct_index:number;explanation:string;source_numbers:number[]};
export type StudyFlashcard = {front:string;back:string;source_numbers:number[]};
export const STUDY_INSTRUCTIONS: Record<StudyMode,string> = {
  overview:"Give a clear overview of this material: its purpose, main ideas, and learning objectives. Use headings and short paragraphs with citations.",
  teach:"Teach the material progressively. Explain key terms, then mechanisms and clinical applications supported by the source. Use a worked example when supported. End with three recall questions and their answers. Cite each section.",
  summary:"Summarize this material's key facts and distinctions concisely. Use useful headings and bullet points, with citations.",
  guide:"Build a practical study guide for this material with learning objectives, key concepts, source-supported clinical facts, a suggested revision sequence, and recall questions. Cite each section. Include historical examination coverage only when records supply it.",
  mcqs:"Generate 5 new practice MCQs drawn from different concepts in this material. Each needs exactly 4 plausible options, one correct_index (0–3), an explanation, and supporting source_numbers. These are AI-generated study questions, never official exam answers. Put them in mcqs. Use a short introduction in answer.",
  flashcards:"Generate 8 concise question-and-answer flashcards covering different concepts in this material. Put the question in front, the answer in back, and supporting citations in source_numbers. Put them in flashcards. Use a short introduction in answer.",
};
