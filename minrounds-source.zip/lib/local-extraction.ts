import {unzipSync,strFromU8} from "fflate";
import {getDocumentProxy} from "unpdf";
import type {ExtractedDocument} from "./openai-extraction";
function decode(text:string){return text.replace(/&(?:amp|lt|gt|quot|apos|#\d+|#x[0-9a-f]+);/gi,value=>{const key=value.slice(1,-1);const named:Record<string,string>={amp:"&",lt:"<",gt:">",quot:'"',apos:"'"};if(named[key])return named[key];const code=key.startsWith("#x")?parseInt(key.slice(2),16):parseInt(key.slice(1),10);return Number.isFinite(code)&&code<=0x10ffff?String.fromCodePoint(code):value;});}
function paragraphs(xml:string,prefix:"a"|"w"){return [...xml.matchAll(new RegExp(`<${prefix}:p(?:\\s[^>]*)?>[\\s\\S]*?</${prefix}:p>`,"g"))].map(p=>[...p[0].matchAll(new RegExp(`<${prefix}:t(?:\\s[^>]*)?>([\\s\\S]*?)</${prefix}:t>`,"g"))].map(t=>decode(t[1])).join("")).filter(Boolean).join("\n");}
export async function extractLocalDocument(input:{blob:Blob;filename:string}):Promise<ExtractedDocument|null>{
 if(/past[ _-]?question|\bexams?\b|exam(?:ination)?[ _-]+(?:paper|questions?)|question[ _-]+paper/i.test(input.filename))return null;
 const ext=input.filename.split(".").pop()?.toLowerCase();
 if(ext==="pdf"){
   const pdf=await getDocumentProxy(new Uint8Array(await input.blob.arrayBuffer()),{useSystemFonts:false});
   try{
    if(pdf.numPages>1000)throw Error("This PDF exceeds the current 1000-page processing limit.");
    const pages:Array<{page_number:number;text:string}>=[];let total=0;
    for(let number=1;number<=pdf.numPages;number++){
     const page=await pdf.getPage(number);const content=await page.getTextContent();let text="";
     for(const item of content.items){if("str" in item)text+=item.str+(item.hasEOL?"\n":" ");}
     page.cleanup();total+=text.length;if(total>10*1024*1024)throw Error("PDF text exceeds the safe extraction limit.");
     if(text.trim())pages.push({page_number:number,text:text.trim()});
    }
    if(!pages.length)return null;
    return {summary:"",document_type:/textbook|handbook/i.test(input.filename)?"textbook":"note",is_past_question:false,pages,topics:[],concepts:[],questions:[],past_paper:{exam_year:null,session_name:"",institution:"",answer_key_available:false}};
   }finally{await pdf.loadingTask.destroy();}
 }
 if(/past[ _-]?question|\bexams?\b|exam(?:ination)?[ _-]+(?:paper|questions?)|question[ _-]+paper/i.test(input.filename))return null;
 const extension=input.filename.split(".").pop()?.toLowerCase();if(extension!=="pptx"&&extension!=="docx")return null;
 const bytes=new Uint8Array(await input.blob.arrayBuffer());let expanded=0;
 const files=unzipSync(bytes,{filter:file=>{const selected=/^(ppt\/slides\/slide\d+\.xml|ppt\/presentation\.xml|ppt\/_rels\/presentation\.xml\.rels|word\/document\.xml)$/.test(file.name);if(selected){expanded+=file.originalSize;if(expanded>24*1024*1024)throw Error("Material text exceeds the safe extraction limit.");}return selected;}});
 const pages:Array<{page_number:number;text:string}>=[];
 if(extension==="pptx"){
  let names=Object.keys(files).filter(n=>/^ppt\/slides\/slide\d+\.xml$/.test(n)).sort((a,b)=>Number(a.match(/slide(\d+)/)?.[1])-Number(b.match(/slide(\d+)/)?.[1]));
  const presentation=files["ppt/presentation.xml"],relations=files["ppt/_rels/presentation.xml.rels"];
  if(presentation&&relations){const targets=new Map<string,string>();for(const relation of strFromU8(relations).matchAll(/<Relationship\b([^>]+)\/?\s*>/g)){const id=relation[1].match(/\bId="([^"]+)"/)?.[1],target=relation[1].match(/\bTarget="([^"]+)"/)?.[1];if(id&&target)targets.set(id,target.startsWith("/")?target.slice(1):`ppt/${target}`);}
   const ordered=[...strFromU8(presentation).matchAll(/<p:sldId\b[^>]*\br:id="([^"]+)"[^>]*\/?\s*>/g)].map(m=>targets.get(m[1])).filter((n):n is string=>!!n&&!!files[n]);if(ordered.length===names.length)names=ordered;
  }
  names.forEach((name,index)=>{const text=paragraphs(strFromU8(files[name]),"a");if(text.trim())pages.push({page_number:index+1,text});});
 }else if(files["word/document.xml"]){const text=paragraphs(strFromU8(files["word/document.xml"]),"w");if(text.trim())pages.push({page_number:1,text});}
 if(!pages.length)return null;
 return {summary:"",document_type:extension==="pptx"?"slide":"note",is_past_question:false,pages,topics:[],concepts:[],questions:[],past_paper:{exam_year:null,session_name:"",institution:"",answer_key_available:false}};
}
