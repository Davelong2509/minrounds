import {database} from "./saved-study";
export async function allowStudyRequest(request:Request,operation:string,limit=8){
 const actor=request.headers.get("oai-authenticated-user-id")||request.headers.get("cf-connecting-ip")||"anonymous";const now=Date.now();const db=database();
 const windows=[{key:JSON.stringify([operation,actor,"minute",Math.floor(now/60000)]),expires:now+120000,limit}];
 if(operation==="answer")windows.push({key:JSON.stringify([operation,actor,"day",Math.floor(now/86400000)]),expires:now+2*86400000,limit:Math.max(1,Number(process.env.STUDY_DAILY_LIMIT)||100)});
 const results=await db.batch(windows.map(w=>db.prepare("INSERT INTO request_limits (key,count,expires_at) VALUES (?,1,?) ON CONFLICT(key) DO UPDATE SET count=request_limits.count+1 WHERE request_limits.count < ? RETURNING count").bind(w.key,w.expires,w.limit)));
 return results.every(r=>r.results.length>0);
}
