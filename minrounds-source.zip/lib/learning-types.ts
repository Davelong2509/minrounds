import type { StudyFlashcard, StudyMCQ } from "./study-types";
export type Progress = {topic_slug:string;completed:number;bookmarked:number;seconds:number;last_visited:string};
export type Attempt = {id:string;result_id:string;topic_slug:string;mode:string;answers_json:string;correct:number;total:number;seconds:number;created_at:string};
export type Review = {result_id:string;card_index:number;interval_days:number;repetitions:number;grade:string;due_at:string;updated_at:string};
export type Deck = {id:string;topicSlug:string;createdAt:string;cards:StudyFlashcard[];mcqs:StudyMCQ[]};
export type Plan = {exam_date:string;daily_minutes:number;timezone:string;reminder_hour:number};
export type LearningData = {signedIn:boolean;progress:Progress[];attempts:Attempt[];reviews:Review[];decks:Deck[];plan:Plan|null;totals:{correct:number;questions:number;attempts:number};watches:Array<{video_id:string;position:number;duration:number;completed:number}>};
export type CardGrade = "again"|"hard"|"good"|"easy";
export function nextCardReview(previous:{interval_days:number;repetitions:number}|null,grade:CardGrade,now=Date.now()) {
  let interval=previous?.interval_days??0;
  let repetitions=previous?.repetitions??0;
  if(grade==="again"){interval=0;repetitions=0;}
  else if(grade==="hard"){interval=Math.max(1,Math.ceil(interval*1.2));repetitions++;}
  else if(grade==="good"){interval=repetitions===0?1:repetitions===1?3:Math.max(1,Math.ceil(interval*2));repetitions++;}
  else {interval=Math.max(4,Math.ceil(interval*2.5));repetitions++;}
  return {intervalDays:Math.min(interval,365),repetitions,dueAt:new Date(now+(grade==="again"?10*60_000:Math.min(interval,365)*86400_000)).toISOString()};
}
export function gradeQuiz(items:StudyMCQ[],answers:unknown){
  if(!Array.isArray(answers)||answers.length!==items.length)throw Error("Answer each question or leave it unanswered.");
  if(answers.some((v,i)=>v!==null&&(!Number.isInteger(v)||v<0||v>=items[i].options.length)))throw Error("Invalid answer selection.");
  return {answers:answers as Array<number|null>,correct:items.reduce((n,q,i)=>n+(answers[i]===q.correct_index?1:0),0),total:items.length};
}
export function dayInTimezone(timezone:string,now=new Date()){
  const parts=new Intl.DateTimeFormat("en-CA",{timeZone:timezone,year:"numeric",month:"2-digit",day:"2-digit"}).formatToParts(now);
  const part=(type:string)=>parts.find(p=>p.type===type)!.value;
  return `${part("year")}-${part("month")}-${part("day")}`;
}
export function revisionSchedule(topics:Array<{slug:string;name:string}>,progress:Progress[],plan:Plan,now=new Date()) {
  const today=dayInTimezone(plan.timezone,now);
  const days=Math.max(0,Math.min(366,Math.floor((Date.parse(plan.exam_date)-Date.parse(today))/86400_000)+1));
  if(!days||!topics.length)return [];
  const pending=topics.filter(t=>!progress.some(p=>p.topic_slug===t.slug&&p.completed));
  const pool=pending.length?pending:topics;
  // Cover each unfinished material before rotating through it again. Several may fall on a short study day.
  const slots=Math.max(days,pool.length);
  const schedule:Array<{date:string;topics:Array<{slug:string;name:string}>;minutes:number}>=Array.from({length:days},(_,i)=>({date:new Date(Date.parse(today)+i*86400_000).toISOString().slice(0,10),topics:[],minutes:plan.daily_minutes}));
  for(let i=0;i<slots;i++)schedule[Math.floor(i*days/slots)].topics.push(pool[i%pool.length]);
  return schedule;
}
