import type { GroundedAnswer } from "./rag";
import type { StudyMode } from "./study-types";

export type SavedStudyResult = {
  id:string;
  topicSlug:string;
  requestKey:string;
  sourceVersion:string;
  mode?:StudyMode;
  question:string;
  result:GroundedAnswer;
  createdAt:string;
};
export const STUDY_LABELS:Record<StudyMode,string> = {
  overview:"Overview",teach:"Teach Me",summary:"Summary",guide:"Study guide",mcqs:"MCQs",flashcards:"Flashcards",
};
export function normalizeStudyQuestion(question:string) {return question.trim().replace(/\s+/g," ").toLowerCase();}
export function studyRequestKey(question:string,mode?:StudyMode) {return mode?`tool:${mode}`:`question:${normalizeStudyQuestion(question)}`;}
export function findSavedResult(history:SavedStudyResult[],question:string,mode?:StudyMode,sourceVersion?:string) {
  const key=studyRequestKey(question,mode);
  return history.find(item=>item.requestKey===key && (sourceVersion===undefined||item.sourceVersion===sourceVersion));
}
