import { env } from "cloudflare:workers";
import { cookies } from "next/headers";
import { getChatGPTUser } from "@/app/chatgpt-auth";
import { supabaseRequest } from "./supabase";
import {documentCourse} from "./courses";
import { studyRequestKey, type SavedStudyResult } from "./saved-study-types";
import type { StudyMode } from "./study-types";
import type { GroundedAnswer } from "./rag";

export function database(){if(!env.DB)throw new Error("Saved study storage is unavailable. Please retry shortly.");return env.DB;}
export async function studyOwner() {
  const user=await getChatGPTUser();
  if(user)return {owner:`user:${user.userId}`,signedIn:true};
  const jar=await cookies();
  const existing=jar.get("mindrounds-study")?.value;
  const token=existing&&/^[0-9a-f-]{36}$/.test(existing)?existing:crypto.randomUUID();
  if(!existing||token!==existing)jar.set("mindrounds-study",token,{httpOnly:true,secure:true,sameSite:"none",partitioned:true,path:"/",maxAge:365*24*60*60});
  return {owner:`guest:${token}`,signedIn:false};
}
export async function materialVersion(topicSlug:string) {
  const match=/^material-([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/.exec(topicSlug);
  if(!match)throw new Error("Choose a course material.");
  const course=(await documentCourse(match[1]))?.id;
  if(!course)throw new Error("This course is unavailable.");
  const {data}=await supabaseRequest<Array<{id:string;source_file_id:string;source_version:string|null;processed_at:string|null}>>(`documents?select=id,source_file_id,source_version,processed_at&id=eq.${match[1]}&course_id=eq.${course}`);
  if(!data[0])throw new Error("This material is not part of an active course.");
  return `${data[0].source_file_id}:${data[0].source_version??"unversioned"}:${data[0].processed_at??"unprepared"}`;
}
type Row={id:string;topic_slug:string;request_key:string;source_version:string;mode:StudyMode|null;question:string;result_json:string;created_at:string};
function decode(row:Row):SavedStudyResult{return {id:row.id,topicSlug:row.topic_slug,requestKey:row.request_key,sourceVersion:row.source_version,mode:row.mode??undefined,question:row.question,result:JSON.parse(row.result_json),createdAt:row.created_at};}
export async function studyHistory(owner:string,topicSlug:string,offset=0){
  const rows=await database().prepare("SELECT * FROM study_results WHERE owner = ? AND topic_slug = ? ORDER BY created_at DESC, id DESC LIMIT 101 OFFSET ?").bind(owner,topicSlug,offset).all<Row>();
  return {items:rows.results.slice(0,100).map(decode),hasMore:rows.results.length>100};
}
export async function cachedStudy(owner:string,topicSlug:string,question:string,mode:StudyMode|undefined,sourceVersion:string){
  const row=await database().prepare("SELECT * FROM study_results WHERE owner = ? AND topic_slug = ? AND request_key = ? AND source_version = ? ORDER BY created_at DESC, id DESC LIMIT 1").bind(owner,topicSlug,studyRequestKey(question,mode),sourceVersion).first<Row>();
  return row?decode(row):null;
}
export async function saveStudy(owner:string,topicSlug:string,question:string,mode:StudyMode|undefined,sourceVersion:string,result:GroundedAnswer){
  const item:SavedStudyResult={id:crypto.randomUUID(),topicSlug,requestKey:studyRequestKey(question,mode),sourceVersion,mode,question,result,createdAt:new Date().toISOString()};
  await database().prepare("INSERT INTO study_results (id, owner, topic_slug, request_key, source_version, mode, question, result_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)").bind(item.id,owner,topicSlug,item.requestKey,sourceVersion,mode??null,question,JSON.stringify(result),item.createdAt).run();
  return item;
}
export async function claimStudy(owner:string,topicSlug:string,question:string,mode:StudyMode|undefined,sourceVersion:string){
  const key=JSON.stringify([owner,topicSlug,studyRequestKey(question,mode),sourceVersion]);
  const token=crypto.randomUUID();const now=Date.now();
  const row=await database().prepare("INSERT INTO study_locks (key, token, expires_at) VALUES (?, ?, ?) ON CONFLICT(key) DO UPDATE SET token = excluded.token, expires_at = excluded.expires_at WHERE study_locks.expires_at < ? RETURNING token").bind(key,token,now+15*60_000,now).first<{token:string}>();
  return row?.token===token?{key,token}:null;
}
export async function releaseStudy(lease:{key:string;token:string}){
  await database().prepare("DELETE FROM study_locks WHERE key = ? AND token = ?").bind(lease.key,lease.token).run();
}
