import { cachedStudy, claimStudy, materialVersion, releaseStudy, saveStudy, studyOwner } from "./saved-study";
import type { GroundedAnswer } from "./rag";
import type { StudyMode } from "./study-types";

export async function savedStudyGeneration(topicSlug:string, question:string, mode:StudyMode|undefined, force:boolean, generate:()=>Promise<GroundedAnswer>){
  const {owner}=await studyOwner();const version=await materialVersion(topicSlug);
  if(!force){const saved=await cachedStudy(owner,topicSlug,question,mode,version);if(saved)return {...saved.result,saved,cached:true};}
  const lease=await claimStudy(owner,topicSlug,question,mode,version);
  if(!lease) return {busy:true as const};
  try{
    // Another request may have saved a response while this one acquired its lease.
    if(!force){const saved=await cachedStudy(owner,topicSlug,question,mode,version);if(saved)return {...saved.result,saved,cached:true};}
    const result=await generate();
    const saved=await saveStudy(owner,topicSlug,question,mode,await materialVersion(topicSlug),result);
    return {...result,saved,cached:false};
  }finally{await releaseStudy(lease);}
}
