import {
  countRows,
  isSupabaseConfigured,
  supabaseRequest,
  verifyDatabaseSchema,
} from "./supabase";
import { isGoogleDriveConfigured } from "./google-drive";
import { getTopicGraph, topicFromGraph } from "./topic-data";

import {getCourse,getCourses,activeCourseFilter} from "./courses";

export type TopicSummary = {
  courseSlug?: string;
  courseName?: string;
  id: string;
  name: string;
  slug: string;
  description: string | null;
  status: string;
  resources: number;
  questions: number;
  examYears: number;
  concepts: number;
  processingStatus: string;
};

export type MaterialSummary = {
  id: string;
  title: string;
  mimeType: string;
  documentType: string;
  status: string;
  sourceUrl: string | null;
  discoveredAt: string;
};

export type DashboardData = {
  state: "ready" | "not_configured" | "schema_missing" | "unavailable";
  message: string;
  topics: TopicSummary[];
  materials: MaterialSummary[];
  totals: { documents: number; questions: number; examYears: number };
};

export const EMPTY_DASHBOARD: DashboardData = {
  state: "not_configured",
  message: "The course data connection is not configured.",
  topics: [],
  materials: [],
  totals: { documents: 0, questions: 0, examYears: 0 },
};

export async function getDashboardData(courseSlug="psychiatry"): Promise<DashboardData> {
  if (!isSupabaseConfigured()) return EMPTY_DASHBOARD;

  try {
    const schema = await verifyDatabaseSchema();
    if (!schema.ready) {
      return { ...EMPTY_DASHBOARD, state: "schema_missing", message: schema.message };
    }
    const courseId = (await getCourse(courseSlug))?.id ?? null;
    if (!courseId) {
      return {
        ...EMPTY_DASHBOARD,
        state: "ready",
        message: "The database is connected. The selected course has not been initialized yet.",
      };
    }

    const encodedCourse = encodeURIComponent(courseId);
    const topicGraph = await getTopicGraph(courseId);
    const [materialsResult, papersResult] = await Promise.all([
      supabaseRequest<Array<{id:string;title:string;mime_type:string;document_type:string;processing_status:string;source_url:string|null;discovered_at:string}>>(
        `documents?select=id,title,mime_type,document_type,processing_status,source_url,discovered_at&course_id=eq.${encodedCourse}&order=discovered_at.desc&limit=6`),
      supabaseRequest<Array<{exam_year:number|null}>>(`past_question_papers?select=exam_year&course_id=eq.${encodedCourse}&limit=1000`),
    ]);

    return {
      state: "ready",
      message: "Live course data from Supabase.",
      topics: topicGraph.topics.map((topic) => ({
        courseSlug,
        id: topic.id,
        name: topic.canonical_name,
        slug: topic.slug,
        description: topic.description,
        status: topic.status,
        processingStatus: topicGraph.documents.find(d=>d.id===topic.id)?.processing_status ?? "discovered",
        resources: topicFromGraph(topicGraph, topicGraph.topics.find(t=>t.id===topic.id)!).documents.length,
        questions: topicFromGraph(topicGraph, topic).questions.length,
        examYears: topicFromGraph(topicGraph, topicGraph.topics.find(t=>t.id===topic.id)!).years.length,
        concepts: topicGraph.conceptLinks.filter(r=>r.topic_id===topic.id).length,
      })),
      materials: materialsResult.data.map((material) => ({
        id: material.id,
        title: material.title,
        mimeType: material.mime_type,
        documentType: material.document_type,
        status: material.processing_status,
        sourceUrl: material.source_url,
        discoveredAt: material.discovered_at,
      })),
      totals: {
        documents: await countRows("documents", `course_id=eq.${encodedCourse}`),
        questions: topicGraph.questions.length,
        examYears: new Set(
          papersResult.data.map((paper) => paper.exam_year).filter((year): year is number => year !== null),
        ).size,
      },
    };
  } catch (error) {
    return {
      ...EMPTY_DASHBOARD,
      state: "unavailable",
      message: error instanceof Error ? error.message : "Course data could not be loaded.",
    };
  }
}

export type IngestionStatus = {
  supabaseConfigured: boolean;
  driveConfigured: boolean;
  schema: Awaited<ReturnType<typeof verifyDatabaseSchema>>;
  counts: Record<string, number>;
  recentDocuments: MaterialSummary[];
  suggestedTopics: Array<{ id: string; name: string; description: string | null; resources: number }>;
  semanticReady: boolean;
};

export async function getIngestionStatus(): Promise<IngestionStatus> {
  const supabaseConfigured = isSupabaseConfigured();
  const driveConfigured = isGoogleDriveConfigured();
  const schema = await verifyDatabaseSchema();
  const counts: Record<string, number> = {
    total: 0,
    discovered: 0,
    queued: 0,
    processing: 0,
    ready: 0,
    failed: 0,
    unembedded: 0,
  };
  let recentDocuments: MaterialSummary[] = [];
  let suggestedTopics: IngestionStatus["suggestedTopics"] = [];
  let semanticReady = false;

  if (schema.ready) {
    try {
      await supabaseRequest<unknown[]>("document_chunks?select=embedding_model&limit=0");
      semanticReady = true;
    } catch {
      semanticReady = false;
    }
    const courses = await getCourses();
    if (courses.length) {
      const courseFilter = await activeCourseFilter();
      const statuses = ["discovered", "queued", "processing", "ready", "failed"];
      const [total, statusCounts, recent, unembedded] = await Promise.all([
        countRows("documents", courseFilter),
        Promise.all(
          statuses.map((status) =>
            countRows("documents", `${courseFilter}&processing_status=eq.${status}`),
          ),
        ),
        supabaseRequest<
          Array<{
            id: string;
            title: string;
            mime_type: string;
            document_type: string;
            processing_status: string;
            source_url: string | null;
            discovered_at: string;
          }>
        >(
          `documents?select=id,title,mime_type,document_type,processing_status,source_url,discovered_at&${courseFilter}&order=discovered_at.desc&limit=12`,
        ),
        countRows("document_chunks", "embedding=is.null"),
      ]);
      counts.total = total;
      statuses.forEach((status, index) => {
        counts[status] = statusCounts[index];
      });
      counts.unembedded = unembedded;
      recentDocuments = recent.data.map((document) => ({
        id: document.id,
        title: document.title,
        mimeType: document.mime_type,
        documentType: document.document_type,
        status: document.processing_status,
        sourceUrl: document.source_url,
        discoveredAt: document.discovered_at,
      }));
      suggestedTopics = []; // Every registered material is already a topic.
    }
  }

  return { supabaseConfigured, driveConfigured, schema, counts, recentDocuments, suggestedTopics, semanticReady };
}

export type PastQuestionOption = {
  key: string | null;
  text: string;
  isCorrect: boolean | null;
};

export type PastQuestionItem = {
  id: string;
  number: string | null;
  text: string;
  type: string;
  officialAnswer: string | null;
  topics: string[];
  options: PastQuestionOption[];
};

export type PastQuestionPaper = {
  id: string;
  title: string;
  sourceUrl: string | null;
  year: number | null;
  session: string | null;
  institution: string | null;
  answerKeyAvailable: boolean;
  questions: PastQuestionItem[];
};

export type PastQuestionsData = {
  state: DashboardData["state"];
  message: string;
  papers: PastQuestionPaper[];
  trends: Array<{ topic: string; questions: number; years: number }>;
  totalQuestions: number;
};

export async function getPastQuestionsData(search = "",courseSlug="psychiatry"): Promise<PastQuestionsData> {
  const empty: PastQuestionsData = {
    state: "not_configured",
    message: "The course data connection is not configured.",
    papers: [],
    trends: [],
    totalQuestions: 0,
  };
  if (!isSupabaseConfigured()) return empty;

  try {
    const schema = await verifyDatabaseSchema();
    if (!schema.ready) return { ...empty, state: "schema_missing", message: schema.message };
    const courseId = (await getCourse(courseSlug))?.id ?? null;
    if (!courseId) return { ...empty, state: "ready", message: "No past-question papers are indexed yet." };
    const course = encodeURIComponent(courseId);
    const [papersResult, documentsResult, questionsResult, optionsResult, relationsResult, topicsResult] =
      await Promise.all([
        supabaseRequest<Array<{
          id: string;
          document_id: string;
          exam_year: number | null;
          session_name: string | null;
          institution: string | null;
          answer_key_available: boolean;
        }>>(`past_question_papers?select=id,document_id,exam_year,session_name,institution,answer_key_available&course_id=eq.${course}&order=exam_year.desc.nullslast&limit=500`),
        supabaseRequest<Array<{ id: string; title: string; source_url: string | null }>>(
          `documents?select=id,title,source_url&course_id=eq.${course}&limit=1000`,
        ),
        supabaseRequest<Array<{
          id: string;
          paper_id: string;
          question_number: string | null;
          question_text: string;
          question_type: string;
          official_answer: string | null;
        }>>("past_questions?select=id,paper_id,question_number,question_text,question_type,official_answer&limit=5000"),
        supabaseRequest<Array<{
          question_id: string;
          option_key: string | null;
          option_text: string;
          is_officially_correct: boolean | null;
          display_order: number;
        }>>("past_question_options?select=question_id,option_key,option_text,is_officially_correct,display_order&order=display_order.asc&limit=20000"),
        supabaseRequest<Array<{ question_id: string; topic_id: string }>>(
          "past_question_topics?select=question_id,topic_id&limit=10000",
        ),
        supabaseRequest<Array<{ id: string; canonical_name: string }>>(
          `topics?select=id,canonical_name&course_id=eq.${course}&status=eq.approved&limit=1000`,
        ),
      ]);

    const query = search.trim().toLocaleLowerCase();
    const coursePaperIds = new Set(papersResult.data.map((paper) => paper.id));
    const documents = new Map(documentsResult.data.map((item) => [item.id, item]));
    const topicNames = new Map(topicsResult.data.map((topic) => [topic.id, topic.canonical_name]));
    const optionsByQuestion = new Map<string, PastQuestionOption[]>();
    for (const option of optionsResult.data) {
      const options = optionsByQuestion.get(option.question_id) ?? [];
      options.push({ key: option.option_key, text: option.option_text, isCorrect: option.is_officially_correct });
      optionsByQuestion.set(option.question_id, options);
    }
    const topicsByQuestion = new Map<string, string[]>();
    for (const question of questionsResult.data) {
      const paper = papersResult.data.find(p => p.id === question.paper_id);
      const material = documents.get(paper?.document_id ?? "");
      if (material) topicsByQuestion.set(question.id, [material.title]);
    }
    const questionsByPaper = new Map<string, PastQuestionItem[]>();
    for (const question of questionsResult.data) {
      const topics = topicsByQuestion.get(question.id) ?? [];
      const haystack = `${question.question_number ?? ""} ${question.question_text} ${topics.join(" ")}`.toLocaleLowerCase();
      if (query && !haystack.includes(query)) continue;
      const questions = questionsByPaper.get(question.paper_id) ?? [];
      questions.push({
        id: question.id,
        number: question.question_number,
        text: question.question_text,
        type: question.question_type,
        officialAnswer: question.official_answer,
        topics,
        options: optionsByQuestion.get(question.id) ?? [],
      });
      questionsByPaper.set(question.paper_id, questions);
    }

    const papers = papersResult.data
      .map((paper) => {
        const document = documents.get(paper.document_id);
        return {
          id: paper.id,
          title: document?.title ?? "Past examination paper",
          sourceUrl: document?.source_url ?? null,
          year: paper.exam_year,
          session: paper.session_name,
          institution: paper.institution,
          answerKeyAvailable: paper.answer_key_available,
          questions: questionsByPaper.get(paper.id) ?? [],
        };
      })
      .filter((paper) => !query || paper.questions.length > 0);

    const topicStats = new Map<string, { questions: Set<string>; years: Set<number> }>();
    for (const paper of papersResult.data) {
      for (const question of questionsResult.data.filter((item) => item.paper_id === paper.id)) {
        for (const topic of topicsByQuestion.get(question.id) ?? []) {
          const stats = topicStats.get(topic) ?? { questions: new Set<string>(), years: new Set<number>() };
          stats.questions.add(question.id);
          if (paper.exam_year !== null) stats.years.add(paper.exam_year);
          topicStats.set(topic, stats);
        }
      }
    }
    const trends = [...topicStats.entries()]
      .map(([topic, stats]) => ({ topic, questions: stats.questions.size, years: stats.years.size }))
      .sort((a, b) => b.questions - a.questions || a.topic.localeCompare(b.topic))
      .slice(0, 8);

    return {
      state: "ready",
      message: papers.length ? "Past questions indexed from the configured Drive folder." : query ? "No questions match this search." : "No past-question papers have been indexed yet.",
      papers,
      trends,
      totalQuestions: questionsResult.data.filter((question) => coursePaperIds.has(question.paper_id)).length,
    };
  } catch (error) {
    return {
      ...empty,
      state: "unavailable",
      message: error instanceof Error ? error.message : "Past questions could not be loaded.",
    };
  }
}

export async function getAllDashboardData():Promise<DashboardData>{
 try{const courses=await getCourses();const dashboards=await Promise.all(courses.map(c=>getDashboardData(c.slug)));
 const failed=dashboards.find(d=>d.state!=="ready");if(failed)return {...EMPTY_DASHBOARD,state:"unavailable",message:failed.message};
 return {state:"ready",message:courses.length?"All active MindRounds courses.":"No courses have been registered yet.",topics:dashboards.flatMap((d,i)=>d.topics.map(t=>({...t,courseSlug:courses[i].slug,courseName:courses[i].name}))),materials:dashboards.flatMap(d=>d.materials),totals:{documents:dashboards.reduce((n,d)=>n+d.totals.documents,0),questions:dashboards.reduce((n,d)=>n+d.totals.questions,0),examYears:Math.max(0,...dashboards.map(d=>d.totals.examYears))}};
 }catch(e){return {...EMPTY_DASHBOARD,state:"unavailable",message:e instanceof Error?e.message:"Courses could not be loaded."};}
}
