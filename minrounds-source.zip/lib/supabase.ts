const REQUIRED_TABLES = [
  "courses",
  "topics",
  "documents",
  "topic_documents",
  "past_question_papers",
  "past_questions",
  "past_question_topics",
] as const;

export type SchemaCheck = {
  configured: boolean;
  ready: boolean;
  tables: Array<{ name: string; ready: boolean; detail?: string }>;
  message: string;
};

function config() {
  const url = process.env.SUPABASE_URL?.replace(/\/$/, "");
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) return null;
  return { url, key };
}

export function isSupabaseConfigured() {
  return Boolean(config());
}

export async function supabaseRequest<T>(
  path: string,
  init: RequestInit = {},
): Promise<{ data: T; response: Response }> {
  const values = config();
  if (!values) throw new Error("Supabase environment variables are not configured.");

  const response = await fetch(`${values.url}/rest/v1/${path}`, {
    ...init,
    signal:init.signal??AbortSignal.timeout(30_000),
    headers: {
      apikey: values.key,
      Authorization: `Bearer ${values.key}`,
      Accept: "application/json",
      ...(init.body ? { "Content-Type": "application/json" } : {}),
      ...init.headers,
    },
    cache: "no-store",
  });

  const raw = await response.text();
  if (!response.ok) {
    let detail = raw;
    try {
      const parsed = JSON.parse(raw) as { message?: string; details?: string };
      detail = parsed.message ?? parsed.details ?? raw;
    } catch {
      // Preserve the response text when it is not JSON.
    }
    throw new Error(`Supabase request failed (${response.status}): ${detail || response.statusText}`);
  }

  return {
    data: (raw ? JSON.parse(raw) : null) as T,
    response,
  };
}

export async function verifyDatabaseSchema(): Promise<SchemaCheck> {
  if (!config()) {
    return {
      configured: false,
      ready: false,
      tables: REQUIRED_TABLES.map((name) => ({ name, ready: false })),
      message: "Supabase credentials are not configured.",
    };
  }

  const tables = await Promise.all(
    REQUIRED_TABLES.map(async (name) => {
      try {
        await supabaseRequest<unknown[]>(`${name}?select=*&limit=0`);
        return { name, ready: true };
      } catch (error) {
        return {
          name,
          ready: false,
          detail: error instanceof Error ? error.message : "Table could not be read.",
        };
      }
    }),
  );
  const ready = tables.every((table) => table.ready);

  return {
    configured: true,
    ready,
    tables,
    message: ready
      ? "The required Psychiatry schema is available through Supabase."
      : "The database is reachable, but one or more required tables are missing.",
  };
}

export async function getPsychiatryCourseId(): Promise<string | null> {
  const { data } = await supabaseRequest<Array<{ id: string }>>(
    "courses?select=id&slug=eq.psychiatry&limit=1",
  );
  return data[0]?.id ?? null;
}

export async function ensurePsychiatryCourse(): Promise<string> {
  const existing = await getPsychiatryCourseId();
  if (existing) return existing;

  const { data } = await supabaseRequest<Array<{ id: string }>>(
    "courses?on_conflict=slug&select=id",
    {
      method: "POST",
      headers: { Prefer: "resolution=merge-duplicates,return=representation" },
      body: JSON.stringify({
        slug: "psychiatry",
        name: "Psychiatry",
        description: "Structured Psychiatry learning from lectures, notes, and past questions",
      }),
    },
  );

  if (!data[0]?.id) throw new Error("The Psychiatry course could not be created.");
  return data[0].id;
}

export function countFromContentRange(response: Response) {
  const range = response.headers.get("content-range");
  const total = range?.split("/")[1];
  return total && total !== "*" ? Number(total) : 0;
}

export async function countRows(table: string, filters = "") {
  const separator = filters ? `&${filters}` : "";
  const { response } = await supabaseRequest<unknown[]>(
    `${table}?select=id&limit=1${separator}`,
    { headers: { Prefer: "count=exact", Range: "0-0" } },
  );
  return countFromContentRange(response);
}
