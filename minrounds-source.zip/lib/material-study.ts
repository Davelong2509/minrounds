import { supabaseRequest } from "./supabase";
import {documentCourse} from "./courses";
import { processDocument } from "./document-processing";

export async function prepareStudyMaterial(slug: string, localOnly=false) {
  const match = /^material-([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/.exec(slug);
  if (!match) throw new Error("Choose a material from the selected course topic list.");
  const courseId = (await documentCourse(match[1]))?.id;
  if (!courseId) throw new Error("This course is not available.");
  const {data:documents} = await supabaseRequest<Array<{id:string; title:string; processing_status:string}>>(
    `documents?select=id,title,processing_status&id=eq.${match[1]}&course_id=eq.${courseId}`,
  );
  const document = documents[0];
  if (!document) throw new Error("This material is not part of an active course.");
  const {data:pages} = await supabaseRequest<Array<{extracted_text:string|null}>>(
    `document_pages?select=extracted_text&document_id=eq.${document.id}&limit=1000`,
  );
  const {data:chunks} = await supabaseRequest<Array<{content:string}>>(
    `document_chunks?select=content&document_id=eq.${document.id}&limit=1`,
  );
  // Ready pages are sufficient; semantic embeddings are not required for studying a file.
  if (document.processing_status === "ready" && (pages.some(p=>p.extracted_text?.trim()) || chunks.some(c=>c.content.trim()))) {
    return {ready:true, title:document.title, newlyProcessed:false};
  }
  const result = await processDocument(document.id, {skipEmbeddings:true, ...(localOnly?{localOnly:true}:{})});
  if (result.skipped) return {ready:false, title:document.title, newlyProcessed:false, message:"This material is being prepared. Please keep this page open."};
  if (!result.processed?.chunks) throw new Error("This material has no readable content yet. Retry preparation or check the original file.");
  return {ready:true, title:document.title, newlyProcessed:true};
}
