import {database,materialVersion} from "./saved-study";
import {recommendedVideos,VIDEO_CATALOG,type TeachingVideo} from "./video-catalog";
export type ManagedVideo=TeachingVideo&{disabled:number;checkStatus:string;checkedAt:string|null};
type Row={video_id:string;title:string;publisher:string;focus:string;disabled:number;check_status:string;checked_at:string|null};
export function parseVideoId(value:string){if(/^[\w-]{11}$/.test(value))return value;let u:URL;try{u=new URL(value);}catch{throw Error("Paste a YouTube video URL or video ID.");}if(u.protocol!=="https:")throw Error("Use an HTTPS YouTube URL.");const host=u.hostname.toLowerCase();let id:string|null=null;if(host==="youtu.be")id=u.pathname.slice(1);else if(["youtube.com","www.youtube.com","m.youtube.com","www.youtube-nocookie.com"].includes(host))id=u.pathname==="/watch"?u.searchParams.get("v"):u.pathname.match(/^\/(?:embed|shorts)\/([\w-]{11})$/)?.[1]??null;if(!id||!/^[\w-]{11}$/.test(id))throw Error("Choose a valid YouTube video URL.");return id;}
export async function topicVideos(topicSlug:string,name:string,includeDisabled=false,courseSlug="psychiatry"){
 const defaults=(courseSlug==="psychiatry"?recommendedVideos(name):[]).map(v=>({...v,disabled:0,checkStatus:"curated",checkedAt:null}));
 let rows:Row[]=[];try{rows=(await database().prepare("SELECT * FROM video_recommendations WHERE topic_slug = ? ORDER BY updated_at DESC").bind(topicSlug).all<Row>()).results;}catch{return defaults;}
 const combined=new Map(defaults.map(v=>[v.id,v as ManagedVideo]));
 for(const r of rows)combined.set(r.video_id,{id:r.video_id,title:r.title,publisher:r.publisher,focus:r.focus,disabled:r.disabled,checkStatus:r.check_status,checkedAt:r.checked_at});
 return [...combined.values()].filter(v=>includeDisabled||(!v.disabled&&v.checkStatus!=="unavailable"));
}
export async function inspectVideo(id:string){try{const r=await fetch(`https://www.youtube.com/oembed?url=${encodeURIComponent(`https://www.youtube.com/watch?v=${id}`)}&format=json`,{signal:AbortSignal.timeout(6000)});if(!r.ok)return {checkStatus:r.status===404||r.status===403?"unavailable":"unverified",metadata:null};const body=await r.json() as {title:string;author_name:string};if(!body.title||!body.author_name)return {checkStatus:"unverified",metadata:null};return {checkStatus:"available",metadata:body};}catch{return {checkStatus:"unverified",metadata:null};}}
export async function manageVideo(body:Record<string,unknown>){
 const topic=String(body.topicSlug);await materialVersion(topic);const id=parseVideoId(String(body.url??body.videoId));
 const focus=String(body.focus??"Additional teaching video for this material.").trim().slice(0,300);
 const old=await database().prepare("SELECT * FROM video_recommendations WHERE topic_slug = ? AND video_id = ?").bind(topic,id).first<Row>();
 const fallback=Object.values(VIDEO_CATALOG).find(v=>v.id===id);
 const check=body.action==="check"||body.action==="save"?await inspectVideo(id):null;
 if(body.action==="save"&&!check?.metadata)throw Error("YouTube could not verify this video. Check its URL and try again.");
 if(!["save","check","toggle"].includes(String(body.action)))throw Error("Unknown video action.");
 const title=check?.metadata?.title??old?.title??fallback?.title;
 const publisher=check?.metadata?.author_name??old?.publisher??fallback?.publisher;
 if(!title||!publisher)throw Error("Save a verified video first.");
 const disabled=body.action==="toggle"?(body.disabled===true?1:0):old?.disabled??0;
 const now=new Date().toISOString();
 await database().prepare("INSERT INTO video_recommendations (key,topic_slug,video_id,title,publisher,focus,disabled,check_status,checked_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?) ON CONFLICT(key) DO UPDATE SET origin='manual',title=excluded.title,publisher=excluded.publisher,focus=excluded.focus,disabled=excluded.disabled,check_status=excluded.check_status,checked_at=excluded.checked_at,updated_at=excluded.updated_at").bind(JSON.stringify([topic,id]),topic,id,title,publisher,body.action==="save"?focus:old?.focus??fallback?.focus??focus,disabled,check?.checkStatus??old?.check_status??"curated",check?now:old?.checked_at??null,now).run();
 return {ok:true,status:check?.checkStatus??"updated"};
}
