import { readFileSync } from 'node:fs';
import assert from 'node:assert/strict';
import ts from 'typescript';
const compiled = ts.transpileModule(readFileSync('lib/video-catalog.ts','utf8'), {compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText.replace(/\bexport /g,'');
const {recommendedVideos, VIDEO_CATALOG: c, youtubeEmbedUrl} = new Function(`${compiled};return {recommendedVideos,VIDEO_CATALOG,youtubeEmbedUrl}`)();
// Real material filenames: verify subject-specific recommendations, including duplicate uploads.
const groups = [
 [['Abnormal Sexual Preference.docx','DISORDERS OF SEXUAL PREFERENCE -Autosaved-.pptx','DISORDERS OF SEXUAL PREFERENCE.pptx'],c.paraphilic],
 [['Affective disorders.pptx','Affective disorders(0).pptx','Mood disorders1.pptx'],c.depression],
 [['Ahuja - A Short Textbook of Psychiatry, 7th Edition (1).pdf','Ahuja - A Short Textbook of Psychiatry, 7th Edition.pdf'],c.depression],
 [['anxiety and stress related disorders - 2024 update - Copy.pptx'],c.anxiety],
 [['Childhood psychiatric disorders (2).pptx'],c.adhd],
 [['DELIRIUM ppt 2023.pptx'],c.delirium],
 [['dementia - 2024 update.pptx'],c.dementia],
 [['disorders of perception -2024 update.pptx'],c.psychosis],
 [['DISORDERS OF THOUGHT.pptx'],c.thought],
 [['Drug treatments in Psychiatry (1).pptx'],c.antipsychotics],
 [['emergency psychiatry - 2024 update.pptx'],c.emergency],
 [['history of psychiatry - 2024 update.pptx'],c.history],
 [['HISTORY TAKING IN PSYCHIATRY.pptx','mental state examination.pptx','psychiatric assessment.pdf','PSYCHIATRY CLERKING GUIDE(1).pdf'],c.psychosisMse],
 [['PERSONALITY why we act the way we do lecture for medical students aug2023.pptx'],c.personality],
 [['PMS, puerperal disorders.pptx'],c.perinatal],
 [['SCHIZOPHRENIA part one2024.pptx','SCHIZOPHRENIA SPECTRUM2 2024.pptx'],c.schizophrenia],
];
assert.equal(groups.flatMap(([names])=>names).length,25);
for(const [names,first] of groups)for(const name of names){const result=recommendedVideos(name);assert.equal(result[0].id,first.id,name);assert.equal(new Set(result.map(v=>v.id)).size,result.length);}
assert.deepEqual(recommendedVideos('Unmatched new material.pdf'),[], 'Unknown materials must not get unrelated recommendations');
for(const v of Object.values(c)){const u=new URL(youtubeEmbedUrl(v.id,'https://example.com/topic'));assert.equal(u.hostname,'www.youtube-nocookie.com');assert.equal(u.pathname,`/embed/${v.id}`);assert.equal(u.searchParams.get('origin'),'https://example.com');assert.equal(u.searchParams.get('autoplay'),'0');assert.equal(u.searchParams.get('enablejsapi'),'1');assert.ok(v.publisher&&v.focus);}
for(const bad of ['https://youtube.com/watch?v=test','../danger','<script>bad</script>','abc'])assert.throws(()=>youtubeEmbedUrl(bad,'https://example.com'));
console.log('Video checks passed: all 25 materials, duplicate-file consistency, unknown-subject empty state and safe non-autoplay embeds.');
