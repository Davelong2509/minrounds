import {readFileSync} from 'node:fs';import ts from 'typescript';import assert from 'node:assert/strict';
const source=ts.transpileModule(readFileSync('lib/google-drive.ts','utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText.replace(/\bexport /g,'');const {psychiatryRoot}=new Function(`${source};return {psychiatryRoot};`)();const folder=(id,name)=>({id,name,mimeType:'application/vnd.google-apps.folder'});
assert.equal(psychiatryRoot('root',[folder('p','Psychiatry'),folder('d','Dermatology'),folder('o','Orthopedics')]),'p');
assert.equal(psychiatryRoot('p',[]),'p');assert.throws(()=>psychiatryRoot('root',[folder('d','Dermatology')]),/Configure/);assert.throws(()=>psychiatryRoot('root',[folder('p','Psychiatry'),folder('p2',' Psychiatry ')]),/Multiple/);
console.log('Course boundary checks passed: Psychiatry selected, unrelated courses excluded, ambiguous folders rejected.');
