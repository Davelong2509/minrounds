import {readFileSync} from "node:fs";
import assert from "node:assert/strict";
import ts from "typescript";
function load(path,bindings,names){const source=ts.transpileModule(readFileSync(path,"utf8"),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText.replace(/^import .*;\n/gm,"").replace(/\bexport /g,"");return new Function(...Object.keys(bindings),`${source}\nreturn {${names.join(",")}};`)(...Object.values(bindings));}
const docId="11111111-1111-4111-8111-111111111111";
const slug=`material-${docId}`;
let prepared=0;
let state="discovered";
const preparation=load("lib/material-study.ts",{getPsychiatryCourseId:async()=>"course",documentCourse:async()=>({id:"course"}),getCourse:async()=>({id:"course"}),supabaseRequest:async path=>({data:path.startsWith("documents?")?[{id:docId,title:"Source.pptx",processing_status:state}]:path.startsWith("document_pages?")?[{extracted_text:state==="ready"?"Original page text":""}]:[]}),processDocument:async(id,options)=>{assert.equal(id,docId);assert.equal(options.skipEmbeddings,true);prepared++;return {processed:{chunks:1}};}},["prepareStudyMaterial"]);
assert.equal((await preparation.prepareStudyMaterial(slug)).newlyProcessed,true);
assert.equal(prepared,1,"Discovered material must be prepared on first use");
state="ready";
assert.equal((await preparation.prepareStudyMaterial(slug)).newlyProcessed,false);
assert.equal(prepared,1,"Ready extracted pages must be reused even without chunks");
await assert.rejects(()=>preparation.prepareStudyMaterial("arbitrary-inferred-topic"),/Choose a material/);
const {STUDY_INSTRUCTIONS,STUDY_MODES}=load("lib/study-types.ts",{},["STUDY_INSTRUCTIONS","STUDY_MODES"]);
const detail={topic:{id:docId,course_id:"course",canonical_name:"Source.pptx"},documents:[{id:docId,processing_status:"discovered"}],concepts:[],questions:[],years:[],papers:[],pages:[],sourceDocuments:[]};
let response;
const payloads=[];
const rag=load("lib/rag.ts",{STUDY_INSTRUCTIONS,createEmbeddings:()=>{throw Error("Material must not depend on embeddings");},openAIRequest:async(_path,init)=>{payloads.push(JSON.parse(init.body));return {};},responseOutputText:()=>JSON.stringify(response),getPsychiatryCourseId:async()=>"course",documentCourse:async()=>({id:"course"}),getCourse:async()=>({id:"course"}),getTopicDetail:async s=>s===slug?detail:null,supabaseRequest:async path=>({data:path.startsWith("documents?")?[{id:docId,title:"Source.pptx"}]:path.startsWith("document_pages?")?[{id:"page",page_number:7,extracted_text:"Depression causes low mood and anhedonia. Assessment includes duration and functional impact."}]:[]})},["answerPsychiatryQuestion"]);
for(const mode of STUDY_MODES){
 response={answer:mode==="mcqs"||mode==="flashcards"?"AI-generated practice.":"Source-grounded study output [1]",cannot_answer:false,cited_source_numbers:[1],mcqs:mode==="mcqs"?[{question:"Which symptom is supplied?",options:["Anhedonia","Other","Another","None"],correct_index:0,explanation:"The material supplies anhedonia.",source_numbers:[1]}]:[],flashcards:mode==="flashcards"?[{front:"What is supplied?",back:"Anhedonia.",source_numbers:[1]}]:[]};
 const answer=await rag.answerPsychiatryQuestion("Overview",slug,mode);
 assert.equal(answer.cannotAnswer,false,`${mode} must work with page text and no chunks`);
 assert.equal(answer.retrievalMode,"material");assert.equal(answer.citations[0].pageNumber,7);
 assert.ok(payloads.at(-1).input[1].content[0].text.includes(STUDY_INSTRUCTIONS[mode]),"Each tool must have a distinct task");
 if(mode==="mcqs")assert.equal(answer.mcqs.length,1);
 if(mode==="flashcards")assert.equal(answer.flashcards.length,1);
}
response={answer:"Invalid",cannot_answer:false,cited_source_numbers:[],mcqs:[{question:"Bad",options:["A","B","C","D"],correct_index:8,explanation:"Bad",source_numbers:[1]}],flashcards:[]};
await assert.rejects(()=>rag.answerPsychiatryQuestion("MCQs",slug,"mcqs"),/could not be verified/);
response={answer:"Invalid [999]",cannot_answer:false,cited_source_numbers:[999],mcqs:[],flashcards:[]};
await assert.rejects(()=>rag.answerPsychiatryQuestion("Summary",slug,"summary"),/could not be verified/);
response={answer:"Source-supported summary [1, 1]",cannot_answer:false,cited_source_numbers:[1],mcqs:[],flashcards:[]};
const grouped=await rag.answerPsychiatryQuestion("Summary",slug,"summary");assert.equal(grouped.citations.length,1,"Declared excerpt references remain valid when the model groups inline citations");
console.log("Study checks passed: on-demand preparation, reuse, page fallback, all six modes, citation validation and MCQ validation.");
