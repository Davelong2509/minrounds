"use client";

import { FormEvent, useEffect, useRef, useState } from "react";
import { ArrowRight, ExternalLink, LoaderCircle, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { GroundedAnswer } from "@/lib/rag";
import type { StudyMode } from "@/lib/study-types";
import { findSavedResult, STUDY_LABELS, type SavedStudyResult } from "@/lib/saved-study-types";
import { MCQPractice, FlashcardPractice, StudyText } from "./study-practice";
import { SavedQuiz, SavedCards } from "./practice-deck";
import { initializeLearning } from "./learning-client";
import { useRouter } from "next/navigation";

function ResultContent({result,compact,resultId,topicSlug}:{result:GroundedAnswer;compact:boolean;resultId?:string;topicSlug?:string}) {
  return <div className={compact?"text-emerald-50/90":"text-[#0b513c]"}>
    <StudyText text={result.answer}/>
    {result.mcqs?.length?<>{resultId?<SavedQuiz items={result.mcqs} resultId={resultId}/>:<MCQPractice items={result.mcqs}/>}</>:null}
    {result.flashcards?.length?<>{resultId?<SavedCards items={result.flashcards} resultId={resultId}/>:<FlashcardPractice items={result.flashcards}/>}</>:null}
    {result.citations.length>0&&<details className={`mt-4 border-t pt-3 ${compact?"border-white/10":"border-[#d4e5da]"}`}><summary className="cursor-pointer text-xs font-bold uppercase tracking-[.12em] opacity-70">Sources ({result.citations.length})</summary><div className="mt-2 space-y-2">{result.citations.map(citation=><div key={`${citation.number}-${citation.documentTitle}`} className={`rounded-lg p-3 text-xs leading-5 ${compact?"bg-white/[.06]":"bg-white"}`}><div className="flex items-start justify-between gap-3"><strong>[{citation.number}] {citation.documentTitle}{citation.pageNumber?` · page ${citation.pageNumber}`:""}</strong>{topicSlug&&citation.pageNumber&&<a className="mr-2 underline" href={`/materials/${topicSlug.slice(9)}?page=${citation.pageNumber}`}>Read page</a>}{citation.sourceUrl&&<a href={citation.sourceUrl} target="_blank" rel="noreferrer" aria-label={`Open ${citation.documentTitle}`}><ExternalLink className="h-3.5 w-3.5"/></a>}</div><p className="mt-1 opacity-65">{citation.excerpt}{citation.excerpt.length>=280?"…":""}</p></div>)}</div></details>}
    <p className="mt-3 text-[11px] opacity-50">{result.retrievalMode==="material"?"Based on the selected material.":`Retrieved with ${result.retrievalMode==="semantic"?"semantic similarity":"text matching"}.`} Educational support only.</p>
  </div>;
}

export function AskTutor({topicSlug,topicName,compact=false,studyTools=false,courseSlug="psychiatry"}:{topicSlug?:string;topicName?:string;compact?:boolean;studyTools?:boolean;courseSlug?:string}) {
  const router=useRouter();
  const [question,setQuestion]=useState("");
  const [result,setResult]=useState<GroundedAnswer|null>(null);
  const [history,setHistory]=useState<SavedStudyResult[]>([]);
  const [opened,setOpened]=useState<Set<string>>(new Set());
  const [sourceVersion,setSourceVersion]=useState<string|undefined>();
  const [signedIn,setSignedIn]=useState(false);
  const [historyLoaded,setHistoryLoaded]=useState(!topicSlug);
  const [historyLoading,setHistoryLoading]=useState(Boolean(topicSlug));
  const [hasMore,setHasMore]=useState(false);
  const [activeMode,setActiveMode]=useState<StudyMode|undefined>();
  const [error,setError]=useState<string|null>(null);
  const [notice,setNotice]=useState<string|null>(null);
  const [loading,setLoading]=useState(false);
  const [phase,setPhase]=useState("");
  const scope=useRef(topicSlug);
  const inFlight=useRef<string|null>(null);

  async function loadHistory(offset=0) {
    if(!topicSlug)return;
    const requestedTopic=topicSlug;
    setHistoryLoading(true);
    try{
      await initializeLearning();
      const response=await fetch(`/api/study/results?topicSlug=${encodeURIComponent(topicSlug)}&offset=${offset}`,{cache:"no-store"});
      const body=await response.json() as {items:SavedStudyResult[];sourceVersion:string;signedIn:boolean;hasMore:boolean;error?:string};
      if(scope.current!==requestedTopic)return;
      if(!response.ok)throw new Error(body.error||"Saved study history could not be loaded.");
      setHistory(previous=>offset?[...previous,...body.items.filter(item=>!previous.some(p=>p.id===item.id))]:body.items);
      setSourceVersion(body.sourceVersion);setSignedIn(body.signedIn);setHasMore(body.hasMore);
      setHistoryLoaded(true);setError(null);
      if(!offset&&body.items[0])setOpened(previous=>new Set([...previous,body.items[0].id]));
    }catch(caught){if(scope.current===requestedTopic)setError(caught instanceof Error?caught.message:"Saved study history could not be loaded.");}
    finally{if(scope.current===requestedTopic)setHistoryLoading(false);}
  }
  useEffect(()=>{
    scope.current=topicSlug;inFlight.current=null;setLoading(false);setHistory([]);setOpened(new Set());setResult(null);setSourceVersion(undefined);setHistoryLoaded(!topicSlug);setError(null);setNotice(null);
    if(topicSlug)void loadHistory();else setHistoryLoading(false);
    // History is loaded for the selected material, not after every generated result.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  },[topicSlug]);

  function openSaved(item:SavedStudyResult){
    setActiveMode(item.mode);setOpened(previous=>new Set([...previous,item.id]));
    setNotice("Opened saved content. No AI tokens used.");setError(null);
    requestAnimationFrame(()=>document.getElementById(`saved-${item.id}`)?.scrollIntoView({behavior:"smooth",block:"nearest"}));
  }
  async function submit(event:FormEvent){event.preventDefault();await ask(question);}
  async function ask(prompt:string,mode?:StudyMode,force=false){
    if(!prompt.trim()||inFlight.current)return;
    if(topicSlug&&!historyLoaded){setError("Load your saved history before generating another response.");return;}
    const saved=findSavedResult(history,prompt,mode,sourceVersion);
    if(!force&&saved){openSaved(saved);return;}
    const requestedTopic=topicSlug;
    const runId=crypto.randomUUID();inFlight.current=runId;setLoading(true);setActiveMode(mode);setError(null);setNotice(null);
    try{
      if(topicSlug){
        setPhase("Reading and preparing your material…");let ready=false;
        for(let attempt=0;attempt<24;attempt++){
          const response=await fetch("/api/study/prepare",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({topicSlug})});
          if(scope.current!==requestedTopic)return;
          const prepared=await response.json() as {ready?:boolean;error?:string;newlyProcessed?:boolean};
          if(!response.ok)throw new Error(prepared.error||"The material could not be prepared.");
          if(prepared.ready){ready=true;if(prepared.newlyProcessed)router.refresh();break;}
          setPhase("Your material is being prepared. Waiting for its content…");
          await new Promise(resolve=>setTimeout(resolve,5000));
        }
        if(!ready)throw new Error("This material is still being prepared. Please retry shortly.");
      }
      setPhase(mode?"Creating and saving your study content…":"Finding and saving your answer…");
      const response=await fetch("/api/ask",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({question:prompt,topicSlug,studyMode:mode,force,courseSlug})});
      const body=await response.json() as GroundedAnswer & {saved?:SavedStudyResult;cached?:boolean;error?:string};
      if(!response.ok)throw new Error(body.error||"The tutor could not answer right now.");
      if(scope.current!==requestedTopic)return;
      if(body.saved){const item=body.saved;setHistory(previous=>[item,...previous.filter(p=>p.id!==item.id)]);setOpened(previous=>new Set([...previous,item.id]));setNotice(body.cached?"Opened saved content. No AI tokens used.":"Saved to your study history. Your earlier results are still available below.");}
      else setResult(body);
    }catch(caught){if(scope.current===requestedTopic)setError(caught instanceof Error?caught.message:"The tutor could not answer right now.");}
    finally{if(inFlight.current===runId)inFlight.current=null;if(scope.current===requestedTopic){setLoading(false);setPhase("");}}
  }
  return <form onSubmit={submit} className={compact?"rounded-2xl border border-white/10 bg-white/[.07] p-3 backdrop-blur-sm":"rounded-2xl border border-[#d4e5da] bg-white p-5 sm:p-6"}>
    {studyTools&&<div className="mb-3 flex flex-wrap gap-2">{(["overview","teach","summary","guide","mcqs","flashcards"] as StudyMode[]).map(mode=>{
      const saved=findSavedResult(history,"",mode,sourceVersion);
      const label=mode==="mcqs"?"Generate MCQs":mode==="flashcards"?"Generate flashcards":STUDY_LABELS[mode];
      return <button key={mode} type="button" disabled={loading||!historyLoaded} aria-pressed={activeMode===mode} onClick={()=>{const prompt=`${label} for ${topicName}.`;setQuestion(prompt);void ask(prompt,mode);}} className={`rounded-xl border px-4 py-2.5 text-sm font-semibold disabled:opacity-40 ${activeMode===mode?"border-[#0b513c] bg-[#0b513c] text-white":"border-[#d4e5da] bg-[#f2f9f5] text-[#0b513c]"}`}>{label}{saved&&<span className="ml-2 text-xs">✓ Saved</span>}</button>;
    })}</div>}
    {topicSlug&&<p className="mb-4 text-xs text-[#50685c]">{signedIn?"Your saved study results follow your account across devices.":"Saved results stay available in this browser. Sign in to save across devices."} Reopening saved content uses no AI tokens. {!signedIn&&<a href={`/signin-with-chatgpt?return_to=${encodeURIComponent(`/courses/${courseSlug}/topics/${topicSlug}`)}`} target="_top" className="font-semibold underline">Sign in</a>}</p>}
    {(loading||historyLoading)&&<p role="status" aria-live="polite" className="mb-4 flex items-center gap-2 text-sm text-[#50685c]"><LoaderCircle className="h-4 w-4 animate-spin"/>{historyLoading?"Loading saved study history…":phase}</p>}
    <label htmlFor={topicSlug?`ask-${topicSlug}`:"ask-course"} className={`flex items-center gap-2 text-xs font-semibold uppercase tracking-[.13em] ${compact?"px-2 pt-1 text-emerald-100/65":"text-[#50685c]"}`}><Sparkles className="h-3.5 w-3.5 text-[#087f3d]"/>{topicName?`Ask about ${topicName}`:"Ask your course"}</label>
    <textarea id={topicSlug?`ask-${topicSlug}`:"ask-course"} value={question} onChange={event=>setQuestion(event.target.value)} rows={compact?3:4} placeholder={topicName?`Ask a question about ${topicName}…`:"What are the positive symptoms of schizophrenia?"} className={`mt-2 w-full resize-none bg-transparent px-2 text-base leading-6 outline-none ${compact?"text-white placeholder:text-emerald-100/35":"text-[#063f30] placeholder:text-[#60776a]"}`}/>
    <div className={`flex flex-wrap items-center justify-between gap-2 border-t px-1 pt-2 ${compact?"border-white/10":"border-[#d4e5da]"}`}><span className={`text-xs ${compact?"text-emerald-100/45":"text-[#60776a]"}`}>Answers use indexed course sources</span><Button type="submit" disabled={loading||!historyLoaded||question.trim().length<3} size="sm" className="rounded-xl bg-[#087f3d] px-4 text-white hover:bg-[#087f3d]">{loading?<LoaderCircle className="mr-1.5 h-4 w-4 animate-spin"/>:null}{loading?"Working…":"Ask AI"}{!loading&&<ArrowRight className="ml-1.5 h-4 w-4"/>}</Button></div>
    {notice&&<p role="status" className="mt-3 rounded-xl bg-[#e5f3e9] p-3 text-sm text-[#087f3d]">{notice}</p>}
    {error&&<div role="alert" className="mt-3 rounded-xl bg-[#e5f3e9] p-3 text-sm text-[#087f3d]"><p>{error}</p>{topicSlug&&<button type="button" disabled={historyLoading||loading} onClick={()=>void loadHistory()} className="mt-2 font-semibold underline">Reload saved history</button>}</div>}
    {history.length>0&&<section aria-label="Saved study history" className="mt-6"><div className="mb-3 flex items-center justify-between"><h2 className="font-semibold">Saved study history</h2><button type="button" onClick={()=>void loadHistory()} disabled={historyLoading||loading} className="text-xs font-semibold text-[#087f3d]">Refresh history</button></div><p className="mb-3 text-xs text-[#50685c]">Open any saved result below. You can keep your summary and quiz open together. Generate new creates another version and uses AI tokens.</p><div className="space-y-3">{history.map(item=><section key={item.id} id={`saved-${item.id}`} className={`rounded-xl border p-4 ${compact?"border-white/10 bg-[#063f30]":"border-[#d4e5da] bg-[#f2f9f5]"}`}><div className="flex flex-wrap items-start justify-between gap-3"><button type="button" aria-expanded={opened.has(item.id)} aria-controls={`content-${item.id}`} onClick={()=>setOpened(previous=>{const next=new Set(previous);if(next.has(item.id))next.delete(item.id);else next.add(item.id);return next;})} className="min-w-0 flex-1 text-left"><h3 className="font-semibold">{opened.has(item.id)?"▾":"▸"} {item.mode?STUDY_LABELS[item.mode]:item.question}</h3><p className="mt-1 text-xs text-[#50685c]">{new Date(item.createdAt).toLocaleString()} · Saved{sourceVersion&&sourceVersion!==item.sourceVersion?" · Source has changed":""}</p></button><a target="_blank" rel="noreferrer" href={`/api/study/export?resultId=${item.id}&format=print`} className="rounded-lg border px-3 py-1.5 text-xs font-semibold">Print / PDF</a><a href={`/api/study/export?resultId=${item.id}`} className="rounded-lg border px-3 py-1.5 text-xs font-semibold">Download</a><button type="button" onClick={()=>document.getElementById(`content-${item.id}`)?.scrollIntoView({behavior:"smooth"})} className="sr-only">Read saved result</button><button type="button" disabled={loading||!historyLoaded} onClick={()=>void ask(item.question,item.mode,true)} className="rounded-lg border border-[#d4e5da] px-3 py-1.5 text-xs font-semibold text-[#087f3d] disabled:opacity-40">Generate new</button></div><div id={`content-${item.id}`} hidden={!opened.has(item.id)} className="mt-4">{opened.has(item.id)&&<div><ResultContent result={item.result} compact={compact} resultId={item.id} topicSlug={topicSlug}/></div>}</div></section>)}</div>{hasMore&&<button type="button" disabled={historyLoading} onClick={()=>void loadHistory(history.length)} className="mt-3 text-sm font-semibold text-[#087f3d]">Load older saved results</button>}</section>}
    {result&&<div className={`mt-4 rounded-xl p-4 ${compact?"bg-[#063f30]":"bg-[#f2f9f5]"}`}><ResultContent result={result} compact={compact}/></div>}
  </form>;
}
