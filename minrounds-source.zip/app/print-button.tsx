"use client";
export function PrintButton(){return <button type="button" onClick={()=>window.print()} className="rounded-xl border bg-white px-4 py-2 text-sm font-semibold print:hidden">Print / Save as PDF</button>;}
