import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "MindRounds | Psychiatry Study AI",
  description: "A source-grounded medical study platform for Psychiatry lectures, topics, past questions, and practice.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className="antialiased">{children}</body>
    </html>
  );
}
