import {notFound,redirect} from "next/navigation";
import {documentCourse} from "@/lib/courses";
export const dynamic="force-dynamic";
export default async function Page({params,searchParams}:{params:Promise<{id:string}>;searchParams:Promise<Record<string,string|undefined>>}){
 const {id}=await params;const course=await documentCourse(id);if(!course)notFound();
 const query=new URLSearchParams();for(const [key,value] of Object.entries(await searchParams))if(value)query.set(key,value);
 redirect(`/courses/${course.slug}/materials/${id}${query.size?`?${query}`:""}`);
}
