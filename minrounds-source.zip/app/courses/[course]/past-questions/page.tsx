export {default,dynamic} from "@/app/courses/psychiatry/past-questions/page";
