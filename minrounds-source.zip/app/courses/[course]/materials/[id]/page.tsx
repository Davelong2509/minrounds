export {default,dynamic} from "@/app/courses/psychiatry/materials/[id]/page";
