export {default,dynamic} from "@/app/courses/psychiatry/topics/[slug]/page";
