import {notFound} from "next/navigation";
import {getCourse} from "@/lib/courses";
import {getDashboardData} from "@/lib/psychiatry-data";
import {getChatGPTUser} from "@/app/chatgpt-auth";
import {isIngestionAdmin} from "@/lib/admin";
import {PsychiatryDashboard} from "@/app/psychiatry-dashboard";
export const dynamic="force-dynamic";
export default async function Page({params}:{params:Promise<{course:string}>}){const {course:slug}=await params;const course=await getCourse(slug);if(!course)notFound();const [user,dashboard]=await Promise.all([getChatGPTUser(),getDashboardData(slug)]);return <PsychiatryDashboard studentName={user?.displayName??"Medical student"} dashboard={dashboard} isAdmin={isIngestionAdmin(user)} courseSlug={course.slug} courseName={course.name}/>;}
