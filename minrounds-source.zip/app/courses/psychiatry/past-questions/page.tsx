import {getCourse} from "@/lib/courses";
import {notFound} from "next/navigation";
import { ArrowLeft, CalendarDays, ExternalLink, FileQuestion, Search } from "lucide-react";
import { getPastQuestionsData } from "@/lib/psychiatry-data";

export const dynamic = "force-dynamic";

export default async function PastQuestionsPage({
  searchParams,params,
}: {
  params?:Promise<{course?:string}>;
  searchParams: Promise<{ q?: string }>;
}) {
  const { q = "" } = await searchParams;
  const courseSlug=(await params)?.course??"psychiatry";const course=await getCourse(courseSlug);if(!course)notFound();
  const data = await getPastQuestionsData(q,courseSlug);
  const maxTrend = Math.max(1, ...data.trends.map((trend) => trend.questions));

  return (
    <main className="min-h-screen bg-[#f2f9f5] px-4 py-6 text-[#063f30] sm:px-8 lg:px-12">
      <div className="mx-auto max-w-6xl">
        <a href={`/courses/${courseSlug}`} className="inline-flex items-center gap-2 text-sm font-semibold text-[#087f3d]"><ArrowLeft className="h-4 w-4" /> Back to {course.name}</a>
        <div className="mt-6 flex flex-col justify-between gap-5 rounded-[28px] bg-[#063f30] p-7 text-white sm:p-10 lg:flex-row lg:items-end">
          <div>
            <p className="text-xs font-bold uppercase tracking-[.16em] text-[#b4e3c7]">Historical evidence</p>
            <h1 className="mt-2 text-4xl font-semibold tracking-[-.04em]">Past questions</h1>
            <p className="mt-3 max-w-2xl text-emerald-50/70">{data.totalQuestions} questions indexed from course source papers, with traceable document links.</p>
          </div>
          <form className="relative w-full lg:w-80">
            <Search className="absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-emerald-100/50" />
            <input name="q" defaultValue={q} className="h-12 w-full rounded-xl border border-white/10 bg-white/10 pl-10 pr-3 text-sm outline-none placeholder:text-emerald-100/40" placeholder="Search questions or topics" />
          </form>
        </div>

        {data.state !== "ready" || data.papers.length === 0 ? (
          <section className="mt-7 rounded-2xl border border-[#d4e5da] bg-white p-8 text-center">
            <FileQuestion className="mx-auto h-8 w-8 text-[#087f3d]" />
            <h2 className="mt-3 text-xl font-semibold">{q ? "No matching questions" : "Question indexing is in progress"}</h2>
            <p className="mx-auto mt-2 max-w-xl text-sm leading-6 text-[#50685c]">{data.message}</p>
            {q && <a href={`/courses/${courseSlug}/past-questions`} className="mt-4 inline-block text-sm font-semibold text-[#087f3d]">Clear search</a>}
          </section>
        ) : (
          <div className="mt-7 grid gap-6 lg:grid-cols-[1fr_.62fr]">
            <section className="space-y-5">
              <div className="flex items-center gap-3"><CalendarDays className="h-5 w-5 text-[#087f3d]" /><h2 className="text-xl font-semibold">Indexed papers</h2></div>
              {data.papers.map((paper) => (
                <article key={paper.id} className="rounded-2xl border border-[#d4e5da] bg-white p-5 sm:p-6">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div>
                      <p className="text-xs font-bold uppercase tracking-[.12em] text-[#087f3d]">{paper.year ?? "Year not identified"}{paper.session ? ` · ${paper.session}` : ""}</p>
                      <h3 className="mt-1 text-lg font-semibold">{paper.title}</h3>
                      <p className="mt-1 text-xs text-[#60776a]">{paper.questions.length} question{paper.questions.length === 1 ? "" : "s"}{paper.institution ? ` · ${paper.institution}` : ""}</p>
                    </div>
                    {paper.sourceUrl && <a href={paper.sourceUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#087f3d]">Open source <ExternalLink className="h-3.5 w-3.5" /></a>}
                  </div>
                  <div className="mt-5 space-y-3">
                    {paper.questions.map((question) => (
                      <details key={question.id} className="group rounded-xl border border-[#d4e5da] bg-[#f2f9f5] p-4">
                        <summary className="cursor-pointer list-none pr-4 text-sm font-semibold leading-6 marker:hidden">
                          {question.number && <span className="mr-2 text-[#087f3d]">{question.number}.</span>}{question.text}
                          {question.topics.length > 0 && <span className="mt-2 block text-[11px] font-medium text-[#60776a]">{question.topics.join(" · ")}</span>}
                        </summary>
                        {question.options.length > 0 && <ol className="mt-4 space-y-2 border-t border-[#d4e5da] pt-4">{question.options.map((option, index) => <li key={`${question.id}-${index}`} className={`rounded-lg px-3 py-2 text-sm ${option.isCorrect === true ? "bg-[#e5f3e9] text-[#087f3d]" : "bg-white text-[#50685c]"}`}><span className="mr-2 font-semibold">{option.key ?? String.fromCharCode(65 + index)}.</span>{option.text}</li>)}</ol>}
                        {question.officialAnswer && <p className="mt-3 rounded-lg bg-[#e5f3e9] px-3 py-2 text-xs font-semibold text-[#087f3d]">Official answer: {question.officialAnswer}</p>}
                      </details>
                    ))}
                  </div>
                </article>
              ))}
            </section>

            <aside className="h-fit rounded-2xl bg-[#e5f3e9] p-6 ring-1 ring-[#d4e5da] lg:sticky lg:top-6">
              <h2 className="text-xl font-semibold">Topics from past questions</h2>
              <p className="mt-1 text-sm text-[#50685c]">Frequency in available papers</p>
              {data.trends.length ? <div className="mt-5 space-y-5">{data.trends.map((trend) => <div key={trend.topic}><div className="flex items-end justify-between gap-3"><span className="text-sm font-semibold">{trend.topic}</span><span className="shrink-0 text-xs text-[#087f3d]">{trend.questions} · {trend.years} year{trend.years === 1 ? "" : "s"}</span></div><div className="mt-2 h-1.5 overflow-hidden rounded-full bg-[#d4e5da]"><span className="block h-full rounded-full bg-[#087f3d]" style={{ width: `${trend.questions / maxTrend * 100}%` }} /></div></div>)}</div> : <p className="mt-5 text-sm leading-6 text-[#50685c]">Approve suggested topics in the ingestion admin to add topic frequency analysis.</p>}
              <p className="mt-6 rounded-xl bg-white/70 p-3 text-xs leading-5 text-[#50685c]">Historical frequency is descriptive and does not predict future examinations.</p>
            </aside>
          </div>
        )}
      </div>
    </main>
  );
}
