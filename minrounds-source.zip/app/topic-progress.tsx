"use client";
import { useEffect, useRef, useState } from "react";
import { initializeLearning, learningRequest, learningChanged } from "./learning-client";
import type { Progress } from "@/lib/learning-types";
export function TopicProgress({topicSlug}:{topicSlug:string}){
  const [progress,setProgress]=useState<Progress|null>(null);const [error,setError]=useState("");const [ready,setReady]=useState(false);const [busy,setBusy]=useState(false);const seconds=useRef(0);
  useEffect(()=>{let disposed=false;seconds.current=0;const sessionId=crypto.randomUUID();let initialized=false;let activeAt=Date.now();let sent=0;
    const activity=()=>{activeAt=Date.now();};
    const send=()=>{if(initialized)void learningRequest({action:"visit",topicSlug,sessionId,seconds:seconds.current}).catch(e=>{if(!disposed)setError(e.message);});};
    initializeLearning().then(data=>{if(disposed)return;setProgress(data.progress.find(p=>p.topic_slug===topicSlug)??null);setReady(true);initialized=true;send();}).catch(e=>{if(!disposed)setError(e.message);});
    const timer=setInterval(()=>{if(document.visibilityState==="visible"&&Date.now()-activeAt<120000&&initialized)seconds.current++;if(seconds.current-sent>=60){sent=seconds.current;send();}},1000);
    const visibility=()=>{if(document.visibilityState==="hidden")send();else activity();};
    for(const event of ["pointerdown","keydown","scroll","mindrounds-active-study"])window.addEventListener(event,activity,{passive:true});
    document.addEventListener("visibilitychange",visibility);
    return ()=>{disposed=true;clearInterval(timer);send();for(const event of ["pointerdown","keydown","scroll","mindrounds-active-study"])window.removeEventListener(event,activity);document.removeEventListener("visibilitychange",visibility);};
  },[topicSlug]);
  async function update(kind:"completed"|"bookmarked"){setBusy(true);setError("");try{const next=!progress?.[kind];await learningRequest({action:"progress",topicSlug,[kind]:next});setProgress(p=>({...p,topic_slug:topicSlug,completed:p?.completed??0,bookmarked:p?.bookmarked??0,seconds:p?.seconds??0,last_visited:p?.last_visited??new Date().toISOString(),[kind]:next?1:0}));learningChanged();}catch(e){setError(e instanceof Error?e.message:"Could not update progress.");}finally{setBusy(false);}}
  return <div className="my-5 flex flex-wrap items-center gap-3"><button type="button" disabled={!ready||busy} aria-pressed={Boolean(progress?.completed)} onClick={()=>void update("completed")} className={`rounded-full border px-4 py-2 text-sm font-semibold disabled:opacity-40 ${progress?.completed?"bg-[#e5f3e9] text-[#087f3d]":"bg-white"}`}>{progress?.completed?"✓ Topic completed":"Mark completed"}</button><button type="button" disabled={!ready||busy} aria-pressed={Boolean(progress?.bookmarked)} onClick={()=>void update("bookmarked")} className="rounded-full border bg-white px-4 py-2 text-sm font-semibold disabled:opacity-40">{progress?.bookmarked?"★ Bookmarked":"☆ Bookmark"}</button><a href="/study" className="text-sm font-semibold text-[#087f3d]">My study progress →</a>{error&&<p role="alert" className="w-full text-sm text-red-700">{error}</p>}</div>;
}
