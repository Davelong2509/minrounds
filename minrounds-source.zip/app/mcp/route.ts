import {getChatGPTUser} from "@/app/chatgpt-auth";
import {isIngestionAdmin} from "@/lib/admin";
import {operationsStatus,pipelineStep} from "@/lib/operations";
export const dynamic="force-dynamic";
const tools=[
 {name:"psychiatry_content_status",description:"Read material readiness across all active MindRounds courses and recent pipeline runs. Administrator only.",inputSchema:{type:"object",properties:{},additionalProperties:false},annotations:{readOnlyHint:true}},
 {name:"sync_psychiatry_drive",description:"Register new or changed files from every course folder in the configured MindRounds parent Drive folder, automatically discovering new courses. One material equals one topic using its filename. Also find, verify and save relevant YouTube recommendations for materials missing videos. Uses configured OpenAI web search; study answers are not generated. Administrator only.",inputSchema:{type:"object",properties:{},additionalProperties:false},annotations:{readOnlyHint:false,idempotentHint:true}},
];
export async function POST(request:Request){
 let body:{jsonrpc?:string;id?:string|number;method?:string;params?:{name?:string;arguments?:unknown}};
 try{body=await request.json() as typeof body;}catch{return Response.json({jsonrpc:"2.0",id:null,error:{code:-32700,message:"Invalid JSON"}},{status:400});}
 const reply=(result:unknown)=>Response.json({jsonrpc:"2.0",id:body.id??null,result});
 if(body.method==="initialize")return reply({protocolVersion:"2024-11-05",capabilities:{tools:{}},serverInfo:{name:"MindRounds content maintenance",version:"1.0.0"}});
 if(body.method?.startsWith("notifications/"))return new Response(null,{status:202});
 if(body.method==="ping")return reply({});
 if(body.method==="tools/list")return reply({tools});
 if(body.method!=="tools/call")return Response.json({jsonrpc:"2.0",id:body.id??null,error:{code:-32601,message:"Method not found"}});
 const user=await getChatGPTUser();if(!user)return Response.json({error:"Sign in required."},{status:401});if(!isIngestionAdmin(user))return Response.json({error:"Administrator access required."},{status:403});
 try{let result:unknown;if(body.params?.name==="psychiatry_content_status"){const data=await operationsStatus();result={courses:data.courses,documents:data.documents,videoDiscovery:data.videoDiscovery,runs:data.runs};}else if(body.params?.name==="sync_psychiatry_drive")result=await pipelineStep("sync");else throw Error("Unknown maintenance tool.");return reply({content:[{type:"text",text:JSON.stringify(result)}]});}catch(e){return reply({isError:true,content:[{type:"text",text:e instanceof Error?e.message:"Maintenance failed."}]});}
}
export async function GET(){return new Response(null,{status:405});}
