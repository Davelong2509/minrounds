import { notFound } from "next/navigation";
import { ArrowLeft, Brain } from "lucide-react";
import { requireChatGPTUser } from "@/app/chatgpt-auth";
import { isIngestionAdmin } from "@/lib/admin";
import { getIngestionStatus } from "@/lib/psychiatry-data";
import { IngestionAdmin } from "./ingestion-admin";

export const dynamic = "force-dynamic";

export default async function IngestionAdminPage() {
  const user = await requireChatGPTUser("/admin/ingestion");
  if (!isIngestionAdmin(user)) notFound();
  const status = await getIngestionStatus();

  return (
    <main className="min-h-screen bg-[#f2f9f5] px-4 py-6 text-[#063f30] sm:px-8 lg:px-12">
      <div className="mx-auto max-w-6xl">
        <div className="flex items-center justify-between gap-4">
          <a href="/" className="inline-flex items-center gap-2 text-sm font-semibold text-[#087f3d]">
            <ArrowLeft className="h-4 w-4" /> Back to courses
          </a>
          <div className="flex items-center gap-2 text-sm font-semibold text-[#0b513c]">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-[#063f30] text-white"><Brain className="h-4 w-4" /></span>
            MindRounds admin
          </div>
        </div>
        <section className="mt-6 rounded-[28px] bg-[#063f30] p-7 text-white sm:p-10">
          <p className="text-xs font-bold uppercase tracking-[.16em] text-[#b4e3c7]">Content pipeline</p>
          <h1 className="mt-2 text-4xl font-semibold tracking-[-.04em]">MindRounds ingestion</h1>
          <p className="mt-3 max-w-2xl leading-7 text-emerald-50/70">
            Verify the live data connection and register source files from the MindRounds parent Google Drive folder.
          </p>
        </section>
        <div className="mt-5 flex gap-4 text-sm font-semibold text-[#087f3d]"><a href="/admin/operations">Processing queue and usage</a><a href="/admin/videos">Manage videos</a></div><IngestionAdmin initialStatus={status} />
      </div>
    </main>
  );
}
