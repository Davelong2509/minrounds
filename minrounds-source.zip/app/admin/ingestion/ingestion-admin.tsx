"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import {
  CheckCircle2,
  CircleAlert,
  Cloud,
  Database,
  FileText,
  LoaderCircle,
  RefreshCw,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import type { IngestionStatus } from "@/lib/psychiatry-data";

export function IngestionAdmin({ initialStatus }: { initialStatus: IngestionStatus }) {
  const router = useRouter();
  const [syncing, setSyncing] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [indexing, setIndexing] = useState(false);
  const [notice, setNotice] = useState<{ tone: "success" | "error"; text: string } | null>(null);

  async function syncDrive() {
    setSyncing(true);
    setNotice(null);
    try {
      const response = await fetch("/api/admin/ingestion", { method: "POST" });
      let body = (await response.json()) as {
        error?: string;
        result?: { discovered: number; registered: number; refreshed: number; unchanged: number;videos?:{pending:number;added:number;failures:Array<{material:string;error:string}>};failures?:Array<{course:string;error:string}> };
      };
      if (!response.ok || !body.result) throw new Error(body.error || "Drive sync failed.");
      let videosAdded=body.result!.videos?.added??0;
      while((body.result!.videos?.pending??0)>0){setNotice({tone:"success",text:`Saving video recommendations… ${body.result!.videos?.pending} materials remaining.`});const next=await fetch("/api/admin/ingestion",{method:"POST"});const nextBody=await next.json() as typeof body;if(!next.ok||!nextBody.result)throw Error(nextBody.error||"Video sync failed.");body=nextBody;videosAdded+=body.result!.videos?.added??0;}
      if(body.result!.failures?.length){router.refresh();throw Error(body.result!.failures!.map(f=>`${f.course}: ${f.error}`).join("; "));}
      if(body.result!.videos?.failures.length){router.refresh();throw Error(`Materials synced; video lookups need attention: ${body.result!.videos.failures.map(f=>`${f.material}: ${f.error}`).join("; ")}`);}
      setNotice({
        tone: "success",
        text: `Drive scan complete: ${body.result!.registered} new, ${body.result!.refreshed} updated, ${body.result!.unchanged} unchanged. ${videosAdded} video recommendations saved.`,
      });
      router.refresh();
    } catch (error) {
      setNotice({ tone: "error", text: error instanceof Error ? error.message : "Drive sync failed." });
    } finally {
      setSyncing(false);
    }
  }

  async function processNext() {
    setProcessing(true);
    setNotice(null);
    try {
      const response = await fetch("/api/admin/ingestion", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "process_next" }),
      });
      let body = (await response.json()) as {
        error?: string;
        result?: { done?: boolean; processed?: { title: string; pages: number; chunks: number; topics: number } | null };
      };
      if (!response.ok || !body.result) throw new Error(body.error || "Document processing failed.");
      setNotice({
        tone: "success",
        text: body.result.done
          ? "All discovered files have been processed."
          : `Processed ${body.result.processed?.title}: ${body.result.processed?.pages} pages, ${body.result.processed?.chunks} chunks, ${body.result.processed?.topics} material topic.`,
      });
      router.refresh();
    } catch (error) {
      setNotice({ tone: "error", text: error instanceof Error ? error.message : "Document processing failed." });
    } finally {
      setProcessing(false);
    }
  }


  async function indexSources() {
    setIndexing(true);
    setNotice(null);
    try {
      const response = await fetch("/api/admin/ingestion", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "embed_pending" }),
      });
      let body = (await response.json()) as { error?: string; result?: { embedded: number; done: boolean } };
      if (!response.ok || !body.result) throw new Error(body.error || "Semantic indexing failed.");
      setNotice({
        tone: "success",
        text: body.result.embedded
          ? `Indexed ${body.result.embedded} source chunks for semantic retrieval.${body.result.done ? " Indexing is complete." : " Run again to continue."}`
          : "All source chunks are already indexed.",
      });
      router.refresh();
    } catch (error) {
      setNotice({ tone: "error", text: error instanceof Error ? error.message : "Semantic indexing failed." });
    } finally {
      setIndexing(false);
    }
  }

  const canSync = initialStatus.schema.ready && initialStatus.driveConfigured;

  return (
    <div className="mt-7 space-y-6">
      <section className="grid gap-4 md:grid-cols-2">
        <ConnectionCard
          icon={Database}
          title="Supabase database"
          ready={initialStatus.supabaseConfigured && initialStatus.schema.ready}
          description={initialStatus.schema.message}
        />
        <ConnectionCard
          icon={Cloud}
          title="Google Drive source"
          ready={initialStatus.driveConfigured}
          description={initialStatus.driveConfigured ? "Service account and folder ID are configured." : "Drive credentials are missing."}
        />
      </section>

      {!initialStatus.schema.ready && initialStatus.supabaseConfigured && (
        <section className="rounded-2xl border border-[#d4e5da] bg-[#e5f3e9] p-5">
          <div className="flex gap-3">
            <CircleAlert className="mt-0.5 h-5 w-5 shrink-0 text-[#087f3d]" />
            <div>
              <h2 className="font-semibold">Database schema needs to be applied</h2>
              <p className="mt-1 text-sm leading-6 text-[#50685c]">
                Run <code className="rounded bg-white px-1.5 py-0.5">database/migrations/0001_foundation.sql</code> in the Supabase SQL Editor, then reload this page.
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                {initialStatus.schema.tables.map((table) => (
                  <span key={table.name} className={`rounded-full px-2.5 py-1 text-xs font-semibold ${table.ready ? "bg-[#e5f3e9] text-[#087f3d]" : "bg-white text-[#087f3d]"}`}>
                    {table.name}: {table.ready ? "ready" : "missing"}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </section>
      )}

      {initialStatus.schema.ready && !initialStatus.semanticReady && (
        <section className="rounded-2xl border border-[#d4e5da] bg-[#e5f3e9] p-5">
          <div className="flex gap-3">
            <CircleAlert className="mt-0.5 h-5 w-5 shrink-0 text-[#3b8062]" />
            <div><h2 className="font-semibold">Enable semantic retrieval</h2><p className="mt-1 text-sm leading-6 text-[#50685c]">Run <code className="rounded bg-white px-1.5 py-0.5">database/migrations/0002_semantic_rag.sql</code> in the Supabase SQL Editor. Ask AI will use text matching until this migration is applied.</p></div>
          </div>
        </section>
      )}

      <section className="rounded-2xl border border-[#d4e5da] bg-white p-6 shadow-[0_12px_35px_rgba(6,63,48,.05)]">
        <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-center">
          <div>
            <p className="text-xs font-bold uppercase tracking-[.14em] text-[#087f3d]">Drive discovery</p>
            <h2 className="mt-1 text-2xl font-semibold tracking-[-.025em]">Register source files</h2>
            <p className="mt-1 text-sm text-[#50685c]">A repeat scan only adds new files or refreshes changed files.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button onClick={syncDrive} disabled={!canSync || syncing || processing || indexing} variant="outline" className="h-11 rounded-xl border-[#d4e5da] bg-white px-5">
              {syncing ? <LoaderCircle className="mr-2 h-4 w-4 animate-spin" /> : <RefreshCw className="mr-2 h-4 w-4" />}
              {syncing ? "Scanning Drive…" : "Sync Drive"}
            </Button>
            <Button onClick={processNext} disabled={!canSync || syncing || processing || indexing || initialStatus.counts.discovered === 0} className="h-11 rounded-xl bg-[#087f3d] px-5 text-white hover:bg-[#087f3d]">
              {processing ? <LoaderCircle className="mr-2 h-4 w-4 animate-spin" /> : <FileText className="mr-2 h-4 w-4" />}
              {processing ? "Extracting document…" : "Process next file"}
            </Button>
            <Button onClick={indexSources} disabled={!canSync || syncing || processing || indexing || initialStatus.counts.unembedded === 0} variant="outline" className="h-11 rounded-xl border-[#087f3d] bg-white px-5 text-[#0b513c]">
              {indexing ? <LoaderCircle className="mr-2 h-4 w-4 animate-spin" /> : <Database className="mr-2 h-4 w-4" />}
              {indexing ? "Indexing sources…" : `Index semantic search (${initialStatus.counts.unembedded})`}
            </Button>
          </div>
        </div>
        {notice && (
          <p role="status" className={`mt-4 rounded-xl p-3 text-sm ${notice.tone === "success" ? "bg-[#e5f3e9] text-[#087f3d]" : "bg-[#e5f3e9] text-[#087f3d]"}`}>
            {notice.text}
          </p>
        )}
      </section>

      <section className="overflow-hidden rounded-2xl border border-[#d4e5da] bg-white">
        <div className="border-b border-[#eaf4ee] px-5 py-4">
          <h2 className="font-semibold">Material-based topics</h2>
          <p className="mt-1 text-sm text-[#50685c]">Each registered Drive material appears as one topic using its filename. No topic approval or splitting is needed.</p>
        </div>
      </section>

      <section>
        <div className="flex items-end justify-between gap-4">
          <div><p className="text-xs font-bold uppercase tracking-[.14em] text-[#50685c]">Current database state</p><h2 className="mt-1 text-2xl font-semibold">Ingestion status</h2></div>
          <span className="text-sm font-semibold text-[#087f3d]">{initialStatus.counts.total} files registered</span>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-6">
          {["discovered", "queued", "processing", "ready", "failed", "unembedded"].map((key) => (
            <div key={key} className="rounded-2xl border border-[#d4e5da] bg-white p-4">
              <p className="text-2xl font-semibold">{initialStatus.counts[key] ?? 0}</p>
              <p className="mt-1 text-sm capitalize text-[#50685c]">{key === "unembedded" ? "Needs semantic index" : key}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="overflow-hidden rounded-2xl border border-[#d4e5da] bg-white">
        <div className="border-b border-[#eaf4ee] px-5 py-4"><h2 className="font-semibold">Recently registered files</h2></div>
        {initialStatus.recentDocuments.length ? initialStatus.recentDocuments.map((document) => (
          <div key={document.id} className="flex items-center gap-3 border-b border-[#eaf4ee] px-5 py-4 last:border-0">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#eaf4ee] text-[#087f3d]"><FileText className="h-4 w-4" /></span>
            <div className="min-w-0 flex-1"><p className="truncate font-medium">{document.title}</p><p className="mt-0.5 text-xs text-[#60776a]">{document.documentType.replaceAll("_", " ")} · {new Date(document.discoveredAt).toLocaleString()}</p></div>
            <span className="rounded-full bg-[#eaf4ee] px-2.5 py-1 text-xs font-semibold capitalize text-[#3b8062]">{document.status}</span>
          </div>
        )) : (
          <div className="px-5 py-10 text-center text-sm text-[#50685c]">No Drive files have been registered yet.</div>
        )}
      </section>
    </div>
  );
}

function ConnectionCard({ icon: Icon, title, ready, description }: { icon: typeof Database; title: string; ready: boolean; description: string }) {
  return (
    <div className="rounded-2xl border border-[#d4e5da] bg-white p-5">
      <div className="flex items-start gap-4">
        <span className={`grid h-11 w-11 shrink-0 place-items-center rounded-xl ${ready ? "bg-[#e5f3e9] text-[#087f3d]" : "bg-[#e5f3e9] text-[#087f3d]"}`}><Icon className="h-5 w-5" /></span>
        <div><div className="flex items-center gap-2"><h2 className="font-semibold">{title}</h2>{ready ? <CheckCircle2 className="h-4 w-4 text-[#087f3d]" /> : <CircleAlert className="h-4 w-4 text-[#087f3d]" />}</div><p className="mt-1 text-sm leading-6 text-[#50685c]">{description}</p></div>
      </div>
    </div>
  );
}
