import {notFound} from "next/navigation";
import {requireChatGPTUser} from "@/app/chatgpt-auth";
import {isIngestionAdmin} from "@/lib/admin";
import {getAllDashboardData} from "@/lib/psychiatry-data";
import {StudyShell} from "@/app/study-shell";
import {VideoManager} from "./video-manager";
export const dynamic="force-dynamic";
export default async function Page(){if(!isIngestionAdmin(await requireChatGPTUser("/admin/videos")))notFound();const data=await getAllDashboardData();return <StudyShell title="Manage teaching videos" subtitle="Add, hide or check video recommendations for each material."><VideoManager topics={data.topics}/></StudyShell>;}
