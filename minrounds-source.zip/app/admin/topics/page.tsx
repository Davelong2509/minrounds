import { notFound } from "next/navigation";
import { requireChatGPTUser } from "@/app/chatgpt-auth";
import { isIngestionAdmin } from "@/lib/admin";
import {getCourses} from "@/lib/courses";
import { getTopicGraph } from "@/lib/topic-data";
import { TopicAdmin } from "./topic-admin";
export const dynamic="force-dynamic";
export default async function Page(){
  if(!isIngestionAdmin(await requireChatGPTUser("/admin/topics"))) notFound();
  let graphs:Array<{name:string;graph:Awaited<ReturnType<typeof getTopicGraph>>}>=[];let error;
  try{const courses=await getCourses();graphs=await Promise.all(courses.map(async c=>({name:c.name,graph:await getTopicGraph(c.id)})));}catch(e){error=e instanceof Error?e.message:"Topic data is unavailable.";}
  return <main className="min-h-screen bg-[#f2f9f5] px-4 py-6 text-[#063f30] sm:px-8"><div className="mx-auto max-w-6xl"><div className="flex justify-between text-sm font-semibold text-[#087f3d]"><a href="/">← All courses</a><a href="/admin/ingestion">Ingestion admin</a></div><header className="my-6 rounded-3xl bg-[#063f30] p-8 text-white"><p className="text-sm text-[#b4e3c7]">MindRounds content review</p><h1 className="mt-2 text-3xl font-semibold">Manage topics</h1><p className="mt-3 text-emerald-100/75">One Drive material equals one topic. Filenames determine topic titles automatically.</p></header>{error?<p role="alert" className="rounded-xl bg-white p-6">{error}</p>:graphs.map(c=><section key={c.graph.courseId} className="mb-6"><h2 className="mb-3 text-2xl font-semibold">{c.name}</h2><TopicAdmin graph={c.graph}/></section>)}</div></main>;
}
