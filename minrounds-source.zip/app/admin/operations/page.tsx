import {notFound} from "next/navigation";
import {requireChatGPTUser} from "@/app/chatgpt-auth";
import {isIngestionAdmin} from "@/lib/admin";
import {StudyShell} from "@/app/study-shell";
import {OperationsPanel} from "./operations-panel";
export const dynamic="force-dynamic";
export default async function Page(){if(!isIngestionAdmin(await requireChatGPTUser("/admin/operations")))notFound();return <StudyShell title="Content and usage admin"><OperationsPanel/></StudyShell>;}
