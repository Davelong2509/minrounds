"use client";
import { useId, useState } from "react";
import type { StudyMCQ, StudyFlashcard } from "@/lib/study-types";

function PracticeQuestion({item,index}:{item:StudyMCQ;index:number}) {
  const inputGroup=useId();
  const [selected,setSelected]=useState<number|null>(null);
  const [reviewed,setReviewed]=useState(false);
  return <section className="rounded-xl border border-[#d4e5da] bg-white p-4">
    <h3 className="font-semibold">{index+1}. {item.question}</h3>
    <div className="mt-3 space-y-2">{item.options.map((option,i)=><label key={i} className={`flex cursor-pointer items-start gap-3 rounded-lg border p-3 text-sm ${reviewed&&i===item.correct_index?"border-emerald-400 bg-emerald-50":selected===i?"border-[#087f3d] bg-emerald-50":"border-[#d4e5da]"}`}>
      <input type="radio" name={inputGroup} checked={selected===i} disabled={reviewed} onChange={()=>setSelected(i)} className="mt-1"/><span><strong>{String.fromCharCode(65+i)}.</strong> {option}</span>
    </label>)}</div>
    <button type="button" disabled={selected===null||reviewed} onClick={()=>setReviewed(true)} className="mt-3 rounded-lg bg-[#0b513c] px-4 py-2 text-sm font-semibold text-white disabled:opacity-40">Check answer</button>
    {reviewed&&<div role="status" className="mt-3 rounded-lg bg-[#f2f9f5] p-3 text-sm leading-6"><strong>{selected===item.correct_index?"Correct.":`Correct answer: ${String.fromCharCode(65+item.correct_index)}.`}</strong><p>{item.explanation}</p><p className="mt-1 text-xs text-[#50685c]">Source {item.source_numbers.map(n=>`[${n}]`).join(" ")}</p><button type="button" onClick={()=>{setReviewed(false);setSelected(null);}} className="mt-2 font-semibold text-[#087f3d]">Try again</button></div>}
  </section>;
}
export function MCQPractice({items}:{items:StudyMCQ[]}) {
  return <div className="mt-4 space-y-4"><p className="text-xs font-semibold text-[#50685c]">AI-generated practice · Based on this material</p>{items.map((item,index)=><PracticeQuestion key={`${index}-${item.question}`} item={item} index={index}/>)}</div>;
}
export function FlashcardPractice({items}:{items:StudyFlashcard[]}) {
  const [index,setIndex]=useState(0);const [revealed,setRevealed]=useState(false);
  const item=items[index];if(!item)return null;
  function move(delta:number){setIndex(i=>(i+delta+items.length)%items.length);setRevealed(false);}
  return <section className="mt-4 rounded-2xl border border-[#d4e5da] bg-white p-5"><p className="text-xs font-semibold text-[#50685c]">AI-generated flashcards · {index+1} of {items.length}</p><div className="my-6 min-h-28"><h3 className="text-lg font-semibold">{item.front}</h3>{revealed&&<div role="status" className="mt-4 border-t pt-4"><p className="whitespace-pre-wrap text-sm leading-6">{item.back}</p><p className="mt-3 text-xs text-[#50685c]">Source {item.source_numbers.map(n=>`[${n}]`).join(" ")}</p></div>}</div><div className="flex flex-wrap justify-between gap-2"><button type="button" onClick={()=>move(-1)} className="rounded-lg border px-3 py-2 text-sm">← Previous</button><button type="button" onClick={()=>setRevealed(!revealed)} className="rounded-lg bg-[#0b513c] px-4 py-2 text-sm font-semibold text-white">{revealed?"Hide answer":"Reveal answer"}</button><button type="button" onClick={()=>move(1)} className="rounded-lg border px-3 py-2 text-sm">Next →</button></div></section>;
}

function inline(text:string){return text.split(/(\*\*[^*]+\*\*)/g).map((part,i)=>part.startsWith("**")?<strong key={i}>{part.slice(2,-2)}</strong>:part);}
export function StudyText({text}:{text:string}) {
  return <div className="space-y-2 text-sm leading-6">{text.split("\n").map((line,i)=>{
    if(!line.trim())return <div key={i} className="h-1"/>;
    if(/^#{1,4} /.test(line))return <h3 key={i} className="pt-2 text-base font-semibold">{inline(line.replace(/^#{1,4} /,""))}</h3>;
    if(/^[-*] /.test(line))return <p key={i} className="pl-3">• {inline(line.slice(2))}</p>;
    return <p key={i}>{inline(line)}</p>;
  })}</div>;
}
