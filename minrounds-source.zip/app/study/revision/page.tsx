import {StudyShell} from "../../study-shell";
import {RevisionQueue} from "../../study-hub";
import {getAllDashboardData} from "@/lib/psychiatry-data";
export const dynamic="force-dynamic";
export default async function Page(){const data=await getAllDashboardData();return <StudyShell title="Flashcard revision"><RevisionQueue topics={data.topics}/></StudyShell>;}
