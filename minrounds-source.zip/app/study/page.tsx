import {StudyShell} from "../study-shell";
import {PersonalStudy} from "../study-hub";
import {getAllDashboardData} from "@/lib/psychiatry-data";
export const dynamic="force-dynamic";
export default async function Page(){const data=await getAllDashboardData();return <StudyShell title="My study" subtitle="Your progress, bookmarks and saved quiz performance."><PersonalStudy topics={data.topics}/></StudyShell>;}
