import {StudyShell} from "../../study-shell";
import {StudyPlanner} from "../../study-hub";
import {getAllDashboardData} from "@/lib/psychiatry-data";
export const dynamic="force-dynamic";
export default async function Page(){const data=await getAllDashboardData();return <StudyShell title="Study planner"><StudyPlanner topics={data.topics}/></StudyShell>;}
