import {StudyShell} from "../../study-shell";
import {ExamPractice} from "../../study-hub";
import {getAllDashboardData} from "@/lib/psychiatry-data";
export const dynamic="force-dynamic";
export default async function Page(){const data=await getAllDashboardData();return <StudyShell title="Timed exam practice"><ExamPractice topics={data.topics}/></StudyShell>;}
