"use client";
import { useEffect, useRef, useState } from "react";
import { initializeLearning, getLearning, learningRequest } from "./learning-client";
import { youtubeEmbedUrl, type TeachingVideo } from "@/lib/video-catalog";

type Player = { destroy(): void; getCurrentTime(): number; getDuration(): number };
type YouTube = { Player: new (element: HTMLIFrameElement, options: { events: { onError: (event: { data: number }) => void; onStateChange: (event: {data:number}) => void } }) => Player };
type VideoWindow = Window & { YT?: YouTube; onYouTubeIframeAPIReady?: () => void };
let apiPromise: Promise<YouTube> | undefined;
function playerApi(): Promise<YouTube> {
  const w = window as VideoWindow;
  if (w.YT?.Player) return Promise.resolve(w.YT);
  if (apiPromise) return apiPromise;
  apiPromise = new Promise((resolve, reject) => {
    const previous = w.onYouTubeIframeAPIReady;
    const timer = setTimeout(() => { apiPromise = undefined; reject(new Error("Player controls unavailable")); }, 15000);
    w.onYouTubeIframeAPIReady = () => { previous?.(); clearTimeout(timer); if (w.YT) resolve(w.YT); };
    if (!document.querySelector('script[src="https://www.youtube.com/iframe_api"]')) {
      const script = document.createElement("script");
      script.src = "https://www.youtube.com/iframe_api";
      script.onerror = () => { clearTimeout(timer); script.remove(); apiPromise = undefined; reject(new Error("Player controls unavailable")); };
      document.head.appendChild(script);
    }
  });
  return apiPromise;
}
export function RecommendedVideos({ videos, topicSlug }: { videos: TeachingVideo[]; topicSlug: string }) {
  const [selected, setSelected] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [attempt, setAttempt] = useState(0);
  const [watches,setWatches]=useState<Array<{video_id:string;position:number;completed:number}>>([]);
  const host = useRef<HTMLDivElement>(null);
  const active = videos.find(v => v.id === selected);
  useEffect(() => {
    setSelected(null); setError(null);
    let canceled=false;
    initializeLearning().then(()=>getLearning(`?topicSlug=${topicSlug}`)).then(data=>{if(!canceled)setWatches(data.watches);}).catch(()=>{});
    return()=>{canceled=true;};
  }, [topicSlug]);
  useEffect(() => {
    if (!active || !host.current) return;
    let disposed = false;
    let player: Player | undefined;
    const frame = document.createElement("iframe");
    const save=()=>{if(!player||typeof player.getCurrentTime!=="function"||typeof player.getDuration!=="function")return;const position=player.getCurrentTime();const duration=player.getDuration();if(!Number.isFinite(position)||!duration)return;void learningRequest({action:"video",topicSlug,videoId:active.id,position,duration}).then(()=>{if(!disposed)setWatches(previous=>[...previous.filter(w=>w.video_id!==active.id),{video_id:active.id,position:Math.floor(position),completed:position/duration>=.9?1:0}]);}).catch(()=>{});};
    const embed=new URL(youtubeEmbedUrl(active.id,window.location.origin));
    const watch=watches.find(w=>w.video_id===active.id);
    if(watch&&!watch.completed&&watch.position>0)embed.searchParams.set("start",String(Math.floor(watch.position)));
    frame.src=embed.toString();
    frame.title = active.title;
    frame.className = "absolute inset-0 h-full w-full border-0";
    frame.allow = "accelerometer; encrypted-media; gyroscope; picture-in-picture; fullscreen";
    frame.allowFullscreen = true;
    frame.referrerPolicy = "strict-origin-when-cross-origin";
    host.current.replaceChildren(frame);
    let timer:ReturnType<typeof setInterval>|undefined;
    playerApi().then(api => {
      if (disposed) return;
      player = new api.Player(frame, { events: { onError: () => {
        if (!disposed) setError("This video cannot play here right now. Try another recommendation or retry the player.");
      },onStateChange: event=>{
        if(timer)clearInterval(timer);
        if(event.data===1){window.dispatchEvent(new Event("mindrounds-active-study"));timer=setInterval(()=>{if(document.visibilityState==="visible")window.dispatchEvent(new Event("mindrounds-active-study"));save();},15000);}
        else if(event.data===0||event.data===2)save();
      } } });
    }).catch(() => {});
    return () => { save(); disposed = true; if(timer)clearInterval(timer); player?.destroy(); frame.remove(); };
  }, [active, attempt]);
  return <section id="videos" className="mt-6 scroll-mt-6 rounded-2xl border bg-white p-6">
    <div className="flex flex-wrap items-start justify-between gap-3"><div><p className="text-xs font-bold uppercase tracking-widest text-[#087f3d]">Watch and learn</p><h2 className="mt-1 text-xl font-semibold">Recommended YouTube videos</h2></div><span className="rounded-full bg-[#e5f3e9] px-3 py-1 text-xs font-semibold text-[#087f3d]">Watch on MindRounds</span></div>
    <p className="mt-3 text-sm leading-6 text-[#50685c]">Teaching videos matched to this material’s subject. These supplement your notes and may cover only part of the material. Choose a video to load the player.</p>
    {!videos.length ? <p className="mt-4 rounded-xl bg-[#f2f9f5] p-4 text-sm">No verified video recommendation is available yet. Recommendations are checked during Drive sync.</p> : <div className="mt-5 grid gap-5 lg:grid-cols-[1.4fr_1fr]">
      <div>
        <div className="relative aspect-video min-h-[200px] overflow-hidden rounded-xl bg-[#063f30]">
          <div ref={host} className="absolute inset-0" />
          {!active && <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-5 text-center text-white"><span aria-hidden="true" className="text-4xl">▶</span><p className="font-semibold">Learn with a video</p><button type="button" onClick={() => { setSelected(videos[0].id); setError(null); }} className="rounded-xl bg-[#b4e3c7] px-5 py-3 font-semibold text-[#063f30]">Watch first recommendation</button></div>}
        </div>
        {active && <div className="mt-3"><h3 className="font-semibold">{active.title}</h3><p className="mt-1 text-sm text-[#50685c]">{active.publisher} · YouTube</p></div>}
        {error && <div role="alert" className="mt-3 rounded-xl bg-amber-50 p-4 text-sm"><p>{error}</p><button type="button" onClick={() => { setError(null); setAttempt(v => v + 1); }} className="mt-2 font-semibold underline">Retry player</button></div>}
        <p className="mt-3 text-xs leading-5 text-[#50685c]">Use the player’s caption, speed and fullscreen controls. Playback depends on YouTube and the publisher’s embedding permissions.</p>
      </div>
      <div className="space-y-3" aria-label="Video recommendations">{videos.map(v => <button key={v.id} type="button" aria-pressed={selected === v.id} onClick={() => { setSelected(v.id); setError(null); }} className={`w-full rounded-xl border p-4 text-left transition-colors hover:bg-[#f2f9f5] ${selected === v.id ? "border-[#087f3d] bg-[#e5f3e9]" : "border-[#d4e5da]"}`}><span className="block text-sm font-semibold">{v.title}</span><span className="mt-1 block text-xs font-semibold text-[#087f3d]">{v.publisher}</span><span className="mt-2 block text-xs leading-5 text-[#50685c]">{v.focus}</span><span className="mt-3 block text-xs font-bold text-[#087f3d]">{watches.some(w=>w.video_id===v.id&&w.completed)?"✓ Watched · watch again":selected === v.id ? "Selected · watch above" : watches.some(w=>w.video_id===v.id&&w.position>0)?"Resume here":"▶ Watch here"}</span></button>)}</div>
    </div>}
  </section>;
}
