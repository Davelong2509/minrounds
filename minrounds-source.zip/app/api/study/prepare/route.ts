import { NextResponse } from "next/server";
import { prepareStudyMaterial } from "@/lib/material-study";
import { allowStudyRequest } from "@/lib/study-limits";
export const dynamic = "force-dynamic";
export async function POST(request:Request) {
  const origin=request.headers.get("origin");
  if(origin && origin!==new URL(request.url).origin) return NextResponse.json({error:"Invalid request origin."},{status:403});
  try {
  if(!await allowStudyRequest(request,"prepare",30)) return NextResponse.json({error:"Please wait a minute before preparing another material."},{status:429});
    const body=await request.json() as {topicSlug?:string;localOnly?:boolean};
    if(typeof body.topicSlug!=="string") return NextResponse.json({error:"Choose a material."},{status:400});
    return NextResponse.json(await prepareStudyMaterial(body.topicSlug,body.localOnly===true));
  } catch(error) {
    return NextResponse.json({error:error instanceof Error?error.message:"The material could not be prepared."},{status:422});
  }
}
