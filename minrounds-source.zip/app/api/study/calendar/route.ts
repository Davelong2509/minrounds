import {learningData} from "@/lib/learning";
import {revisionSchedule} from "@/lib/learning-types";
import {studyCalendar} from "@/lib/study-export";
import {getAllDashboardData} from "@/lib/psychiatry-data";
export const dynamic="force-dynamic";
export async function GET(request:Request){try{const [data,course]=await Promise.all([learningData(),getAllDashboardData()]);if(!data.plan)return Response.json({error:"Save a study plan first."},{status:404});const calendar=studyCalendar(revisionSchedule(course.topics,data.progress,data.plan),data.plan.reminder_hour,data.plan.timezone,new URL(request.url).origin);return new Response(calendar,{headers:{"Content-Type":"text/calendar; charset=utf-8","Content-Disposition":"attachment; filename=mindrounds-revision.ics","Cache-Control":"private, no-store"}});}catch{return Response.json({error:"Your calendar could not be exported."},{status:503});}}
