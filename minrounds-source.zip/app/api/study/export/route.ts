import {studyOwner} from "@/lib/saved-study";
import {ownedStudy} from "@/lib/learning";
import {studyMarkdown,printableStudy} from "@/lib/study-export";
export const dynamic="force-dynamic";
export async function GET(request:Request){try{const u=new URL(request.url);const {owner}=await studyOwner();const saved=await ownedStudy(owner,u.searchParams.get("resultId")??"");const text=studyMarkdown(saved.question,saved.result,saved.created_at);const print=u.searchParams.get("format")==="print";return new Response(print?printableStudy(text):text,{headers:{"Content-Type":print?"text/html; charset=utf-8":"text/markdown; charset=utf-8","Cache-Control":"private, no-store",...(print?{"Content-Security-Policy":"default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'"}:{"Content-Disposition":`attachment; filename="mindrounds-${saved.id}.md"`})}});}catch{return Response.json({error:"This saved result is unavailable for your account."},{status:404});}}
