import { NextResponse } from "next/server";
import { materialVersion, studyHistory, studyOwner } from "@/lib/saved-study";
export const dynamic="force-dynamic";
export async function GET(request:Request){
  try{
    const url=new URL(request.url);const topicSlug=url.searchParams.get("topicSlug")??"";
    const offset=Math.max(0,Math.min(100000,Number(url.searchParams.get("offset"))||0));
    const identity=await studyOwner();
    const sourceVersion=await materialVersion(topicSlug);
    return NextResponse.json({...await studyHistory(identity.owner,topicSlug,Math.floor(offset)),sourceVersion,signedIn:identity.signedIn},{headers:{"Cache-Control":"private, no-store"}});
  }catch(error){return NextResponse.json({error:error instanceof Error?error.message:"Saved study results could not be loaded."},{status:500,headers:{"Cache-Control":"private, no-store"}});}
}
