import { NextResponse } from "next/server";
import { answerPsychiatryQuestion } from "@/lib/rag";
import { STUDY_MODES, type StudyMode } from "@/lib/study-types";
import { prepareStudyMaterial } from "@/lib/material-study";
import { allowStudyRequest } from "@/lib/study-limits";
import { savedStudyGeneration } from "@/lib/study-generation";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const origin = request.headers.get("origin");
  if (origin && origin !== new URL(request.url).origin) return NextResponse.json({ error: "Invalid request origin." }, { status: 403 });
  try {
    const body = (await request.json()) as { question?: string; topicSlug?: string; studyMode?: string; force?:boolean;courseSlug?:string };
    const question = body.question?.trim() ?? "";
    if (question.length < 3 || question.length > 1200) {
      return NextResponse.json({ error: "Enter a question between 3 and 1,200 characters." }, { status: 400 });
    }
    const topicSlug = body.topicSlug?.trim();
    if(body.courseSlug&&!/^[a-z0-9-]{1,100}$/.test(body.courseSlug))return NextResponse.json({error:"Invalid course."},{status:400});
    if (topicSlug && !/^[a-z0-9-]{1,100}$/.test(topicSlug)) {
      return NextResponse.json({ error: "Invalid topic." }, { status: 400 });
    }
    if(body.studyMode && !STUDY_MODES.includes(body.studyMode as StudyMode)) return NextResponse.json({error:"Choose a valid study tool."},{status:400});
    if(body.studyMode && !topicSlug) return NextResponse.json({error:"Select a material topic first."},{status:400});
    if(body.force!==undefined && typeof body.force!=="boolean") return NextResponse.json({error:"Invalid regeneration option."},{status:400});
    const generate=async()=>{
      if(!await allowStudyRequest(request,"answer"))throw new Error("Your study request limit has been reached. Wait a minute, or return tomorrow if your daily allowance is used.");
      if(topicSlug){
        const prepared=await prepareStudyMaterial(topicSlug);
        if(!prepared.ready)throw new Error(prepared.message||"This material is being prepared. Please retry shortly.");
      }
      return answerPsychiatryQuestion(question,topicSlug,body.studyMode as StudyMode|undefined,body.courseSlug);
    };
    if(topicSlug){
      const result=await savedStudyGeneration(topicSlug,question,body.studyMode as StudyMode|undefined,body.force===true,generate);
      if("busy" in result)return NextResponse.json({error:"This response is already being generated. Please wait and reopen the saved history.",busy:true},{status:409});
      return NextResponse.json(result,{headers:{"Cache-Control":"private, no-store"}});
    }
    return NextResponse.json(await generate(),{headers:{"Cache-Control":"private, no-store"}});
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "The tutor could not answer right now." }, { status: error instanceof Error && error.message.includes("request limit") ? 429 : 500 });
  }
}
