import { NextResponse } from "next/server";
import { getChatGPTUser } from "@/app/chatgpt-auth";
import { isIngestionAdmin } from "@/lib/admin";
import { manageTopic, type TopicAction } from "@/lib/topic-management";
export const dynamic="force-dynamic";
export async function POST(request:Request) {
  if(!isIngestionAdmin(await getChatGPTUser())) return NextResponse.json({error:"Admin access is required."},{status:403});
  const origin=request.headers.get("origin");if(origin && origin!==new URL(request.url).origin) return NextResponse.json({error:"Invalid origin."},{status:403});
  try {return NextResponse.json(await manageTopic(await request.json() as TopicAction));}
  catch(error){return NextResponse.json({error:error instanceof Error?error.message:"Changes could not be saved."},{status:400});}
}
