import {getChatGPTUser} from "@/app/chatgpt-auth";
import {isIngestionAdmin} from "@/lib/admin";
import {manageVideo,topicVideos} from "@/lib/managed-videos";
import {documentCourse} from "@/lib/courses";
import {getTopicDetail} from "@/lib/topic-data";
export const dynamic="force-dynamic";
export async function GET(request:Request){if(!isIngestionAdmin(await getChatGPTUser()))return Response.json({error:"Admin access required."},{status:403});try{const slug=new URL(request.url).searchParams.get("topicSlug")??"";const detail=await getTopicDetail(slug);if(!detail)return Response.json({error:"Material not found."},{status:404});return Response.json({videos:await topicVideos(slug,detail.topic.canonical_name,true,(await documentCourse(detail.topic.id))?.slug??"")},{headers:{"Cache-Control":"private, no-store"}});}catch{return Response.json({error:"Videos unavailable."},{status:503});}}
export async function POST(request:Request){if(!isIngestionAdmin(await getChatGPTUser()))return Response.json({error:"Admin access required."},{status:403});const origin=request.headers.get("origin");if(origin&&origin!==new URL(request.url).origin)return Response.json({error:"Invalid request origin."},{status:403});try{return Response.json(await manageVideo(await request.json()));}catch(e){return Response.json({error:e instanceof Error?e.message:"Video could not be updated."},{status:422});}}
