import { NextResponse } from "next/server";
import { getChatGPTUser } from "@/app/chatgpt-auth";
import { isIngestionAdmin } from "@/lib/admin";
import { pipelineStep } from "@/lib/operations";
import { getIngestionStatus } from "@/lib/psychiatry-data";
import { approveSuggestedTopic, embedPendingChunks, processNextDocument } from "@/lib/document-processing";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getChatGPTUser();
  if (!isIngestionAdmin(user)) {
    return NextResponse.json({ error: "Admin access is required." }, { status: 403 });
  }

  try {
    return NextResponse.json(await getIngestionStatus());
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Status could not be loaded." },
      { status: 500 },
    );
  }
}

export async function POST(request: Request) {
  const user = await getChatGPTUser();
  const configuredSyncSecret = process.env.INGESTION_SYNC_SECRET;
  const suppliedSyncSecret = request.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
  const automationAuthorized = Boolean(
    configuredSyncSecret && suppliedSyncSecret && suppliedSyncSecret === configuredSyncSecret,
  );
  if (!isIngestionAdmin(user) && !automationAuthorized) {
    return NextResponse.json({ error: "Admin access is required." }, { status: 403 });
  }

  const origin = request.headers.get("origin");
  if (!automationAuthorized && origin && origin !== new URL(request.url).origin) {
    return NextResponse.json({ error: "Invalid request origin." }, { status: 403 });
  }

  try {
    const body = (await request.json().catch(() => ({}))) as {
      action?: "sync" | "process_next" | "approve_topic" | "embed_pending";
      topicId?: string;
    };
    const action = body.action ?? "sync";
    const result =
      action === "process_next"
        ? await pipelineStep("process")
        : action === "embed_pending"
          ? await pipelineStep("index")
        : action === "approve_topic"
          ? await approveSuggestedTopic(body.topicId ?? "")
          : await pipelineStep("sync");
    return NextResponse.json({ ok: true, result });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Drive sync failed." },
      { status: 500 },
    );
  }
}
