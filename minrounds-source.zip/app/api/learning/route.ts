import { NextResponse } from "next/server";
import { learningData, learningMutation } from "@/lib/learning";
export const dynamic="force-dynamic";
export async function GET(request:Request){try{const u=new URL(request.url);return NextResponse.json(await learningData(u.searchParams.get("resultId")??undefined,u.searchParams.get("topicSlug")??undefined),{headers:{"Cache-Control":"private, no-store"}});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Learning data unavailable."},{status:503});}}
export async function POST(request:Request){const origin=request.headers.get("origin");if(origin&&origin!==new URL(request.url).origin)return NextResponse.json({error:"Invalid request origin."},{status:403});try{return NextResponse.json(await learningMutation(await request.json()),{headers:{"Cache-Control":"private, no-store"}});}catch(e){return NextResponse.json({error:e instanceof Error?e.message:"Could not save learning progress."},{status:422});}}
