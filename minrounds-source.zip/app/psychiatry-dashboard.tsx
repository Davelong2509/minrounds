"use client";

import { useMemo, useState } from "react";
import {
  ArrowRight,
  BookOpen,
  Brain,
  ChevronRight,
  CircleHelp,
  Clock3,
  FileText,
  GraduationCap,
  History,
  Library,
  Menu,
  MessageSquareText,
  Search,
  Settings,
  Sparkles,
  Stethoscope,
  X,
} from "lucide-react";
import { Input } from "@/components/ui/input";
import type { DashboardData } from "@/lib/psychiatry-data";
import { PersonalStudy } from "./study-hub";
import { AskTutor } from "./ask-tutor";

const topicAccents = ["#087f3d", "#149b48", "#64b88a", "#8ec9a1", "#3b8062"];

const navItems = [
  { label: "Course home", icon: BookOpen, active: true },
  { label: "Topics", icon: Library },
  { label: "My study", icon: GraduationCap },
  { label: "Study planner", icon: Clock3 },
  { label: "Past questions", icon: History },
  { label: "Ask AI", icon: MessageSquareText },
  { label: "Ingestion admin", icon: Settings },
  { label: "Topic admin", icon: Settings },
  { label: "Content and usage", icon: Settings },
];

type Props = { studentName: string; dashboard: DashboardData; isAdmin?:boolean;courseSlug?:string;courseName?:string };

export function PsychiatryDashboard({ studentName, dashboard, isAdmin=false,courseSlug="psychiatry",courseName="Psychiatry" }: Props) {
  const [query, setQuery] = useState("");
  const [mobileNav, setMobileNav] = useState(false);

  const filteredTopics = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return dashboard.topics;
    return dashboard.topics.filter((topic) => topic.name.toLowerCase().includes(needle));
  }, [dashboard.topics, query]);

  return (
    <div className="min-h-screen bg-[#f2f9f5] text-[#063f30]">
      <div className="mx-auto flex min-h-screen max-w-[1600px]">
        <aside className={`fixed inset-y-0 left-0 z-50 flex w-[278px] flex-col bg-[#063f30] px-5 py-6 text-white transition-transform lg:sticky lg:top-0 lg:h-screen lg:translate-x-0 ${mobileNav ? "translate-x-0" : "-translate-x-full"}`}>
          <div className="flex items-center justify-between px-2">
            <a href="#top" className="flex items-center gap-3" aria-label="MindRounds home">
              <span className="grid h-10 w-10 place-items-center rounded-xl bg-[#087f3d] shadow-[0_10px_30px_rgba(20,155,72,.28)]"><Brain className="h-5 w-5" strokeWidth={2.2} /></span>
              <span><span className="block text-[1.02rem] font-semibold tracking-tight">MindRounds</span><span className="block text-[0.69rem] font-medium uppercase tracking-[.18em] text-emerald-200/60">Medical study</span></span>
            </a>
            <button onClick={() => setMobileNav(false)} className="rounded-lg p-2 text-emerald-100 lg:hidden" aria-label="Close navigation"><X className="h-5 w-5" /></button>
          </div>

          <div className="mt-9 rounded-2xl border border-white/10 bg-white/[.06] p-4">
            <div className="flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-[#0b513c] text-emerald-100"><Stethoscope className="h-5 w-5" /></span><div><p className="text-sm font-semibold">{courseName}</p><a href="/" className="mt-0.5 text-xs text-emerald-100/60 underline">Switch course</a></div></div>
            <div className="mt-4 flex items-center gap-2 text-xs font-medium text-emerald-100/65"><span className={`h-2 w-2 rounded-full ${dashboard.state === "ready" ? "bg-[#149b48]" : "bg-[#087f3d]"}`} />{dashboard.state === "ready" ? `${dashboard.totals.documents} source files` : "Data setup required"}</div>
          </div>

          <nav className="mt-7 space-y-1.5" aria-label="Course navigation">
            {navItems.filter(item=>isAdmin||!["Ingestion admin","Topic admin","Content and usage"].includes(item.label)).map(({ label, icon: Icon, active }) => (
              <a key={label} href={label === "Past questions" ? `/courses/${courseSlug}/past-questions` : label === "My study" ? "/study" : label === "Study planner" ? "/study/planner" : label === "Topics" ? "#topics" : label === "Ask AI" ? "#ask-ai" : label === "Ingestion admin" ? "/admin/ingestion" : label === "Content and usage" ? "/admin/operations" : label === "Topic admin" ? "/admin/topics" : "#top"} onClick={() => setMobileNav(false)} className={`flex items-center gap-3 rounded-xl px-3.5 py-3 text-sm font-medium transition ${active ? "bg-white text-[#063f30] shadow-sm" : "text-emerald-100/70 hover:bg-white/[.07] hover:text-white"}`}><Icon className="h-[18px] w-[18px]" />{label}</a>
            ))}
          </nav>

          <div className="mt-auto rounded-2xl bg-[#0b513c] p-4"><p className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[.14em] text-[#b4e3c7]"><Sparkles className="h-3.5 w-3.5" /> Data status</p><p className="mt-2 text-sm leading-6 text-emerald-50/80">{dashboard.message}</p></div>
        </aside>

        {mobileNav && <button className="fixed inset-0 z-40 bg-[#063f30]/55 backdrop-blur-sm lg:hidden" onClick={() => setMobileNav(false)} aria-label="Close navigation overlay" />}

        <main id="top" className="min-w-0 flex-1 px-4 pb-16 pt-4 sm:px-7 lg:px-10 xl:px-14">
          <header className="flex items-center justify-between py-2">
            <button onClick={() => setMobileNav(true)} className="rounded-xl border border-[#d4e5da] bg-white p-2.5 lg:hidden" aria-label="Open navigation"><Menu className="h-5 w-5" /></button>
            <div className="hidden items-center gap-2 text-sm text-[#50685c] lg:flex"><GraduationCap className="h-4 w-4" /><span>Clinical sciences</span><ChevronRight className="h-3.5 w-3.5" /><span className="font-medium text-[#063f30]">{courseName}</span></div>
            <div className="flex items-center gap-3"><a href="/help" className="grid h-10 w-10 place-items-center rounded-full border border-[#d4e5da] bg-white text-[#50685c]" aria-label="Help"><CircleHelp className="h-[18px] w-[18px]" /></a><div className="grid h-10 w-10 place-items-center rounded-full bg-[#eaf4ee] text-sm font-bold text-[#0b513c]" title={studentName}>{studentName.slice(0, 1).toUpperCase()}</div></div>
          </header>

          <section className="mt-5 overflow-hidden rounded-[28px] bg-[#063f30] text-white shadow-[0_24px_70px_rgba(6,63,48,.14)]">
            <div className="grid gap-7 p-6 sm:p-8 xl:grid-cols-[1.15fr_.85fr] xl:p-10">
              <div className="max-w-2xl"><p className="text-sm font-medium text-[#b4e3c7]">Good to see you, {studentName}</p><h1 className="mt-3 max-w-xl text-[clamp(2rem,4vw,3.45rem)] font-semibold leading-[1.02] tracking-[-.045em]">Study {courseName} with the evidence beside you.</h1><p className="mt-5 max-w-xl text-[1.02rem] leading-7 text-emerald-50/68">Learn by topic, connect lectures to past questions, and ask a tutor that stays inside your course material.</p></div>
              <div id="ask-ai" className="self-end"><AskTutor compact courseSlug={courseSlug} /></div>
            </div>
          </section>

          {dashboard.state !== "ready" && <div className="mt-5 flex flex-col gap-3 rounded-2xl border border-[#d4e5da] bg-[#e5f3e9] p-4 text-sm text-[#50685c] sm:flex-row sm:items-center sm:justify-between"><span>{dashboard.message}</span><a href="/admin/ingestion" className="font-semibold text-[#087f3d]">Open ingestion admin <ArrowRight className="ml-1 inline h-4 w-4" /></a></div>}

          <PersonalStudy topics={dashboard.topics} compact/>
          <section id="topics" className="mt-10 scroll-mt-4">
            <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-end"><div><p className="text-xs font-bold uppercase tracking-[.14em] text-[#087f3d]">Course map</p><h2 className="mt-1 text-2xl font-semibold tracking-[-.025em] text-[#063f30]">Study by topic</h2><p className="mt-1 text-sm text-[#50685c]">One topic per Drive material, using its filename.</p></div><div className="relative w-full sm:w-[300px]"><Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-[#60776a]" /><Input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search topics" aria-label={`Search ${courseName} topics`} className="h-11 rounded-xl border-[#d4e5da] bg-white pl-10 shadow-none" /></div></div>
            <div className="mt-5 overflow-hidden rounded-2xl border border-[#d4e5da] bg-white shadow-[0_12px_35px_rgba(6,63,48,.05)]">
              {filteredTopics.map((topic, index) => (
                <a key={topic.slug} href={`/courses/${courseSlug}/topics/${topic.slug}`} className="group grid gap-4 border-b border-[#eaf4ee] p-5 transition last:border-0 hover:bg-[#f2f9f5] sm:grid-cols-[1fr_auto] sm:items-center"><div className="flex items-start gap-4"><span className="mt-1 block h-10 w-1 rounded-full" style={{ backgroundColor: topicAccents[index % topicAccents.length] }} /><div><span className="text-xs font-semibold text-[#60776a]">{String(index + 1).padStart(2, "0")}</span><h3 className="mt-0.5 text-[1.05rem] font-semibold text-[#063f30] group-hover:text-[#087f3d]">{topic.name}</h3><p className="mt-1 text-sm text-[#50685c]">{topic.resources} source material · {topic.questions} past questions · {topic.examYears} exam years · {topic.concepts} concepts · {topic.processingStatus}</p></div></div><span className="flex items-center gap-2 text-sm font-semibold text-[#087f3d]">Study topic <span className="grid h-8 w-8 place-items-center rounded-full bg-[#eaf4ee] transition group-hover:translate-x-1 group-hover:bg-[#e5f3e9]"><ArrowRight className="h-4 w-4" /></span></span></a>
              ))}
              {filteredTopics.length === 0 && <div className="p-8 text-center"><Search className="mx-auto h-6 w-6 text-[#60776a]" /><p className="mt-3 font-medium">{query ? `No topic matches “${query}”` : "No Drive materials registered yet"}</p><p className="mt-1 text-sm text-[#60776a]">{query ? "Try a material filename." : "Sync the Drive folder to register material topics."}</p></div>}
            </div>
            <p className="mt-3 text-xs text-[#60776a]">Topic counts are loaded from the live course database.</p>
          </section>

          <section className="mt-10 grid gap-6 xl:grid-cols-[1.18fr_.82fr]">
            <div><div className="flex items-end justify-between"><div><p className="text-xs font-bold uppercase tracking-[.14em] text-[#50685c]">Continue learning</p><h2 className="mt-1 text-2xl font-semibold tracking-[-.025em]">Recent materials</h2></div><a href="/library" className="text-sm font-semibold text-[#087f3d]">View library</a></div><div className="mt-4 space-y-3">
              {dashboard.materials.map((material) => (
                <a key={material.id} href={`/courses/${courseSlug}/materials/${material.id}`} className="flex w-full items-center gap-4 rounded-2xl border border-[#d4e5da] bg-white p-4 text-left transition hover:-translate-y-0.5 hover:shadow-[0_12px_30px_rgba(6,63,48,.07)]"><span className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-[#eaf4ee] text-[#087f3d]"><FileText className="h-5 w-5" /></span><span className="min-w-0 flex-1"><span className="block truncate font-semibold text-[#063f30]">{material.title}</span><span className="mt-1 block text-xs capitalize text-[#60776a]">{material.documentType.replaceAll("_", " ")} · {material.status} · {new Date(material.discoveredAt).toLocaleDateString()}</span></span><ChevronRight className="h-5 w-5 text-[#60776a]" /></a>
              ))}
              {!dashboard.materials.length && <div className="rounded-2xl border border-dashed border-[#d4e5da] bg-white p-8 text-center text-sm text-[#60776a]">No course files are registered yet.</div>}
            </div></div>

            <div id="past-questions" className="scroll-mt-5 rounded-2xl bg-[#e5f3e9] p-6 ring-1 ring-[#d4e5da]"><div className="flex items-start justify-between"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-[#087f3d] text-white"><History className="h-5 w-5" /></span><span className="rounded-full bg-white px-3 py-1 text-xs font-semibold text-[#087f3d]">Historical patterns</span></div><h2 className="mt-6 text-2xl font-semibold tracking-[-.025em] text-[#063f30]">Past questions, decoded.</h2><p className="mt-2 text-sm leading-6 text-[#50685c]">See how topics have appeared across exam years—without pretending to predict the next paper.</p><div className="mt-5 space-y-3"><div className="flex items-center justify-between border-b border-[#d4e5da] pb-3"><span className="text-sm font-medium">Questions indexed</span><strong className="text-xl text-[#087f3d]">{dashboard.totals.questions}</strong></div><div className="flex items-center justify-between border-b border-[#d4e5da] pb-3"><span className="text-sm font-medium">Exam years</span><strong className="text-xl text-[#087f3d]">{dashboard.totals.examYears}</strong></div><div className="flex items-center justify-between"><span className="text-sm font-medium">Source files</span><strong className="text-sm text-[#087f3d]">{dashboard.totals.documents} registered</strong></div></div><a href={`/courses/${courseSlug}/past-questions`} className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-[#0b513c] px-4 py-3 text-sm font-semibold text-white transition hover:bg-[#0b513c]">Explore exam history <ArrowRight className="h-4 w-4" /></a></div>
          </section>

          <footer className="mt-12 flex flex-col gap-2 border-t border-[#d4e5da] pt-5 text-xs text-[#60776a] sm:flex-row sm:items-center sm:justify-between"><span>MindRounds · {courseName}</span><span className="flex items-center gap-1.5"><Clock3 className="h-3.5 w-3.5" /> Sources remain traceable from answer to page</span></footer>
        </main>
      </div>
    </div>
  );
}
