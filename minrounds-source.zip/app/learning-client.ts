"use client";
import type { LearningData } from "@/lib/learning-types";
let bootstrap:Promise<LearningData>|undefined;
export async function learningRequest<T=Record<string,unknown>>(body:Record<string,unknown>):Promise<T>{
  await initializeLearning();
  const response=await fetch("/api/learning",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body),keepalive:true});const result=await response.json() as T & {error?:string};if(!response.ok)throw Error(result.error||"Progress could not be saved.");return result;
}
export async function getLearning(query=""):Promise<LearningData>{
  const response=await fetch(`/api/learning${query}`,{cache:"no-store"});const result=await response.json() as LearningData & {error?:string};if(!response.ok)throw Error(result.error||"Progress could not be loaded.");return result;
}
export function initializeLearning(){if(!bootstrap)bootstrap=getLearning().catch(e=>{bootstrap=undefined;throw e;});return bootstrap;}
export function learningChanged(){window.dispatchEvent(new Event("learning-changed"));}
export const field="w-full rounded-xl border border-[#d5dfeb] bg-white px-3 py-2 text-sm";
export const button="rounded-xl bg-[#24466f] px-4 py-2.5 text-sm font-semibold text-white disabled:opacity-40";
export const panel="rounded-2xl border border-[#dfe6ef] bg-white p-5 sm:p-6";
